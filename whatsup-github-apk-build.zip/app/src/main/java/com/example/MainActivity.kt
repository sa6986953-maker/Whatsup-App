package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.testTag
import com.example.core.BiometricAuthHelper
import com.example.core.OfflineMeshEngine
import com.example.core.PreferencesManager
import com.example.core.configureAppCheck
import com.example.data.repository.AuthRepository
import com.example.data.repository.LocalWhatsupStore
import com.example.data.repository.WhatsupAiRepository
import com.example.data.repository.WhatsupRepository
import com.example.ui.components.WhatsupBrandLogo
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.home.WhatsupMainApp
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.theme.WhatsupTheme
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.WhatsupViewModel
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory Firebase App Check wiring before Compose UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefsManager = remember { PreferencesManager(context.applicationContext) }
            val localPrefs by prefsManager.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = com.example.core.LocalAppPreferences()
            )

            WhatsupTheme(darkTheme = localPrefs.darkMode) {
                WhatsupRootApp(
                    preferencesManager = prefsManager,
                    appLockEnabled = localPrefs.appLockEnabled,
                    appLockPin = localPrefs.appLockPin
                )
            }
        }
    }
}

@Composable
private fun WhatsupRootApp(
    preferencesManager: PreferencesManager,
    appLockEnabled: Boolean,
    appLockPin: String
) {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val localStore = remember(context) { LocalWhatsupStore(context.applicationContext) }
    var splashComplete by rememberSaveable { mutableStateOf(false) }
    var unlockedSession by rememberSaveable { mutableStateOf(false) }
    var showOptionalCloudAuth by rememberSaveable { mutableStateOf(false) }

    val authViewModel: AuthViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                AuthViewModel(AuthRepository(), preferencesManager)
            }
        }
    )

    val currentUser by authViewModel.currentUser.collectAsStateWithLifecycle()
    val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        authViewModel.attemptSilentSignIn(context)
    }

    LaunchedEffect(currentUser) {
        if (currentUser != null) {
            showOptionalCloudAuth = false
        }
    }

    if (!splashComplete) {
        SplashScreen(onSplashFinished = { splashComplete = true })
        return
    }

    if (appLockEnabled && !unlockedSession) {
        AppLockGateScreen(
            expectedPin = appLockPin,
            onUnlocked = { unlockedSession = true }
        )
        return
    }

    if (showOptionalCloudAuth) {
        AuthScreen(
            authViewModel = authViewModel,
            onContinueWithoutGoogle = { showOptionalCloudAuth = false }
        )
        return
    }

    val user = currentUser
    val uid = user?.uid ?: "local_device_user"
    key(uid) {
        val whatsupViewModel: WhatsupViewModel = viewModel(
            key = uid,
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY])
                    val databaseId = app.getString(R.string.firestore_database_id)
                    val db = FirebaseFirestore.getInstance(databaseId)
                    WhatsupViewModel(
                        repository = WhatsupRepository(db = db, localStore = localStore),
                        preferencesManager = preferencesManager,
                        offlineMeshEngine = OfflineMeshEngine(app.applicationContext),
                        currentUserId = uid,
                        initialDisplayName = user?.displayName ?: "Hamza"
                    )
                }
            }
        )
        val aiViewModel: AiAssistantViewModel = viewModel(
            key = "ai_$uid",
            factory = viewModelFactory {
                initializer { AiAssistantViewModel(WhatsupAiRepository()) }
            }
        )

        WhatsupMainApp(
            viewModel = whatsupViewModel,
            aiViewModel = aiViewModel,
            isGoogleSignedIn = user != null,
            signedInEmail = user?.email,
            isAuthLoading = authUiState.isLoading,
            authErrorMessage = authUiState.errorMessage,
            onConnectGoogleAccount = {
                if (activity != null) {
                    authViewModel.signInWithGoogle(activity)
                } else {
                    showOptionalCloudAuth = true
                }
            },
            onOpenOptionalCloudSetup = { showOptionalCloudAuth = true },
            onSignOut = {
                authViewModel.signOut(context)
            }
        )
    }
}

@Composable
private fun AppLockGateScreen(
    expectedPin: String,
    onUnlocked: () -> Unit
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val triggerBiometric = remember(context, onUnlocked) {
        {
            BiometricAuthHelper.authenticate(
                context = context,
                title = "Unlock Whatsup",
                subtitle = "Verify with Fingerprint or Face Lock",
                onSuccess = onUnlocked,
                onError = { msg -> error = msg },
                onUnavailableFallback = {
                    error = "Biometrics unavailable on this device. Enter your PIN below."
                }
            )
        }
    }

    LaunchedEffect(Unit) {
        if (BiometricAuthHelper.canUseBiometricOrDeviceCredential(context)) {
            triggerBiometric()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        WhatsupBrandLogo(size = 76.dp)
        Spacer(modifier = Modifier.height(16.dp))
        Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Whatsup Locked", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Use Fingerprint / Face or App Lock PIN (default: $expectedPin)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = pinInput,
            onValueChange = {
                pinInput = it.filter { c -> c.isDigit() }.take(6)
                error = null
            },
            label = { Text("Enter PIN") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.testTag("app_lock_pin_input")
        )
        if (error != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
        Spacer(modifier = Modifier.height(14.dp))
        Button(
            onClick = {
                if (pinInput == expectedPin) onUnlocked() else error = "Incorrect PIN"
            },
            colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
            modifier = Modifier.testTag("app_lock_unlock_button")
        ) {
            Text("Unlock Whatsup", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(
            onClick = { triggerBiometric() },
            modifier = Modifier.testTag("app_lock_biometric_button")
        ) {
            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = WhatsupGreen, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Use Fingerprint / Face")
        }
    }
}
