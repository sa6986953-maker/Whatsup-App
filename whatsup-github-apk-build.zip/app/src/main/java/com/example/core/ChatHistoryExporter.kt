package com.example.core

import android.content.Context
import android.os.Environment
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ExportFormat(
    val extension: String,
    val label: String,
    val description: String
) {
    JSON("json", "JSON (.json)", "Structured data with metadata & message fields"),
    TXT("txt", "TXT (.txt)", "Human-readable conversation transcript")
}

data class ExportedChatFile(
    val name: String,
    val format: ExportFormat,
    val sizeBytes: Long,
    val lastModifiedMillis: Long,
    val absolutePath: String
)

object ChatHistoryExporter {

    private const val FILE_PREFIX = "whatsup_chat_"

    fun getLocalDocumentsDir(context: Context): File {
        val docsRoot = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: File(context.filesDir, "documents")
        if (!docsRoot.exists()) {
            docsRoot.mkdirs()
        }
        return docsRoot
    }

    fun exportToLocalDocuments(
        context: Context,
        accountPhone: String,
        scopeLabel: String,
        chatEntries: List<Pair<ChatThread, List<ChatMessage>>>,
        format: ExportFormat
    ): ExportedChatFile {
        val docsDir = getLocalDocumentsDir(context)
        val fileTimestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val readableTimestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val safeScope = scopeLabel
            .lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .take(28)
            .ifBlank { "history" }

        val fileName = "${FILE_PREFIX}${safeScope}_${fileTimestamp}.${format.extension}"
        val targetFile = File(docsDir, fileName)

        val content = when (format) {
            ExportFormat.JSON -> buildJsonExport(
                accountPhone = accountPhone,
                scopeLabel = scopeLabel,
                exportedAt = readableTimestamp,
                chatEntries = chatEntries
            )
            ExportFormat.TXT -> buildTxtExport(
                accountPhone = accountPhone,
                scopeLabel = scopeLabel,
                exportedAt = readableTimestamp,
                chatEntries = chatEntries
            )
        }

        targetFile.writeText(content, Charsets.UTF_8)

        return ExportedChatFile(
            name = targetFile.name,
            format = format,
            sizeBytes = targetFile.length(),
            lastModifiedMillis = targetFile.lastModified(),
            absolutePath = targetFile.absolutePath
        )
    }

    fun listExportedFiles(context: Context): List<ExportedChatFile> {
        val docsDir = getLocalDocumentsDir(context)
        val files = docsDir.listFiles() ?: return emptyList()
        return files
            .filter { it.isFile && it.name.startsWith(FILE_PREFIX) && (it.extension.equals("json", true) || it.extension.equals("txt", true)) }
            .sortedByDescending { it.lastModified() }
            .map { file ->
                val fmt = if (file.extension.equals("json", ignoreCase = true)) {
                    ExportFormat.JSON
                } else {
                    ExportFormat.TXT
                }
                ExportedChatFile(
                    name = file.name,
                    format = fmt,
                    sizeBytes = file.length(),
                    lastModifiedMillis = file.lastModified(),
                    absolutePath = file.absolutePath
                )
            }
    }

    fun readExportedFilePreview(filePath: String, maxChars: Int = 6000): String {
        val file = File(filePath)
        if (!file.exists() || !file.isFile) return "File not found."
        val text = file.readText(Charsets.UTF_8)
        return if (text.length > maxChars) {
            text.take(maxChars) + "\n\n... (truncated preview)"
        } else {
            text
        }
    }

    fun deleteExportedFile(filePath: String): Boolean {
        val file = File(filePath)
        return if (file.exists() && file.isFile) file.delete() else false
    }

    private fun buildJsonExport(
        accountPhone: String,
        scopeLabel: String,
        exportedAt: String,
        chatEntries: List<Pair<ChatThread, List<ChatMessage>>>
    ): String {
        val root = JSONObject()
        root.put("app", "Whatsup")
        root.put("exportedAt", exportedAt)
        root.put("accountPhone", accountPhone)
        root.put("scope", scopeLabel)

        val chatsArray = JSONArray()
        var totalMessages = 0

        chatEntries.forEach { (thread, messages) ->
            val visibleMessages = messages.filter { !it.deletedForMe }
            totalMessages += visibleMessages.size

            val chatObj = JSONObject()
            chatObj.put("chatId", thread.id)
            chatObj.put("title", thread.title)
            chatObj.put("phone", thread.phone)
            chatObj.put("chatType", thread.chatType)
            chatObj.put("disappearingMode", thread.disappearingMode)
            chatObj.put("bluetoothChat", thread.bluetoothChat)
            chatObj.put("archived", thread.archived)
            chatObj.put("pinned", thread.pinned)

            val msgsArray = JSONArray()
            visibleMessages.forEach { msg ->
                val msgObj = JSONObject()
                msgObj.put("id", msg.id)
                msgObj.put("senderName", if (msg.fromMe) "Me" else msg.senderName)
                msgObj.put("fromMe", msg.fromMe)
                msgObj.put("text", msg.text)
                msgObj.put("messageType", msg.messageType)
                msgObj.put("tickStatus", msg.tickStatus)
                msgObj.put("viaBluetooth", msg.viaBluetooth)
                msgObj.put("starred", msg.starred)
                msgObj.put("timeLabel", msg.timeLabel)
                if (!msg.replyToSender.isNullOrBlank()) {
                    msgObj.put("replyToSender", msg.replyToSender)
                }
                if (!msg.replyToText.isNullOrBlank()) {
                    msgObj.put("replyToText", msg.replyToText)
                }
                if (!msg.mediaMeta.isNullOrBlank()) {
                    msgObj.put("mediaMeta", msg.mediaMeta)
                }
                msgsArray.put(msgObj)
            }
            chatObj.put("messages", msgsArray)
            chatsArray.put(chatObj)
        }

        root.put("chatCount", chatEntries.size)
        root.put("totalMessages", totalMessages)
        root.put("chats", chatsArray)
        return root.toString(2)
    }

    private fun buildTxtExport(
        accountPhone: String,
        scopeLabel: String,
        exportedAt: String,
        chatEntries: List<Pair<ChatThread, List<ChatMessage>>>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("Whatsup Chat History Export")
        sb.appendLine("Exported: $exportedAt")
        sb.appendLine("Account: $accountPhone")
        sb.appendLine("Scope: $scopeLabel")
        sb.appendLine("========================================")
        sb.appendLine()

        chatEntries.forEach { (thread, messages) ->
            val visibleMessages = messages.filter { !it.deletedForMe }
            sb.appendLine("--- ${thread.title} (${thread.chatType}) ---")
            if (visibleMessages.isEmpty()) {
                sb.appendLine("(No messages in this conversation)")
            } else {
                visibleMessages.forEach { msg ->
                    val sender = if (msg.fromMe) "Me" else msg.senderName
                    val btTag = if (msg.viaBluetooth) " [Sent via Bluetooth]" else ""
                    val starTag = if (msg.starred) " ★" else ""
                    val replyPrefix = if (!msg.replyToText.isNullOrBlank()) {
                        " (Replying to ${msg.replyToSender ?: "message"}: \"${msg.replyToText}\")"
                    } else ""
                    val metaSuffix = if (!msg.mediaMeta.isNullOrBlank()) " [${msg.mediaMeta}]" else ""
                    sb.appendLine("[${msg.timeLabel}] $sender$replyPrefix: ${msg.text}$metaSuffix$btTag$starTag")
                }
            }
            sb.appendLine()
        }
        return sb.toString()
    }
}
