package com.example.data.model

object PakistaniSeedData {

    data class SeedChatSpec(
        val id: String,
        val title: String,
        val phone: String,
        val colorHex: Long,
        val chatType: String,
        val lastMessage: String,
        val lastTime: String,
        val tick: String,
        val unread: Long,
        val pinned: Boolean,
        val online: Boolean,
        val lastSeen: String,
        val memberCount: Long = 2L,
        val communityName: String? = null,
        val onlyAdminCanSend: Boolean = false,
        val bluetoothChat: Boolean = false,
        val disappearing: String = "OFF",
        val sortOrder: Long,
        val messages: List<SeedMessageSpec>
    )

    data class SeedMessageSpec(
        val id: String,
        val senderName: String,
        val fromMe: Boolean,
        val text: String,
        val type: String = "TEXT",
        val tick: String = "READ",
        val viaBluetooth: Boolean = false,
        val mediaMeta: String? = null,
        val timeLabel: String
    )

    val chats: List<SeedChatSpec> = listOf(
        SeedChatSpec(
            id = "chat_ammi",
            title = "Ammi ❤️",
            phone = "+92 300 7123456",
            colorHex = 0xFF1DAB61,
            chatType = "DIRECT",
            lastMessage = "Khana kha liya beta? Dawai time pe lena.",
            lastTime = "10:15 AM",
            tick = "READ",
            unread = 2L,
            pinned = true,
            online = true,
            lastSeen = "online",
            sortOrder = 1000L,
            messages = listOf(
                SeedMessageSpec("m1", "Ammi ❤️", false, "Assalam-o-Alaikum beta, office pohanch gaye?", timeLabel = "9:40 AM"),
                SeedMessageSpec("m2", "Me", true, "Walaikum Assalam Ammi, ji Alhamdulillah pohanch gaya hoon.", tick = "READ", timeLabel = "9:42 AM"),
                SeedMessageSpec("m3", "Ammi ❤️", false, "Shaam ko aate waqt taza dahi aur sabzi le aana.", timeLabel = "10:12 AM"),
                SeedMessageSpec("m4", "Ammi ❤️", false, "Khana kha liya beta? Dawai time pe lena.", timeLabel = "10:15 AM")
            )
        ),
        SeedChatSpec(
            id = "chat_abbu",
            title = "Abbu",
            phone = "+92 301 6677889",
            colorHex = 0xFF075E54,
            chatType = "DIRECT",
            lastMessage = "Bijli ka bill jama karwa diya hai Whatsup se screenshot bhejo.",
            lastTime = "9:50 AM",
            tick = "DELIVERED",
            unread = 0L,
            pinned = true,
            online = false,
            lastSeen = "last seen today at 9:52 AM",
            sortOrder = 990L,
            messages = listOf(
                SeedMessageSpec("m1", "Abbu", false, "Beta gaon mein aaj net slow hai, Bluetooth chat on rakhna.", viaBluetooth = true, timeLabel = "9:15 AM"),
                SeedMessageSpec("m2", "Me", true, "Ji Abbu, Whatsup Offline Mode on hai. Signal aate hi sync ho jayega.", tick = "DELIVERED", viaBluetooth = true, timeLabel = "9:20 AM"),
                SeedMessageSpec("m3", "Abbu", false, "Bijli ka bill jama karwa diya hai Whatsup se screenshot bhejo.", timeLabel = "9:50 AM")
            )
        ),
        SeedChatSpec(
            id = "chat_ali_raza",
            title = "Ali Raza",
            phone = "+92 302 4455661",
            colorHex = 0xFF1D9BF0,
            chatType = "DIRECT",
            lastMessage = "Bro Kahror Pakka road pe signal gayab thay, Bluetooth se msg mila!",
            lastTime = "Yesterday",
            tick = "BLUETOOTH",
            unread = 1L,
            pinned = false,
            online = true,
            lastSeen = "online",
            bluetoothChat = true,
            sortOrder = 980L,
            messages = listOf(
                SeedMessageSpec("m1", "Ali Raza", false, "Yaar cricket match shaam 5 baje ground mein hai.", timeLabel = "4:10 PM"),
                SeedMessageSpec("m2", "Me", true, "Done hai, main pads aur ball le ke aa raha hoon.", tick = "READ", timeLabel = "4:12 PM"),
                SeedMessageSpec("m3", "Ali Raza", false, "Bro Kahror Pakka road pe signal gayab thay, Bluetooth se msg mila!", viaBluetooth = true, timeLabel = "8:30 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_ayesha",
            title = "Ayesha Khan",
            phone = "+92 333 9988112",
            colorHex = 0xFF8E24AA,
            chatType = "DIRECT",
            lastMessage = "Notes PDF bhej rahi hoon HD mein, check kar lena.",
            lastTime = "Yesterday",
            tick = "READ",
            unread = 0L,
            pinned = false,
            online = false,
            lastSeen = "last seen yesterday at 11:20 PM",
            disappearing = "7D",
            sortOrder = 970L,
            messages = listOf(
                SeedMessageSpec("m1", "Ayesha Khan", false, "Kal university ki presentation ready hai?", timeLabel = "6:00 PM"),
                SeedMessageSpec("m2", "Me", true, "Haan bas final slides Whatsup AI se summarize ki hain.", tick = "READ", timeLabel = "6:05 PM"),
                SeedMessageSpec("m3", "Ayesha Khan", false, "Notes PDF bhej rahi hoon HD mein, check kar lena.", type = "DOCUMENT", mediaMeta = "CS_Final_Notes.pdf • 3.4 MB", timeLabel = "6:10 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_bilal_bhai",
            title = "Bilal Bhai",
            phone = "+92 345 2233445",
            colorHex = 0xFFEF6C00,
            chatType = "DIRECT",
            lastMessage = "Voice note suno, Multan se kab nikal rahe ho?",
            lastTime = "Yesterday",
            tick = "SENT",
            unread = 0L,
            pinned = false,
            online = false,
            lastSeen = "last seen yesterday at 7:45 PM",
            sortOrder = 960L,
            messages = listOf(
                SeedMessageSpec("m1", "Bilal Bhai", false, "Voice note suno, Multan se kab nikal rahe ho?", type = "VOICE", mediaMeta = "Voice message • 0:24", timeLabel = "7:40 PM"),
                SeedMessageSpec("m2", "Me", true, "Subah Fajr ke baad nikloonga InshaAllah.", tick = "SENT", timeLabel = "7:44 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_kahror_group",
            title = "Kahror Pakka Friends 🇵🇰",
            phone = "",
            colorHex = 0xFF00897B,
            chatType = "GROUP",
            lastMessage = "Hamza: Aaj raat chai Quetta Hotel pe pakki hai!",
            lastTime = "10:05 AM",
            tick = "READ",
            unread = 5L,
            pinned = false,
            online = true,
            lastSeen = "Hamza, Ali Raza, Usman +42 members",
            memberCount = 45L,
            communityName = "Kahror Pakka Youth Community",
            sortOrder = 950L,
            messages = listOf(
                SeedMessageSpec("m1", "Usman", false, "Sab bhai online aao, weekend tour ka plan banate hain.", timeLabel = "9:55 AM"),
                SeedMessageSpec("m2", "Ali Raza", false, "Murree ya Swat? Poll daal do group mein!", type = "POLL", mediaMeta = "Poll: Weekend Tour • Murree (18) vs Swat (27)", timeLabel = "10:00 AM"),
                SeedMessageSpec("m3", "Hamza Tariq", false, "Aaj raat chai Quetta Hotel pe pakki hai!", timeLabel = "10:05 AM")
            )
        ),
        SeedChatSpec(
            id = "chat_zainab",
            title = "Zainab Bibi",
            phone = "+92 312 5544332",
            colorHex = 0xFFD81B60,
            chatType = "DIRECT",
            lastMessage = "Photo View-Once mein bheja hai, dekh lo.",
            lastTime = "Tuesday",
            tick = "READ",
            unread = 0L,
            pinned = false,
            online = false,
            lastSeen = "last seen Tuesday at 4:18 PM",
            sortOrder = 940L,
            messages = listOf(
                SeedMessageSpec("m1", "Zainab Bibi", false, "Shaadi ki shopping ho gayi?", timeLabel = "4:10 PM"),
                SeedMessageSpec("m2", "Zainab Bibi", false, "Photo View-Once mein bheja hai, dekh lo.", type = "VIEW_ONCE", mediaMeta = "View Once Photo • Tap to open", timeLabel = "4:15 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_hamza_tariq",
            title = "Hamza Tariq",
            phone = "+92 306 8899001",
            colorHex = 0xFF3949AB,
            chatType = "DIRECT",
            lastMessage = "16-person Video Call link bhej diya hai, join karo.",
            lastTime = "Monday",
            tick = "READ",
            unread = 0L,
            pinned = false,
            online = true,
            lastSeen = "online",
            sortOrder = 930L,
            messages = listOf(
                SeedMessageSpec("m1", "Hamza Tariq", false, "Project meeting start ho rahi hai.", timeLabel = "2:00 PM"),
                SeedMessageSpec("m2", "Hamza Tariq", false, "16-person Video Call link bhej diya hai, join karo.", timeLabel = "2:02 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_usman_elec",
            title = "Usman Electrician",
            phone = "+92 308 1122009",
            colorHex = 0xFF5D4037,
            chatType = "DIRECT",
            lastMessage = "UPS ki battery check kar li hai, shaam 6 baje aaunga.",
            lastTime = "Monday",
            tick = "DELIVERED",
            unread = 0L,
            pinned = false,
            online = false,
            lastSeen = "last seen Monday at 5:30 PM",
            sortOrder = 920L,
            messages = listOf(
                SeedMessageSpec("m1", "Me", true, "Usman bhai UPS trip kar raha hai, kab aaoge?", tick = "READ", timeLabel = "3:15 PM"),
                SeedMessageSpec("m2", "Usman Electrician", false, "UPS ki battery check kar li hai, shaam 6 baje aaunga.", timeLabel = "3:40 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_fatima_baji",
            title = "Fatima Baji",
            phone = "+92 334 7766554",
            colorHex = 0xFF00796B,
            chatType = "DIRECT",
            lastMessage = "JazakAllah khair! Bacchon ki duaon mein yaad rakhna.",
            lastTime = "Sunday",
            tick = "READ",
            unread = 0L,
            pinned = false,
            online = false,
            lastSeen = "last seen Sunday at 9:10 PM",
            sortOrder = 910L,
            messages = listOf(
                SeedMessageSpec("m1", "Fatima Baji", false, "Eid pe ghar kab aa rahe ho sab?", timeLabel = "8:55 PM"),
                SeedMessageSpec("m2", "Me", true, "InshaAllah chand raat se ek din pehle sab sath aayenge.", tick = "READ", timeLabel = "9:02 PM"),
                SeedMessageSpec("m3", "Fatima Baji", false, "JazakAllah khair! Bacchon ki duaon mein yaad rakhna.", timeLabel = "9:05 PM")
            )
        ),
        SeedChatSpec(
            id = "chat_bt_classroom",
            title = "Hostel & Campus Bluetooth Mesh",
            phone = "",
            colorHex = 0xFF1D9BF0,
            chatType = "BLUETOOTH_GROUP",
            lastMessage = "Nearby 100m mesh active • No internet required",
            lastTime = "Now",
            tick = "BLUETOOTH",
            unread = 3L,
            pinned = false,
            online = true,
            lastSeen = "12 nearby Whatsup peers within 100m",
            memberCount = 12L,
            communityName = "Kahror Pakka Youth Community",
            bluetoothChat = true,
            sortOrder = 900L,
            messages = listOf(
                SeedMessageSpec("m1", "Ali Raza", false, "Class cancel ho gayi hai, sir nahi aaye!", viaBluetooth = true, timeLabel = "9:05 AM"),
                SeedMessageSpec("m2", "Hamza Tariq", false, "Wifi aur 4G dono band hain hostel mein, shukar hai Whatsup Bluetooth chal raha hai!", viaBluetooth = true, timeLabel = "9:07 AM")
            )
        )
    )

    val statuses = listOf(
        Triple("Ali Raza", "Kahror Pakka sunset vibes 🌅✨", "PHOTO") to ("25m ago" to "Ammi ❤️, Ayesha, Hamza +14"),
        Triple("Ayesha Khan", "Alhamdulillah! Final Year Project defended 🎓", "TEXT") to ("1h ago" to "Ali Raza, Bilal Bhai, Zainab +28"),
        Triple("Bilal Bhai", "Motorway M-5 smooth drive towards Multan 🚗", "VIDEO") to ("3h ago" to "Abbu, Usman, Fatima Baji +9"),
        Triple("Whatsup Official Channel", "New: Offline 100m Bluetooth Mesh & Whatsup AI ✨", "CHANNEL") to ("Today" to "1.2M followers"),
        Triple("Pakistan Tech & Cricket", "Live updates, weather alerts & low-data feeds 🇵🇰", "CHANNEL") to ("Today" to "840K followers")
    )

    val calls = listOf(
        CallRecord(
            id = "call_1",
            peerName = "Ammi ❤️",
            callType = "VIDEO",
            direction = "INCOMING",
            durationLabel = "14:22",
            participantCount = 2L,
            recorded = false,
            timeLabel = "Today, 9:30 AM"
        ),
        CallRecord(
            id = "call_2",
            peerName = "Kahror Pakka Friends (16 Video)",
            callType = "GROUP_VIDEO",
            direction = "OUTGOING",
            durationLabel = "42:10",
            participantCount = 16L,
            callLinkCode = "whatsup.pk/join/kp-8492",
            recorded = true,
            timeLabel = "Yesterday, 10:15 PM"
        ),
        CallRecord(
            id = "call_3",
            peerName = "Abbu",
            callType = "VOICE",
            direction = "OUTGOING",
            durationLabel = "06:48",
            participantCount = 2L,
            recorded = false,
            timeLabel = "Yesterday, 6:00 PM"
        ),
        CallRecord(
            id = "call_4",
            peerName = "Hamza Tariq (32 Voice Conf)",
            callType = "GROUP_VOICE",
            direction = "INCOMING",
            durationLabel = "29:05",
            participantCount = 24L,
            callLinkCode = "whatsup.pk/join/dev-3104",
            recorded = false,
            timeLabel = "Monday, 3:20 PM"
        ),
        CallRecord(
            id = "call_5",
            peerName = "Ali Raza",
            callType = "VIDEO",
            direction = "MISSED",
            durationLabel = "Missed",
            participantCount = 2L,
            recorded = false,
            timeLabel = "Sunday, 8:10 PM"
        )
    )
}
