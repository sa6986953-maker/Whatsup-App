package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Whatsup User",
    val phoneNumber: String = "+92 300 4512980",
    val secondaryPhone: String = "+92 321 9876543",
    val about: String = "Assalam-o-Alaikum! Using Whatsup Mesh",
    val twoStepEnabled: Boolean = false,
    val hideOnline: Boolean = false,
    val hideBlueTicks: Boolean = false,
    val hideLastSeen: Boolean = false,
    val dataSaver: Boolean = false,
    val autoReplyEnabled: Boolean = false,
    val autoReplyText: String = "Assalam-o-Alaikum, main abhi masroof hoon. Thori der mein jawab doonga.",
    val appLockEnabled: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatThread(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val phone: String = "",
    val avatarColorHex: Long = 0xFF25D366,
    val chatType: String = "DIRECT", // DIRECT, GROUP, COMMUNITY, BLUETOOTH_GROUP
    val lastMessage: String = "",
    val lastMessageTimeLabel: String = "",
    val lastMessageTick: String = "READ", // PENDING_SYNC, SENT, DELIVERED, READ, BLUETOOTH
    val unreadCount: Long = 0L,
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val muted: Boolean = false,
    val locked: Boolean = false,
    val online: Boolean = false,
    val typing: Boolean = false,
    val lastSeenText: String = "last seen today at 10:15 AM",
    val disappearingMode: String = "OFF", // OFF, 24H, 7D, 90D
    val wallpaperStyle: String = "DEFAULT",
    val memberCount: Long = 2L,
    val communityName: String? = null,
    val onlyAdminCanSend: Boolean = false,
    val bluetoothChat: Boolean = false,
    val encryptionCode: String = "88412-90124-55612-77219",
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val chatId: String = "",
    val senderName: String = "",
    val fromMe: Boolean = true,
    val text: String = "",
    val messageType: String = "TEXT", // TEXT, VOICE, IMAGE_HD, VIDEO, DOCUMENT, LOCATION, CONTACT, POLL, EVENT, VIEW_ONCE, STICKER, GIF
    val tickStatus: String = "SENT", // PENDING_SYNC, SENT, DELIVERED, READ
    val viaBluetooth: Boolean = false,
    val starred: Boolean = false,
    val deletedForEveryone: Boolean = false,
    val deletedForMe: Boolean = false,
    val viewOnceOpened: Boolean = false,
    val replyToText: String? = null,
    val replyToSender: String? = null,
    val mediaMeta: String? = null,
    val scheduledForMillis: Long? = null,
    val reactions: Map<String, Long> = emptyMap(),
    val myReaction: String = "",
    val timeLabel: String = "10:30 AM",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

object MessageReactionHelper {
    val quickEmojis: List<String> = listOf("❤️", "👍", "😂", "😮", "😢", "🙏")

    fun computeToggledReactions(
        currentReactions: Map<String, Long>,
        currentMyReaction: String,
        emoji: String
    ): Pair<Map<String, Long>, String> {
        val nextCounts = currentReactions.toMutableMap()
        if (currentMyReaction == emoji) {
            val decremented = (nextCounts[emoji] ?: 1L) - 1L
            if (decremented > 0L) {
                nextCounts[emoji] = decremented
            } else {
                nextCounts.remove(emoji)
            }
            return nextCounts to ""
        }

        if (currentMyReaction.isNotBlank()) {
            val prevDecremented = (nextCounts[currentMyReaction] ?: 1L) - 1L
            if (prevDecremented > 0L) {
                nextCounts[currentMyReaction] = prevDecremented
            } else {
                nextCounts.remove(currentMyReaction)
            }
        }
        nextCounts[emoji] = (nextCounts[emoji] ?: 0L) + 1L
        return nextCounts to emoji
    }
}

@Keep
@IgnoreExtraProperties
data class StatusUpdate(
    @DocumentId val id: String = "",
    val userId: String = "",
    val authorName: String = "",
    val caption: String = "",
    val statusType: String = "TEXT", // TEXT, PHOTO, VIDEO, CHANNEL
    val bgColorHex: Long = 0xFF075E54,
    val viewedByCount: Long = 0L,
    val viewersSummary: String = "",
    val timeLabel: String = "",
    val viewed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val peerName: String = "",
    val callType: String = "VOICE", // VOICE, VIDEO, GROUP_VOICE, GROUP_VIDEO
    val direction: String = "OUTGOING", // INCOMING, OUTGOING, MISSED
    val durationLabel: String = "",
    val participantCount: Long = 2L,
    val callLinkCode: String? = null,
    val recorded: Boolean = false,
    val timeLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class NearbyBluetoothPeer(
    val peerId: String,
    val name: String,
    val phoneHint: String,
    val distanceMeters: Int,
    val transport: String, // "Bluetooth LE" or "Wi-Fi Direct"
    val signalBars: Int,
    val connected: Boolean = false
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
