package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.MessageReactionHelper
import com.example.data.model.PakistaniSeedData
import com.example.data.model.StatusUpdate
import com.example.data.model.UserProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private const val TAG = "LocalWhatsupStore"
private const val STORE_FILE_NAME = "whatsup_local_store.json"
private const val LOCAL_UID = "local_device_user"

/**
 * Device-local JSON-backed store used when the user skips optional Google login.
 * Ensures all chats, messages, emoji reactions, statuses, calls, locks, and privacy
 * settings persist across app restarts without requiring a Google account.
 */
class LocalWhatsupStore(context: Context) {

    private val storeFile = File(context.applicationContext.filesDir, STORE_FILE_NAME)
    private val mutex = Mutex()

    private data class Snapshot(
        val profile: UserProfile? = null,
        val chats: List<ChatThread> = emptyList(),
        val messagesByChat: Map<String, List<ChatMessage>> = emptyMap(),
        val statuses: List<StatusUpdate> = emptyList(),
        val calls: List<CallRecord> = emptyList()
    )

    private val state = MutableStateFlow(Snapshot())
    private var loaded = false

    fun observeProfile(): Flow<UserProfile?> = state.map { it.profile }

    fun observeChats(): Flow<List<ChatThread>> = state.map { snap ->
        snap.chats.sortedByDescending { it.sortOrder }
    }

    fun observeMessages(chatId: String): Flow<List<ChatMessage>> = state.map { snap ->
        snap.messagesByChat[chatId].orEmpty()
    }

    fun observeStatuses(): Flow<List<StatusUpdate>> = state.map { it.statuses }

    fun observeCalls(): Flow<List<CallRecord>> = state.map { it.calls }

    suspend fun getMessagesSnapshot(chatId: String): List<ChatMessage> {
        ensureLoaded()
        return state.value.messagesByChat[chatId].orEmpty()
    }

    suspend fun ensureInitialized(displayName: String, phoneNumber: String) {
        mutex.withLock {
            loadFromDiskIfNeededLocked()
            val cur = state.value
            if (cur.profile != null && cur.chats.isNotEmpty()) return

            val safeName = displayName.ifBlank { "Whatsup User" }.take(80)
            val safePhone = phoneNumber.ifBlank { "+92 300 4512980" }.take(30)
            val profile = cur.profile ?: UserProfile(
                id = LOCAL_UID,
                userId = LOCAL_UID,
                displayName = safeName,
                phoneNumber = safePhone
            )

            val chats = if (cur.chats.isNotEmpty()) {
                cur.chats
            } else {
                PakistaniSeedData.chats.map { seed ->
                    ChatThread(
                        id = seed.id,
                        userId = LOCAL_UID,
                        title = seed.title,
                        phone = seed.phone,
                        avatarColorHex = seed.colorHex,
                        chatType = seed.chatType,
                        lastMessage = seed.lastMessage,
                        lastMessageTimeLabel = seed.lastTime,
                        lastMessageTick = seed.tick,
                        unreadCount = seed.unread,
                        pinned = seed.pinned,
                        archived = false,
                        muted = false,
                        locked = false,
                        online = seed.online,
                        typing = false,
                        lastSeenText = seed.lastSeen,
                        disappearingMode = seed.disappearing,
                        wallpaperStyle = "DEFAULT",
                        memberCount = seed.memberCount,
                        communityName = seed.communityName,
                        onlyAdminCanSend = seed.onlyAdminCanSend,
                        bluetoothChat = seed.bluetoothChat,
                        encryptionCode = "88412-90124-55612-77219",
                        sortOrder = seed.sortOrder
                    )
                }
            }

            val msgMap = if (cur.messagesByChat.isNotEmpty()) {
                cur.messagesByChat
            } else {
                PakistaniSeedData.chats.associate { seed ->
                    seed.id to seed.messages.map { msg ->
                        ChatMessage(
                            id = "${seed.id}_${msg.id}",
                            userId = LOCAL_UID,
                            chatId = seed.id,
                            senderName = msg.senderName,
                            fromMe = msg.fromMe,
                            text = msg.text,
                            messageType = msg.type,
                            tickStatus = msg.tick,
                            viaBluetooth = msg.viaBluetooth,
                            mediaMeta = msg.mediaMeta,
                            timeLabel = msg.timeLabel
                        )
                    }
                }
            }

            val statuses = if (cur.statuses.isNotEmpty()) {
                cur.statuses
            } else {
                PakistaniSeedData.statuses.mapIndexed { idx, pair ->
                    val (triple, meta) = pair
                    StatusUpdate(
                        id = "seed_status_$idx",
                        userId = LOCAL_UID,
                        authorName = triple.first,
                        caption = triple.second,
                        statusType = triple.third,
                        bgColorHex = when (idx % 4) {
                            0 -> 0xFF075E54L
                            1 -> 0xFF128C7EL
                            2 -> 0xFF1D9BF0L
                            else -> 0xFF25D366L
                        },
                        viewedByCount = 12L + idx * 7,
                        viewersSummary = meta.second,
                        timeLabel = meta.first,
                        viewed = false
                    )
                }
            }

            val calls = if (cur.calls.isNotEmpty()) cur.calls else PakistaniSeedData.calls.map {
                it.copy(userId = LOCAL_UID)
            }

            val next = Snapshot(
                profile = profile,
                chats = chats,
                messagesByChat = msgMap,
                statuses = statuses,
                calls = calls
            )
            state.value = next
            saveToDiskLocked(next)
        }
    }

    suspend fun sendMessage(
        chatId: String,
        text: String,
        messageType: String,
        viaBluetooth: Boolean,
        replyToText: String?,
        replyToSender: String?,
        mediaMeta: String?,
        scheduledForMillis: Long?
    ) {
        val cleanText = text.trim().take(4000)
        if (cleanText.isEmpty()) throw IllegalArgumentException("Message cannot be empty")
        mutateLocked { cur ->
            val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val newMsg = ChatMessage(
                id = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}",
                userId = LOCAL_UID,
                chatId = chatId,
                senderName = "Me",
                fromMe = true,
                text = cleanText,
                messageType = messageType,
                tickStatus = if (viaBluetooth) "PENDING_SYNC" else "DELIVERED",
                viaBluetooth = viaBluetooth,
                replyToText = replyToText?.take(500),
                replyToSender = replyToSender?.take(80),
                mediaMeta = mediaMeta?.take(500),
                scheduledForMillis = scheduledForMillis,
                timeLabel = timeLabel
            )
            val existingList = cur.messagesByChat[chatId].orEmpty()
            val updatedMap = cur.messagesByChat.toMutableMap().apply {
                put(chatId, existingList + newMsg)
            }
            val preview = if (viaBluetooth) "[Bluetooth] $cleanText" else cleanText
            val nowSort = System.currentTimeMillis()
            val updatedChats = cur.chats.map { chat ->
                if (chat.id == chatId) {
                    chat.copy(
                        lastMessage = preview.take(1000),
                        lastMessageTimeLabel = timeLabel,
                        lastMessageTick = if (viaBluetooth) "BLUETOOTH" else "DELIVERED",
                        unreadCount = 0L,
                        sortOrder = nowSort
                    )
                } else chat
            }
            cur.copy(chats = updatedChats, messagesByChat = updatedMap)
        }
    }

    suspend fun syncPendingBluetoothMessages(chatId: String, pendingIds: List<String>) {
        if (pendingIds.isEmpty()) return
        val idSet = pendingIds.toSet()
        mutateLocked { cur ->
            val updatedMsgs = cur.messagesByChat[chatId].orEmpty().map { msg ->
                if (msg.id in idSet) msg.copy(tickStatus = "READ") else msg
            }
            val updatedMap = cur.messagesByChat.toMutableMap().apply { put(chatId, updatedMsgs) }
            val updatedChats = cur.chats.map { chat ->
                if (chat.id == chatId) chat.copy(lastMessageTick = "READ") else chat
            }
            cur.copy(chats = updatedChats, messagesByChat = updatedMap)
        }
    }

    suspend fun updateChatFlags(chatId: String, updates: Map<String, Any>) {
        mutateLocked { cur ->
            val updatedChats = cur.chats.map { chat ->
                if (chat.id != chatId) chat else applyChatUpdates(chat, updates)
            }
            cur.copy(chats = updatedChats)
        }
    }

    suspend fun updateMessageAction(chatId: String, messageId: String, updates: Map<String, Any>) {
        mutateLocked { cur ->
            val updatedMsgs = cur.messagesByChat[chatId].orEmpty().map { msg ->
                if (msg.id != messageId) msg else applyMessageUpdates(msg, updates)
            }
            val updatedMap = cur.messagesByChat.toMutableMap().apply { put(chatId, updatedMsgs) }
            cur.copy(messagesByChat = updatedMap)
        }
    }

    suspend fun toggleMessageReaction(chatId: String, message: ChatMessage, emoji: String) {
        val (updatedReactions, nextMyReaction) = MessageReactionHelper.computeToggledReactions(
            currentReactions = message.reactions,
            currentMyReaction = message.myReaction,
            emoji = emoji
        )
        updateMessageAction(
            chatId = chatId,
            messageId = message.id,
            updates = mapOf(
                "reactions" to updatedReactions,
                "myReaction" to nextMyReaction
            )
        )
    }

    suspend fun createChatOrGroup(
        title: String,
        phone: String,
        chatType: String,
        bluetoothChat: Boolean,
        communityName: String?
    ): String {
        val cleanTitle = title.trim().take(100)
        if (cleanTitle.isEmpty()) throw IllegalArgumentException("Name is required")
        val chatId = "chat_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        mutateLocked { cur ->
            val newChat = ChatThread(
                id = chatId,
                userId = LOCAL_UID,
                title = cleanTitle,
                phone = phone.take(30),
                avatarColorHex = if (bluetoothChat) 0xFF1D9BF0L else 0xFF128C7EL,
                chatType = chatType,
                lastMessage = if (bluetoothChat) {
                    "Bluetooth Mesh Group created (100m range)"
                } else {
                    "End-to-end encrypted chat started"
                },
                lastMessageTimeLabel = timeLabel,
                lastMessageTick = if (bluetoothChat) "BLUETOOTH" else "SENT",
                unreadCount = 0L,
                online = true,
                lastSeenText = if (bluetoothChat) "Offline Bluetooth Mesh Ready" else "online",
                memberCount = if (chatType == "DIRECT") 2L else 12L,
                communityName = communityName?.take(100),
                bluetoothChat = bluetoothChat,
                encryptionCode = "74910-33219-88401-12904",
                sortOrder = System.currentTimeMillis()
            )
            cur.copy(chats = listOf(newChat) + cur.chats)
        }
        return chatId
    }

    suspend fun postStatus(
        authorName: String,
        caption: String,
        statusType: String,
        bgColorHex: Long
    ) {
        val cleanCaption = caption.trim().take(500)
        if (cleanCaption.isEmpty()) throw IllegalArgumentException("Status caption cannot be empty")
        mutateLocked { cur ->
            val status = StatusUpdate(
                id = "st_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                userId = LOCAL_UID,
                authorName = authorName.take(80),
                caption = cleanCaption,
                statusType = statusType,
                bgColorHex = bgColorHex,
                viewedByCount = 0L,
                viewersSummary = "Just posted • Visible for 24h",
                timeLabel = "Just now",
                viewed = true
            )
            cur.copy(statuses = listOf(status) + cur.statuses)
        }
    }

    suspend fun markStatusViewed(statusId: String, currentCount: Long) {
        mutateLocked { cur ->
            val updated = cur.statuses.map { st ->
                if (st.id == statusId) st.copy(viewed = true, viewedByCount = currentCount + 1L) else st
            }
            cur.copy(statuses = updated)
        }
    }

    suspend fun logCall(
        peerName: String,
        callType: String,
        participantCount: Long,
        recorded: Boolean,
        callLinkCode: String?
    ) {
        val timeLabel = SimpleDateFormat("Today, h:mm a", Locale.getDefault()).format(Date())
        mutateLocked { cur ->
            val call = CallRecord(
                id = "call_${UUID.randomUUID().toString().replace("-", "").take(12)}",
                userId = LOCAL_UID,
                peerName = peerName.take(100),
                callType = callType,
                direction = "OUTGOING",
                durationLabel = if (callLinkCode != null) "Link Active" else "Connected",
                participantCount = participantCount.coerceIn(1L, 32L),
                callLinkCode = callLinkCode?.take(120),
                recorded = recorded,
                timeLabel = timeLabel
            )
            cur.copy(calls = listOf(call) + cur.calls)
        }
    }

    suspend fun updateUserProfileSettings(updates: Map<String, Any>) {
        mutateLocked { cur ->
            val p = cur.profile ?: UserProfile(id = LOCAL_UID, userId = LOCAL_UID)
            val updatedProfile = p.copy(
                displayName = (updates["displayName"] as? String) ?: p.displayName,
                phoneNumber = (updates["phoneNumber"] as? String) ?: p.phoneNumber,
                secondaryPhone = (updates["secondaryPhone"] as? String) ?: p.secondaryPhone,
                about = (updates["about"] as? String) ?: p.about,
                twoStepEnabled = (updates["twoStepEnabled"] as? Boolean) ?: p.twoStepEnabled,
                hideOnline = (updates["hideOnline"] as? Boolean) ?: p.hideOnline,
                hideBlueTicks = (updates["hideBlueTicks"] as? Boolean) ?: p.hideBlueTicks,
                hideLastSeen = (updates["hideLastSeen"] as? Boolean) ?: p.hideLastSeen,
                dataSaver = (updates["dataSaver"] as? Boolean) ?: p.dataSaver,
                autoReplyEnabled = (updates["autoReplyEnabled"] as? Boolean) ?: p.autoReplyEnabled,
                autoReplyText = (updates["autoReplyText"] as? String) ?: p.autoReplyText,
                appLockEnabled = (updates["appLockEnabled"] as? Boolean) ?: p.appLockEnabled
            )
            cur.copy(profile = updatedProfile)
        }
    }

    private suspend fun ensureLoaded() {
        mutex.withLock { loadFromDiskIfNeededLocked() }
    }

    private suspend fun mutateLocked(transform: (Snapshot) -> Snapshot) {
        mutex.withLock {
            loadFromDiskIfNeededLocked()
            val updated = transform(state.value)
            state.value = updated
            saveToDiskLocked(updated)
        }
    }

    private suspend fun loadFromDiskIfNeededLocked() {
        if (loaded) return
        loaded = true
        if (!storeFile.exists()) return
        try {
            val raw = withContext(Dispatchers.IO) { storeFile.readText() }
            if (raw.isNotBlank()) {
                state.value = decodeSnapshot(JSONObject(raw))
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to read local store, starting fresh", e)
        }
    }

    private suspend fun saveToDiskLocked(snapshot: Snapshot) {
        try {
            val json = encodeSnapshot(snapshot).toString()
            withContext(Dispatchers.IO) {
                storeFile.writeText(json)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to persist local store", e)
        }
    }

    private fun applyChatUpdates(chat: ChatThread, updates: Map<String, Any>): ChatThread {
        return chat.copy(
            title = (updates["title"] as? String) ?: chat.title,
            lastMessage = (updates["lastMessage"] as? String) ?: chat.lastMessage,
            lastMessageTimeLabel = (updates["lastMessageTimeLabel"] as? String) ?: chat.lastMessageTimeLabel,
            lastMessageTick = (updates["lastMessageTick"] as? String) ?: chat.lastMessageTick,
            unreadCount = (updates["unreadCount"] as? Number)?.toLong() ?: chat.unreadCount,
            pinned = (updates["pinned"] as? Boolean) ?: chat.pinned,
            archived = (updates["archived"] as? Boolean) ?: chat.archived,
            muted = (updates["muted"] as? Boolean) ?: chat.muted,
            locked = (updates["locked"] as? Boolean) ?: chat.locked,
            online = (updates["online"] as? Boolean) ?: chat.online,
            typing = (updates["typing"] as? Boolean) ?: chat.typing,
            lastSeenText = (updates["lastSeenText"] as? String) ?: chat.lastSeenText,
            disappearingMode = (updates["disappearingMode"] as? String) ?: chat.disappearingMode,
            wallpaperStyle = (updates["wallpaperStyle"] as? String) ?: chat.wallpaperStyle,
            onlyAdminCanSend = (updates["onlyAdminCanSend"] as? Boolean) ?: chat.onlyAdminCanSend,
            bluetoothChat = (updates["bluetoothChat"] as? Boolean) ?: chat.bluetoothChat,
            sortOrder = (updates["sortOrder"] as? Number)?.toLong() ?: chat.sortOrder
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun applyMessageUpdates(msg: ChatMessage, updates: Map<String, Any>): ChatMessage {
        val rawReactions = updates["reactions"] as? Map<String, Any>
        val parsedReactions = rawReactions?.mapNotNull { (k, v) ->
            val count = (v as? Number)?.toLong() ?: return@mapNotNull null
            k to count
        }?.toMap() ?: msg.reactions

        return msg.copy(
            tickStatus = (updates["tickStatus"] as? String) ?: msg.tickStatus,
            viaBluetooth = (updates["viaBluetooth"] as? Boolean) ?: msg.viaBluetooth,
            starred = (updates["starred"] as? Boolean) ?: msg.starred,
            deletedForEveryone = (updates["deletedForEveryone"] as? Boolean) ?: msg.deletedForEveryone,
            deletedForMe = (updates["deletedForMe"] as? Boolean) ?: msg.deletedForMe,
            viewOnceOpened = (updates["viewOnceOpened"] as? Boolean) ?: msg.viewOnceOpened,
            text = (updates["text"] as? String) ?: msg.text,
            reactions = parsedReactions,
            myReaction = (updates["myReaction"] as? String) ?: msg.myReaction
        )
    }

    private fun encodeSnapshot(snap: Snapshot): JSONObject {
        val root = JSONObject()
        snap.profile?.let { p ->
            root.put("profile", JSONObject().apply {
                put("userId", p.userId)
                put("displayName", p.displayName)
                put("phoneNumber", p.phoneNumber)
                put("secondaryPhone", p.secondaryPhone)
                put("about", p.about)
                put("twoStepEnabled", p.twoStepEnabled)
                put("hideOnline", p.hideOnline)
                put("hideBlueTicks", p.hideBlueTicks)
                put("hideLastSeen", p.hideLastSeen)
                put("dataSaver", p.dataSaver)
                put("autoReplyEnabled", p.autoReplyEnabled)
                put("autoReplyText", p.autoReplyText)
                put("appLockEnabled", p.appLockEnabled)
            })
        }

        val chatsArr = JSONArray()
        snap.chats.forEach { c ->
            chatsArr.put(JSONObject().apply {
                put("id", c.id)
                put("userId", c.userId)
                put("title", c.title)
                put("phone", c.phone)
                put("avatarColorHex", c.avatarColorHex)
                put("chatType", c.chatType)
                put("lastMessage", c.lastMessage)
                put("lastMessageTimeLabel", c.lastMessageTimeLabel)
                put("lastMessageTick", c.lastMessageTick)
                put("unreadCount", c.unreadCount)
                put("pinned", c.pinned)
                put("archived", c.archived)
                put("muted", c.muted)
                put("locked", c.locked)
                put("online", c.online)
                put("typing", c.typing)
                put("lastSeenText", c.lastSeenText)
                put("disappearingMode", c.disappearingMode)
                put("wallpaperStyle", c.wallpaperStyle)
                put("memberCount", c.memberCount)
                if (c.communityName != null) put("communityName", c.communityName)
                put("onlyAdminCanSend", c.onlyAdminCanSend)
                put("bluetoothChat", c.bluetoothChat)
                put("encryptionCode", c.encryptionCode)
                put("sortOrder", c.sortOrder)
            })
        }
        root.put("chats", chatsArr)

        val msgObj = JSONObject()
        snap.messagesByChat.forEach { (chatId, list) ->
            val arr = JSONArray()
            list.forEach { m ->
                arr.put(JSONObject().apply {
                    put("id", m.id)
                    put("userId", m.userId)
                    put("chatId", m.chatId)
                    put("senderName", m.senderName)
                    put("fromMe", m.fromMe)
                    put("text", m.text)
                    put("messageType", m.messageType)
                    put("tickStatus", m.tickStatus)
                    put("viaBluetooth", m.viaBluetooth)
                    put("starred", m.starred)
                    put("deletedForEveryone", m.deletedForEveryone)
                    put("deletedForMe", m.deletedForMe)
                    put("viewOnceOpened", m.viewOnceOpened)
                    if (m.replyToText != null) put("replyToText", m.replyToText)
                    if (m.replyToSender != null) put("replyToSender", m.replyToSender)
                    if (m.mediaMeta != null) put("mediaMeta", m.mediaMeta)
                    if (m.scheduledForMillis != null) put("scheduledForMillis", m.scheduledForMillis)
                    put("myReaction", m.myReaction)
                    put("reactions", JSONObject().apply {
                        m.reactions.forEach { (emoji, cnt) -> put(emoji, cnt) }
                    })
                    put("timeLabel", m.timeLabel)
                })
            }
            msgObj.put(chatId, arr)
        }
        root.put("messagesByChat", msgObj)

        val stArr = JSONArray()
        snap.statuses.forEach { s ->
            stArr.put(JSONObject().apply {
                put("id", s.id)
                put("userId", s.userId)
                put("authorName", s.authorName)
                put("caption", s.caption)
                put("statusType", s.statusType)
                put("bgColorHex", s.bgColorHex)
                put("viewedByCount", s.viewedByCount)
                put("viewersSummary", s.viewersSummary)
                put("timeLabel", s.timeLabel)
                put("viewed", s.viewed)
            })
        }
        root.put("statuses", stArr)

        val callArr = JSONArray()
        snap.calls.forEach { c ->
            callArr.put(JSONObject().apply {
                put("id", c.id)
                put("userId", c.userId)
                put("peerName", c.peerName)
                put("callType", c.callType)
                put("direction", c.direction)
                put("durationLabel", c.durationLabel)
                put("participantCount", c.participantCount)
                if (c.callLinkCode != null) put("callLinkCode", c.callLinkCode)
                put("recorded", c.recorded)
                put("timeLabel", c.timeLabel)
            })
        }
        root.put("calls", callArr)
        return root
    }

    private fun decodeSnapshot(root: JSONObject): Snapshot {
        val profile = root.optJSONObject("profile")?.let { p ->
            UserProfile(
                id = LOCAL_UID,
                userId = p.optString("userId", LOCAL_UID),
                displayName = p.optString("displayName", "Whatsup User"),
                phoneNumber = p.optString("phoneNumber", "+92 300 4512980"),
                secondaryPhone = p.optString("secondaryPhone", "+92 321 9876543"),
                about = p.optString("about", "Assalam-o-Alaikum! Using Whatsup Mesh"),
                twoStepEnabled = p.optBoolean("twoStepEnabled", false),
                hideOnline = p.optBoolean("hideOnline", false),
                hideBlueTicks = p.optBoolean("hideBlueTicks", false),
                hideLastSeen = p.optBoolean("hideLastSeen", false),
                dataSaver = p.optBoolean("dataSaver", false),
                autoReplyEnabled = p.optBoolean("autoReplyEnabled", false),
                autoReplyText = p.optString("autoReplyText", "Assalam-o-Alaikum, main abhi masroof hoon."),
                appLockEnabled = p.optBoolean("appLockEnabled", false)
            )
        }

        val chatsArr = root.optJSONArray("chats") ?: JSONArray()
        val chats = (0 until chatsArr.length()).map { idx ->
            val c = chatsArr.getJSONObject(idx)
            ChatThread(
                id = c.optString("id"),
                userId = c.optString("userId", LOCAL_UID),
                title = c.optString("title"),
                phone = c.optString("phone"),
                avatarColorHex = c.optLong("avatarColorHex", 0xFF25D366),
                chatType = c.optString("chatType", "DIRECT"),
                lastMessage = c.optString("lastMessage"),
                lastMessageTimeLabel = c.optString("lastMessageTimeLabel"),
                lastMessageTick = c.optString("lastMessageTick", "READ"),
                unreadCount = c.optLong("unreadCount", 0L),
                pinned = c.optBoolean("pinned", false),
                archived = c.optBoolean("archived", false),
                muted = c.optBoolean("muted", false),
                locked = c.optBoolean("locked", false),
                online = c.optBoolean("online", false),
                typing = c.optBoolean("typing", false),
                lastSeenText = c.optString("lastSeenText"),
                disappearingMode = c.optString("disappearingMode", "OFF"),
                wallpaperStyle = c.optString("wallpaperStyle", "DEFAULT"),
                memberCount = c.optLong("memberCount", 2L),
                communityName = c.optString("communityName").ifBlank { null },
                onlyAdminCanSend = c.optBoolean("onlyAdminCanSend", false),
                bluetoothChat = c.optBoolean("bluetoothChat", false),
                encryptionCode = c.optString("encryptionCode", "88412-90124-55612-77219"),
                sortOrder = c.optLong("sortOrder", 0L)
            )
        }

        val messagesObj = root.optJSONObject("messagesByChat") ?: JSONObject()
        val msgMap = mutableMapOf<String, List<ChatMessage>>()
        messagesObj.keys().forEach { chatId ->
            val arr = messagesObj.optJSONArray(chatId) ?: JSONArray()
            val list = (0 until arr.length()).map { idx ->
                val m = arr.getJSONObject(idx)
                val reactObj = m.optJSONObject("reactions")
                val reactionsMap = mutableMapOf<String, Long>()
                reactObj?.keys()?.forEach { emoji ->
                    reactionsMap[emoji] = reactObj.optLong(emoji, 0L)
                }
                ChatMessage(
                    id = m.optString("id"),
                    userId = m.optString("userId", LOCAL_UID),
                    chatId = m.optString("chatId", chatId),
                    senderName = m.optString("senderName"),
                    fromMe = m.optBoolean("fromMe", true),
                    text = m.optString("text"),
                    messageType = m.optString("messageType", "TEXT"),
                    tickStatus = m.optString("tickStatus", "READ"),
                    viaBluetooth = m.optBoolean("viaBluetooth", false),
                    starred = m.optBoolean("starred", false),
                    deletedForEveryone = m.optBoolean("deletedForEveryone", false),
                    deletedForMe = m.optBoolean("deletedForMe", false),
                    viewOnceOpened = m.optBoolean("viewOnceOpened", false),
                    replyToText = m.optString("replyToText").ifBlank { null },
                    replyToSender = m.optString("replyToSender").ifBlank { null },
                    mediaMeta = m.optString("mediaMeta").ifBlank { null },
                    scheduledForMillis = if (m.has("scheduledForMillis")) m.optLong("scheduledForMillis") else null,
                    reactions = reactionsMap,
                    myReaction = m.optString("myReaction", ""),
                    timeLabel = m.optString("timeLabel", "10:30 AM")
                )
            }
            msgMap[chatId] = list
        }

        val stArr = root.optJSONArray("statuses") ?: JSONArray()
        val statuses = (0 until stArr.length()).map { idx ->
            val s = stArr.getJSONObject(idx)
            StatusUpdate(
                id = s.optString("id"),
                userId = s.optString("userId", LOCAL_UID),
                authorName = s.optString("authorName"),
                caption = s.optString("caption"),
                statusType = s.optString("statusType", "TEXT"),
                bgColorHex = s.optLong("bgColorHex", 0xFF075E54),
                viewedByCount = s.optLong("viewedByCount", 0L),
                viewersSummary = s.optString("viewersSummary"),
                timeLabel = s.optString("timeLabel"),
                viewed = s.optBoolean("viewed", false)
            )
        }

        val callArr = root.optJSONArray("calls") ?: JSONArray()
        val calls = (0 until callArr.length()).map { idx ->
            val c = callArr.getJSONObject(idx)
            CallRecord(
                id = c.optString("id"),
                userId = c.optString("userId", LOCAL_UID),
                peerName = c.optString("peerName"),
                callType = c.optString("callType", "VOICE"),
                direction = c.optString("direction", "OUTGOING"),
                durationLabel = c.optString("durationLabel"),
                participantCount = c.optLong("participantCount", 2L),
                callLinkCode = c.optString("callLinkCode").ifBlank { null },
                recorded = c.optBoolean("recorded", false),
                timeLabel = c.optString("timeLabel")
            )
        }

        return Snapshot(
            profile = profile,
            chats = chats,
            messagesByChat = msgMap,
            statuses = statuses,
            calls = calls
        )
    }
}
