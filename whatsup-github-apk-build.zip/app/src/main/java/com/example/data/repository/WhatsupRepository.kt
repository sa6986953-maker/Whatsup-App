package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.PakistaniSeedData
import com.example.data.model.StatusUpdate
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class WhatsupRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
    private val localStore: LocalWhatsupStore? = null
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        localStore = LocalWhatsupStore(context.applicationContext)
    )

    private fun isLocalMode(uid: String? = null): Boolean {
        return localStore != null && (auth.currentUser == null || uid == "local_device_user")
    }

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)
    private fun chatsCol(uid: String) = userDoc(uid).collection("chats")
    private fun messagesCol(uid: String, chatId: String) = chatsCol(uid).document(chatId).collection("messages")
    private fun statusesCol(uid: String) = userDoc(uid).collection("statuses")
    private fun callsCol(uid: String) = userDoc(uid).collection("calls")

    fun observeUserProfile(uid: String): Flow<UserProfile?> = flow {
        if (isLocalMode(uid)) {
            emitAll(localStore!!.observeProfile())
            return@flow
        }
        val path = "users/$uid"
        emitAll(
            userDoc(uid).snapshots()
                .map { snap ->
                    snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fe == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fe ?: error, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeChats(uid: String): Flow<List<ChatThread>> = flow {
        if (isLocalMode(uid)) {
            emitAll(localStore!!.observeChats())
            return@flow
        }
        val path = "users/$uid/chats"
        emitAll(
            chatsCol(uid)
                .orderBy("sortOrder", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ChatThread::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fe == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fe ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(uid: String, chatId: String): Flow<List<ChatMessage>> = flow {
        if (isLocalMode(uid)) {
            emitAll(localStore!!.observeMessages(chatId))
            return@flow
        }
        val path = "users/$uid/chats/$chatId/messages"
        emitAll(
            messagesCol(uid, chatId)
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fe == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fe ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun getMessagesSnapshot(chatId: String): Result<List<ChatMessage>> {
        if (isLocalMode()) {
            return Result.success(localStore!!.getMessagesSnapshot(chatId))
        }
        var path = "users/unknown/chats/$chatId/messages"
        return try {
            val uid = requireUserId()
            path = "users/$uid/chats/$chatId/messages"
            val snap = messagesCol(uid, chatId)
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .get()
                .await()
            val list = snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    fun observeStatuses(uid: String): Flow<List<StatusUpdate>> = flow {
        if (isLocalMode(uid)) {
            emitAll(localStore!!.observeStatuses())
            return@flow
        }
        val path = "users/$uid/statuses"
        emitAll(
            statusesCol(uid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(StatusUpdate::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fe == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fe ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeCalls(uid: String): Flow<List<CallRecord>> = flow {
        if (isLocalMode(uid)) {
            emitAll(localStore!!.observeCalls())
            return@flow
        }
        val path = "users/$uid/calls"
        emitAll(
            callsCol(uid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CallRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                    if (fe == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fe ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureUserAndSeedPakistaniData(
        displayName: String,
        phoneNumber: String
    ): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.ensureInitialized(displayName, phoneNumber)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var currentPath = "users"
        return try {
            val uid = requireUserId()
            currentPath = "users/$uid"
            val userSnap = userDoc(uid).get().await()
            if (!userSnap.exists()) {
                val safeName = displayName.ifBlank { "Whatsup User" }.take(80)
                val safePhone = phoneNumber.ifBlank { "+92 300 4512980" }.take(30)
                val profilePayload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "phoneNumber" to safePhone,
                    "secondaryPhone" to "+92 321 9876543",
                    "about" to "Assalam-o-Alaikum! Using Whatsup Mesh",
                    "twoStepEnabled" to false,
                    "hideOnline" to false,
                    "hideBlueTicks" to false,
                    "hideLastSeen" to false,
                    "dataSaver" to false,
                    "autoReplyEnabled" to false,
                    "autoReplyText" to "Assalam-o-Alaikum, main abhi masroof hoon. Thori der mein jawab doonga.",
                    "appLockEnabled" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                userDoc(uid).set(profilePayload).await()
            }

            val chatsSnap = chatsCol(uid).limit(1).get().await()
            if (chatsSnap.isEmpty) {
                val batch = db.batch()
                PakistaniSeedData.chats.forEach { seed ->
                    val chatRef = chatsCol(uid).document(seed.id)
                    val chatMap = mapOf(
                        "userId" to uid,
                        "title" to seed.title,
                        "phone" to seed.phone,
                        "avatarColorHex" to seed.colorHex,
                        "chatType" to seed.chatType,
                        "lastMessage" to seed.lastMessage,
                        "lastMessageTimeLabel" to seed.lastTime,
                        "lastMessageTick" to seed.tick,
                        "unreadCount" to seed.unread,
                        "pinned" to seed.pinned,
                        "archived" to false,
                        "muted" to false,
                        "locked" to false,
                        "online" to seed.online,
                        "typing" to false,
                        "lastSeenText" to seed.lastSeen,
                        "disappearingMode" to seed.disappearing,
                        "wallpaperStyle" to "DEFAULT",
                        "memberCount" to seed.memberCount,
                        "communityName" to seed.communityName,
                        "onlyAdminCanSend" to seed.onlyAdminCanSend,
                        "bluetoothChat" to seed.bluetoothChat,
                        "encryptionCode" to "88412-90124-55612-77219",
                        "sortOrder" to seed.sortOrder,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    batch.set(chatRef, chatMap)

                    seed.messages.forEach { msg ->
                        val msgRef = messagesCol(uid, seed.id).document(msg.id)
                        val msgMap = mapOf(
                            "userId" to uid,
                            "chatId" to seed.id,
                            "senderName" to msg.senderName,
                            "fromMe" to msg.fromMe,
                            "text" to msg.text,
                            "messageType" to msg.type,
                            "tickStatus" to msg.tick,
                            "viaBluetooth" to msg.viaBluetooth,
                            "starred" to false,
                            "deletedForEveryone" to false,
                            "deletedForMe" to false,
                            "viewOnceOpened" to false,
                            "mediaMeta" to msg.mediaMeta,
                            "timeLabel" to msg.timeLabel,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        ).filterValues { it != null }
                        batch.set(msgRef, msgMap)
                    }
                }

                PakistaniSeedData.statuses.forEachIndexed { idx, pair ->
                    val (triple, meta) = pair
                    val statusRef = statusesCol(uid).document("seed_status_$idx")
                    val statusMap = mapOf(
                        "userId" to uid,
                        "authorName" to triple.first,
                        "caption" to triple.second,
                        "statusType" to triple.third,
                        "bgColorHex" to when (idx % 4) {
                            0 -> 0xFF075E54L
                            1 -> 0xFF128C7EL
                            2 -> 0xFF1D9BF0L
                            else -> 0xFF25D366L
                        },
                        "viewedByCount" to (12L + idx * 7),
                        "viewersSummary" to meta.second,
                        "timeLabel" to meta.first,
                        "viewed" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    batch.set(statusRef, statusMap)
                }

                PakistaniSeedData.calls.forEach { call ->
                    val callRef = callsCol(uid).document(call.id)
                    val callMap = mapOf(
                        "userId" to uid,
                        "peerName" to call.peerName,
                        "callType" to call.callType,
                        "direction" to call.direction,
                        "durationLabel" to call.durationLabel,
                        "participantCount" to call.participantCount,
                        "callLinkCode" to call.callLinkCode,
                        "recorded" to call.recorded,
                        "timeLabel" to call.timeLabel,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    batch.set(callRef, callMap)
                }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, currentPath)
            Result.failure(e)
        }
    }

    suspend fun sendMessage(
        chatId: String,
        text: String,
        messageType: String = "TEXT",
        viaBluetooth: Boolean = false,
        replyToText: String? = null,
        replyToSender: String? = null,
        mediaMeta: String? = null,
        scheduledForMillis: Long? = null
    ): Result<Unit> {
        val cleanText = text.trim().take(4000)
        if (cleanText.isEmpty()) return Result.failure(IllegalArgumentException("Message cannot be empty"))
        if (isLocalMode()) {
            return try {
                localStore!!.sendMessage(
                    chatId = chatId,
                    text = cleanText,
                    messageType = messageType,
                    viaBluetooth = viaBluetooth,
                    replyToText = replyToText,
                    replyToSender = replyToSender,
                    mediaMeta = mediaMeta,
                    scheduledForMillis = scheduledForMillis
                )
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var docPath = "users/unknown/chats/$chatId/messages"
        return try {
            val uid = requireUserId()
            val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val msgRef = messagesCol(uid, chatId).document(msgId)
            docPath = msgRef.path
            val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val tickStatus = if (viaBluetooth) "PENDING_SYNC" else "DELIVERED"

            val msgPayload = mapOf(
                "userId" to uid,
                "chatId" to chatId,
                "senderName" to "Me",
                "fromMe" to true,
                "text" to cleanText,
                "messageType" to messageType,
                "tickStatus" to tickStatus,
                "viaBluetooth" to viaBluetooth,
                "starred" to false,
                "deletedForEveryone" to false,
                "deletedForMe" to false,
                "viewOnceOpened" to false,
                "replyToText" to replyToText?.take(500),
                "replyToSender" to replyToSender?.take(80),
                "mediaMeta" to mediaMeta?.take(500),
                "scheduledForMillis" to scheduledForMillis,
                "timeLabel" to timeLabel,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            val preview = if (viaBluetooth) "[Bluetooth] $cleanText" else cleanText
            batch.update(
                chatsCol(uid).document(chatId),
                mapOf(
                    "lastMessage" to preview.take(1000),
                    "lastMessageTimeLabel" to timeLabel,
                    "lastMessageTick" to if (viaBluetooth) "BLUETOOTH" else "DELIVERED",
                    "unreadCount" to 0L,
                    "sortOrder" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun syncPendingBluetoothMessages(uid: String, chatId: String, pendingIds: List<String>): Result<Unit> {
        if (pendingIds.isEmpty()) return Result.success(Unit)
        if (isLocalMode(uid)) {
            return try {
                localStore!!.syncPendingBluetoothMessages(chatId, pendingIds)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        val path = "users/$uid/chats/$chatId/messages"
        return try {
            val currentUid = requireUserId()
            check(currentUid == uid)
            val batch = db.batch()
            pendingIds.forEach { msgId ->
                batch.update(
                    messagesCol(uid, chatId).document(msgId),
                    mapOf(
                        "tickStatus" to "READ",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.update(
                chatsCol(uid).document(chatId),
                mapOf(
                    "lastMessageTick" to "READ",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateChatFlags(
        chatId: String,
        updates: Map<String, Any>
    ): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.updateChatFlags(chatId, updates)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/chats/$chatId"
        return try {
            val uid = requireUserId()
            val ref = chatsCol(uid).document(chatId)
            path = ref.path
            val payload = updates.toMutableMap().apply {
                put("updatedAt", FieldValue.serverTimestamp())
            }
            ref.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMessageAction(
        chatId: String,
        messageId: String,
        updates: Map<String, Any>
    ): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.updateMessageAction(chatId, messageId, updates)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/chats/$chatId/messages/$messageId"
        return try {
            val uid = requireUserId()
            val ref = messagesCol(uid, chatId).document(messageId)
            path = ref.path
            val payload = updates.toMutableMap().apply {
                put("updatedAt", FieldValue.serverTimestamp())
            }
            ref.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleMessageReaction(
        chatId: String,
        message: ChatMessage,
        emoji: String
    ): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.toggleMessageReaction(chatId, message, emoji)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        val (updatedReactions, nextMyReaction) =
            com.example.data.model.MessageReactionHelper.computeToggledReactions(
                currentReactions = message.reactions,
                currentMyReaction = message.myReaction,
                emoji = emoji
            )
        return updateMessageAction(
            chatId = chatId,
            messageId = message.id,
            updates = mapOf(
                "reactions" to updatedReactions,
                "myReaction" to nextMyReaction
            )
        )
    }

    suspend fun createChatOrGroup(
        title: String,
        phone: String,
        chatType: String,
        bluetoothChat: Boolean,
        communityName: String? = null
    ): Result<String> {
        val cleanTitle = title.trim().take(100)
        if (cleanTitle.isEmpty()) return Result.failure(IllegalArgumentException("Name is required"))
        if (isLocalMode()) {
            return try {
                Result.success(localStore!!.createChatOrGroup(cleanTitle, phone, chatType, bluetoothChat, communityName))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/chats"
        return try {
            val uid = requireUserId()
            val chatId = "chat_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val ref = chatsCol(uid).document(chatId)
            path = ref.path
            val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val payload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "phone" to phone.take(30),
                "avatarColorHex" to if (bluetoothChat) 0xFF1D9BF0L else 0xFF128C7EL,
                "chatType" to chatType,
                "lastMessage" to if (bluetoothChat) "Bluetooth Mesh Group created (100m range)" else "End-to-end encrypted chat started",
                "lastMessageTimeLabel" to timeLabel,
                "lastMessageTick" to if (bluetoothChat) "BLUETOOTH" else "SENT",
                "unreadCount" to 0L,
                "pinned" to false,
                "archived" to false,
                "muted" to false,
                "locked" to false,
                "online" to true,
                "typing" to false,
                "lastSeenText" to if (bluetoothChat) "Offline Bluetooth Mesh Ready" else "online",
                "disappearingMode" to "OFF",
                "wallpaperStyle" to "DEFAULT",
                "memberCount" to if (chatType == "DIRECT") 2L else 12L,
                "communityName" to communityName?.take(100),
                "onlyAdminCanSend" to false,
                "bluetoothChat" to bluetoothChat,
                "encryptionCode" to "74910-33219-88401-12904",
                "sortOrder" to System.currentTimeMillis(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            ref.set(payload).await()
            Result.success(chatId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun postStatus(
        authorName: String,
        caption: String,
        statusType: String,
        bgColorHex: Long
    ): Result<Unit> {
        val cleanCaption = caption.trim().take(500)
        if (cleanCaption.isEmpty()) return Result.failure(IllegalArgumentException("Status caption cannot be empty"))
        if (isLocalMode()) {
            return try {
                localStore!!.postStatus(authorName, cleanCaption, statusType, bgColorHex)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/statuses"
        return try {
            val uid = requireUserId()
            val statusId = "st_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val ref = statusesCol(uid).document(statusId)
            path = ref.path
            val payload = mapOf(
                "userId" to uid,
                "authorName" to authorName.take(80),
                "caption" to cleanCaption,
                "statusType" to statusType,
                "bgColorHex" to bgColorHex,
                "viewedByCount" to 0L,
                "viewersSummary" to "Just posted • Visible for 24h",
                "timeLabel" to "Just now",
                "viewed" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            ref.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markStatusViewed(statusId: String, currentCount: Long): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.markStatusViewed(statusId, currentCount)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/statuses/$statusId"
        return try {
            val uid = requireUserId()
            val ref = statusesCol(uid).document(statusId)
            path = ref.path
            ref.update(
                mapOf(
                    "viewed" to true,
                    "viewedByCount" to currentCount + 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun logCall(
        peerName: String,
        callType: String,
        participantCount: Long = 2L,
        recorded: Boolean = false,
        callLinkCode: String? = null
    ): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.logCall(peerName, callType, participantCount, recorded, callLinkCode)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown/calls"
        return try {
            val uid = requireUserId()
            val callId = "call_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val ref = callsCol(uid).document(callId)
            path = ref.path
            val timeLabel = SimpleDateFormat("Today, h:mm a", Locale.getDefault()).format(Date())
            val payload = mapOf(
                "userId" to uid,
                "peerName" to peerName.take(100),
                "callType" to callType,
                "direction" to "OUTGOING",
                "durationLabel" to if (callLinkCode != null) "Link Active" else "Connected",
                "participantCount" to participantCount.coerceIn(1L, 32L),
                "callLinkCode" to callLinkCode?.take(120),
                "recorded" to recorded,
                "timeLabel" to timeLabel,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            ref.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfileSettings(updates: Map<String, Any>): Result<Unit> {
        if (isLocalMode()) {
            return try {
                localStore!!.updateUserProfileSettings(updates)
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
        var path = "users/unknown"
        return try {
            val uid = requireUserId()
            val ref = userDoc(uid)
            path = ref.path
            val payload = updates.toMutableMap().apply {
                put("updatedAt", FieldValue.serverTimestamp())
            }
            ref.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
