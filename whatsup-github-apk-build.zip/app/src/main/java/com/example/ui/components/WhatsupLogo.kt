package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupGreen

/**
 * Brand logo for Whatsup:
 * Green WhatsApp-style speech bubble + white phone handset + blue Bluetooth rune inside.
 */
@Composable
fun WhatsupBrandLogo(
    modifier: Modifier = Modifier,
    size: Dp = 88.dp
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val radius = w * 0.42f

        // Green circular speech bubble
        drawCircle(
            color = WhatsupGreen,
            radius = radius,
            center = Offset(cx, cy)
        )

        // Speech bubble tail (bottom-left)
        val tail = Path().apply {
            moveTo(cx - radius * 0.72f, cy + radius * 0.50f)
            lineTo(cx - radius * 0.96f, cy + radius * 0.94f)
            lineTo(cx - radius * 0.36f, cy + radius * 0.80f)
            close()
        }
        drawPath(tail, color = WhatsupGreen)

        // Crisp white outer ring
        drawCircle(
            color = Color.White,
            radius = radius * 0.94f,
            center = Offset(cx, cy),
            style = Stroke(width = w * 0.045f)
        )

        // White handset silhouette arc
        val phonePath = Path().apply {
            moveTo(cx - w * 0.16f, cy - h * 0.18f)
            quadraticTo(cx - w * 0.24f, cy - h * 0.05f, cx - w * 0.10f, cy + h * 0.10f)
            quadraticTo(cx + w * 0.04f, cy + h * 0.23f, cx + w * 0.19f, cy + h * 0.14f)
        }
        drawPath(
            path = phonePath,
            color = Color.White,
            style = Stroke(width = w * 0.095f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Earpiece & mouthpiece caps
        drawCircle(color = Color.White, radius = w * 0.055f, center = Offset(cx - w * 0.15f, cy - h * 0.18f))
        drawCircle(color = Color.White, radius = w * 0.055f, center = Offset(cx + w * 0.19f, cy + h * 0.14f))

        // Blue Bluetooth badge inside phone curve (top-right inside bubble)
        val btCenterX = cx + w * 0.11f
        val btCenterY = cy - h * 0.10f
        val btR = w * 0.13f
        drawCircle(
            color = Color.White,
            radius = btR,
            center = Offset(btCenterX, btCenterY)
        )
        drawCircle(
            color = BluetoothBlue,
            radius = btR * 0.85f,
            center = Offset(btCenterX, btCenterY)
        )

        // Bluetooth Rune inside blue circle
        val s = btR * 0.45f
        val rune = Path().apply {
            moveTo(btCenterX, btCenterY - s)
            lineTo(btCenterX, btCenterY + s)
            moveTo(btCenterX - s * 0.65f, btCenterY - s * 0.45f)
            lineTo(btCenterX + s * 0.65f, btCenterY + s * 0.45f)
            lineTo(btCenterX, btCenterY + s)
            moveTo(btCenterX, btCenterY - s)
            lineTo(btCenterX + s * 0.65f, btCenterY - s * 0.45f)
            lineTo(btCenterX - s * 0.65f, btCenterY + s * 0.45f)
        }
        drawPath(
            path = rune,
            color = Color.White,
            style = Stroke(width = w * 0.024f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}
