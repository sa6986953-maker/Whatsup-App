package com.example.ui.screens.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatMessage
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.AiPanelState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsupAiSheet(
    chatTitle: String,
    messages: List<ChatMessage>,
    selectedMessageForTranslate: ChatMessage?,
    aiViewModel: AiAssistantViewModel,
    onInsertReply: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val aiState by aiViewModel.state.collectAsStateWithLifecycle()
    var customPrompt by remember { mutableStateOf("") }
    var targetLanguage by remember { mutableStateOf("Urdu (Nastaliq + Roman)") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(WhatsupGreen.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "Whatsup AI",
                        tint = WhatsupDarkGreen
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Whatsup AI Assistant",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Powered by Gemini • Summarize, Translate & Write Replies",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistChip(
                    onClick = { aiViewModel.summarizeChat(chatTitle, messages) },
                    label = { Text("Summarize Chat") },
                    leadingIcon = {
                        Icon(Icons.Filled.Summarize, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("ai_summarize_chip")
                )
                AssistChip(
                    onClick = { aiViewModel.draftReply(chatTitle, messages, "polite Roman Urdu") },
                    label = { Text("Reply (Roman Urdu)") },
                    leadingIcon = {
                        Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("ai_reply_urdu_chip")
                )
                AssistChip(
                    onClick = { aiViewModel.draftReply(chatTitle, messages, "professional English") },
                    label = { Text("Reply (English)") },
                    modifier = Modifier.testTag("ai_reply_english_chip")
                )
                AssistChip(
                    onClick = {
                        val textToTranslate = selectedMessageForTranslate?.text
                            ?: messages.lastOrNull { !it.deletedForMe && !it.deletedForEveryone }?.text
                            ?: "Assalam-o-Alaikum, kya haal hain?"
                        aiViewModel.translateMessage(textToTranslate, targetLanguage)
                    },
                    label = { Text("Translate Last Msg") },
                    leadingIcon = {
                        Icon(Icons.Filled.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("ai_translate_chip")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Language selector chips for translation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Urdu", "English", "Arabic", "Punjabi", "Spanish").forEach { lang ->
                    OutlinedButton(
                        onClick = {
                            targetLanguage = lang
                            val textToTranslate = selectedMessageForTranslate?.text
                                ?: messages.lastOrNull { !it.deletedForMe && !it.deletedForEveryone }?.text
                                ?: "Assalam-o-Alaikum"
                            aiViewModel.translateMessage(textToTranslate, lang)
                        },
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("→ $lang", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Result Card
            when (val s = aiState) {
                is AiPanelState.Idle -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Tap Summarize Chat, Translate, or Write Reply above — or ask Whatsup AI anything below.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
                is AiPanelState.Loading -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = WhatsupGreen)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("Whatsup AI is thinking...", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                is AiPanelState.Streaming -> {
                    AiOutputCard(
                        title = s.taskTitle,
                        body = s.text,
                        streaming = true,
                        onUseAsReply = null
                    )
                }
                is AiPanelState.Success -> {
                    AiOutputCard(
                        title = s.taskTitle,
                        body = s.text,
                        streaming = false,
                        onUseAsReply = {
                            onInsertReply(s.text)
                            onDismiss()
                        }
                    )
                }
                is AiPanelState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = s.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Custom Prompt Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = customPrompt,
                    onValueChange = { customPrompt = it },
                    placeholder = { Text("Ask Whatsup AI about this chat...") },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_custom_prompt_input")
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (customPrompt.isNotBlank()) {
                            aiViewModel.askAssistant(customPrompt, chatTitle, messages)
                            customPrompt = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(WhatsupGreen)
                        .testTag("ai_send_prompt_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Ask AI",
                        tint = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

@Composable
private fun AiOutputCard(
    title: String,
    body: String,
    streaming: Boolean,
    onUseAsReply: (() -> Unit)?
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = BluetoothBlue,
                    modifier = Modifier.weight(1f)
                )
                if (streaming) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = body, style = MaterialTheme.typography.bodyMedium)
            if (onUseAsReply != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onUseAsReply,
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                    modifier = Modifier.height(40.dp)
                ) {
                    Text("Use in Message Box")
                }
            }
        }
    }
}
