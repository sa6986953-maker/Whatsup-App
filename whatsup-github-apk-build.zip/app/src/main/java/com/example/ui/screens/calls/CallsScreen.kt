package com.example.ui.screens.calls

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PresentToAll
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.SignalCellularAlt1Bar
import androidx.compose.material.icons.filled.SignalCellularAlt2Bar
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.CallSignalQuality
import com.example.core.LatencyReading
import com.example.core.NetworkLatencyMonitor
import com.example.data.model.CallRecord
import com.example.data.model.UiState
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.MissedCallRed
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import java.util.UUID

data class ActiveCallSession(
    val title: String,
    val isVideo: Boolean,
    val isGroupConference: Boolean,
    val participantCount: Int,
    val lowDataMode: Boolean
)

@Composable
fun CallsScreen(
    callsState: UiState<List<CallRecord>>,
    dataSaverDefault: Boolean,
    onCreateCallLink: (String) -> Unit,
    onLaunchCall: (peerName: String, callType: String, participantCount: Int) -> Unit
) {
    var createdLink by remember { mutableStateOf<String?>(null) }
    var lowDataMode by remember(dataSaverDefault) { mutableStateOf(dataSaverDefault) }

    when (callsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = WhatsupGreen)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(callsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "call_link_card") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                val code = "whatsup.pk/join/${UUID.randomUUID().toString().take(6)}"
                                createdLink = code
                                onCreateCallLink(code)
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(WhatsupGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Link, contentDescription = "Create call link", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Create call link", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = createdLink ?: "Share a link for up to 16 video or 32 voice participants",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (createdLink != null) WhatsupGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Conference Call Quick-Launch Card (Zoom + WhatsApp combined)
                item(key = "conference_launcher") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Conference & HD Calls",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                FilterChip(
                                    selected = lowDataMode,
                                    onClick = { lowDataMode = !lowDataMode },
                                    label = { Text(if (lowDataMode) "Low Data: ON" else "HD Voice") }
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onLaunchCall("16-Person Video Conference", "GROUP_VIDEO", 16) },
                                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("start_16_video_conference_button")
                                ) {
                                    Icon(Icons.Filled.Videocam, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("16 Video", maxLines = 1)
                                }
                                Button(
                                    onClick = { onLaunchCall("32-Person Voice Room", "GROUP_VOICE", 32) },
                                    colors = ButtonDefaults.buttonColors(containerColor = BluetoothBlue),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("start_32_voice_conference_button")
                                ) {
                                    Icon(Icons.Filled.Groups, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("32 Voice", maxLines = 1)
                                }
                            }
                        }
                    }
                }

                item(key = "recent_calls_title") {
                    Text(
                        text = "Recent",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                items(callsState.data, key = { it.id }) { call ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                onLaunchCall(call.peerName, call.callType, call.participantCount.toInt())
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(WhatsupDarkGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = call.peerName.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = call.peerName,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (call.direction == "MISSED") MissedCallRed else MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (call.direction == "OUTGOING") Icons.AutoMirrored.Filled.CallMade else Icons.AutoMirrored.Filled.CallReceived,
                                    contentDescription = null,
                                    tint = if (call.direction == "MISSED") MissedCallRed else WhatsupGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${call.timeLabel} • ${call.durationLabel}" + if (call.recorded) " • REC" else "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(onClick = {
                            onLaunchCall(call.peerName, call.callType, call.participantCount.toInt())
                        }) {
                            Icon(
                                imageVector = if (call.callType.contains("VIDEO")) Icons.Filled.Videocam else Icons.Filled.Call,
                                contentDescription = "Call",
                                tint = WhatsupGreen
                            )
                        }
                    }
                }

                item(key = "calls_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }
}

@Composable
fun ActiveCallOverlay(
    session: ActiveCallSession,
    onEndCall: (recorded: Boolean) -> Unit
) {
    BackHandler { onEndCall(false) }

    var muted by remember { mutableStateOf(false) }
    var beautyFilter by remember { mutableStateOf(false) }
    var backgroundBlur by remember { mutableStateOf(true) }
    var screenShare by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var lowData by remember { mutableStateOf(session.lowDataMode) }

    val avPermissions = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        val perms = if (session.isVideo) {
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }
        avPermissions.launch(perms)
    }

    val context = LocalContext.current
    val latencyReading by produceState(
        initialValue = LatencyReading(latencyMs = null, quality = CallSignalQuality.FAIR, transportLabel = "Probing"),
        key1 = context
    ) {
        NetworkLatencyMonitor.observeLatency(context).collect { reading ->
            value = reading
        }
    }

    val targetSignalColor = when (latencyReading.quality) {
        CallSignalQuality.GOOD -> WhatsupGreen
        CallSignalQuality.FAIR -> Color(0xFFFFC107)
        CallSignalQuality.POOR -> Color(0xFFE53935)
    }
    val signalColor by animateColorAsState(
        targetValue = targetSignalColor,
        animationSpec = tween(durationMillis = 350),
        label = "call_signal_color"
    )
    val signalIcon = when (latencyReading.quality) {
        CallSignalQuality.GOOD -> Icons.Filled.SignalCellularAlt
        CallSignalQuality.FAIR -> Icons.Filled.SignalCellularAlt2Bar
        CallSignalQuality.POOR -> Icons.Filled.SignalCellularAlt1Bar
    }

    val conferenceParticipants = remember(session.participantCount) {
        listOf(
            "Me (Host)", "Ammi ❤️", "Abbu", "Ali Raza",
            "Ayesha Khan", "Bilal Bhai", "Hamza Tariq", "Zainab Bibi",
            "Usman", "Fatima Baji", "Saad", "Hira",
            "Tariq", "Nadia", "Kamran", "Sana"
        ).take(session.participantCount.coerceIn(2, 16))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0B141A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Call Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = session.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = buildString {
                            append(if (session.isVideo) "HD Video Call" else "HD Voice Call")
                            append(" • ${session.participantCount} participants")
                            if (lowData) append(" • Low Data Mode")
                            if (recording) append(" • ● REC")
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = WhatsupGreen
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Real-time Network Latency Signal Strength Indicator (Green / Yellow / Red)
                val latencyLabel = latencyReading.latencyMs?.let { "${it}ms" } ?: latencyReading.transportLabel
                Surface(
                    color = signalColor.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, signalColor.copy(alpha = 0.7f)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.testTag("call_signal_strength_indicator")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = signalIcon,
                            contentDescription = "Signal strength ${latencyReading.quality.label}: $latencyLabel",
                            tint = signalColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text(
                                text = latencyReading.quality.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = signalColor
                            )
                            Text(
                                text = latencyLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 16-Tile Conference Grid or 1-to-1 View
            if (session.isGroupConference && session.isVideo) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(conferenceParticipants) { name ->
                        Surface(
                            color = Color(0xFF1F2C34),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.85f)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(WhatsupDarkGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = name,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(6.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1A2730)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(WhatsupDarkGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = session.title.take(1).uppercase(),
                                style = MaterialTheme.typography.headlineLarge,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = if (screenShare) "Sharing Screen Live..." else "End-to-End Encrypted • Connected",
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (beautyFilter || backgroundBlur) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = listOfNotNull(
                                    if (beautyFilter) "Beauty Filter ON" else null,
                                    if (backgroundBlur) "Background Blur ON" else null
                                ).joinToString(" • "),
                                color = WhatsupGreen,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Feature Toggles Row: Beauty Filter, Blur, Screen Share, Record, Low Data
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CallFeatureToggle(Icons.Filled.AutoFixHigh, "Beauty", beautyFilter) { beautyFilter = !beautyFilter }
                CallFeatureToggle(Icons.Filled.BlurOn, "Blur BG", backgroundBlur) { backgroundBlur = !backgroundBlur }
                CallFeatureToggle(Icons.Filled.PresentToAll, "Share", screenShare) { screenShare = !screenShare }
                CallFeatureToggle(Icons.Filled.FiberManualRecord, "Record", recording, activeTint = MissedCallRed) { recording = !recording }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Primary Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { muted = !muted },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (muted) Color.White else Color(0xFF2A3942))
                ) {
                    Icon(
                        imageVector = if (muted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        contentDescription = "Mute",
                        tint = if (muted) Color.Black else Color.White
                    )
                }

                IconButton(
                    onClick = { lowData = !lowData },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (lowData) BluetoothBlue else Color(0xFF2A3942))
                ) {
                    Text(
                        text = "LOW",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                IconButton(
                    onClick = { onEndCall(recording) },
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(MissedCallRed)
                        .testTag("end_call_button")
                ) {
                    Icon(Icons.Filled.CallEnd, contentDescription = "End Call", tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
        }
    }
}

@Composable
private fun CallFeatureToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    activeTint: Color = WhatsupGreen,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (active) activeTint else Color.White.copy(alpha = 0.7f),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) activeTint else Color.White.copy(alpha = 0.7f)
        )
    }
}
