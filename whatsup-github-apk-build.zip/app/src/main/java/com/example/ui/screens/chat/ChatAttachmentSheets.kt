package com.example.ui.screens.chat

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.ScheduleSend
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupGreen

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AttachMediaSheet(
    viewOnceEnabled: Boolean,
    onToggleViewOnce: () -> Unit,
    onSendMediaMessage: (text: String, messageType: String, mediaMeta: String) -> Unit,
    onOpenScheduleDialog: () -> Unit,
    onDismiss: () -> Unit
) {
    var showPollDialog by remember { mutableStateOf(false) }
    var showEventDialog by remember { mutableStateOf(false) }
    var showContactPicker by remember { mutableStateOf(false) }

    // Zero-permission Photo Picker (Google Play Compliant)
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "IMAGE_HD"
            val meta = if (viewOnceEnabled) {
                "View Once HD Photo • Screenshot Protected"
            } else {
                "HD Original Quality (No Compression) • ${uri.lastPathSegment ?: "Photo"}"
            }
            onSendMediaMessage("📷 HD Photo", msgType, meta)
            onDismiss()
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "VIDEO"
            val meta = "Video up to 2GB • ${uri.lastPathSegment ?: "Clip.mp4"}"
            onSendMediaMessage("🎥 Video", msgType, meta)
            onDismiss()
        }
    }

    // Storage Access Framework for PDF, Word, APK, ZIP, any file
    val documentPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onSendMediaMessage(
                "📄 Document Attached",
                "DOCUMENT",
                "File (PDF/Word/APK/ZIP) • ${uri.lastPathSegment ?: "Document"}"
            )
            onDismiss()
        }
    }

    val coarseLocationPermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val locText = if (granted) {
            "📍 Kahror Pakka, Punjab (Approx. Location Shared)"
        } else {
            "📍 Shared Approximate Pin (Location permission declined)"
        }
        onSendMediaMessage(locText, "LOCATION", "Live Approximate Location • 100m accuracy")
        onDismiss()
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Share Media & Tools",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedButton(
                    onClick = onToggleViewOnce,
                    modifier = Modifier.testTag("view_once_toggle_button")
                ) {
                    Text(
                        text = if (viewOnceEnabled) "① View Once: ON" else "① View Once: OFF",
                        color = if (viewOnceEnabled) WhatsupGreen else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                maxItemsInEachRow = 4,
                horizontalArrangement = Arrangement.SpaceAround,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                AttachOption(Icons.Filled.PhotoLibrary, "HD Photo", Color(0xFF8E24AA)) {
                    photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                AttachOption(Icons.Filled.Videocam, "2GB Video", Color(0xFFD81B60)) {
                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }
                AttachOption(Icons.Filled.Description, "Document", Color(0xFF5E35B1)) {
                    documentPicker.launch(arrayOf("*/*"))
                }
                AttachOption(Icons.Filled.LocationOn, "Location", WhatsupGreen) {
                    coarseLocationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                }
                AttachOption(Icons.Filled.Contacts, "Contact", BluetoothBlue) {
                    showContactPicker = true
                }
                AttachOption(Icons.Filled.Poll, "Poll", Color(0xFF00897B)) {
                    showPollDialog = true
                }
                AttachOption(Icons.Filled.Event, "Event", Color(0xFFEF6C00)) {
                    showEventDialog = true
                }
                AttachOption(Icons.Filled.ScheduleSend, "Schedule", Color(0xFF3949AB)) {
                    onDismiss()
                    onOpenScheduleDialog()
                }
            }

            Spacer(modifier = Modifier.height(22.dp))
        }
    }

    if (showPollDialog) {
        var question by remember { mutableStateOf("") }
        var optionA by remember { mutableStateOf("Haan") }
        var optionB by remember { mutableStateOf("Nahi") }
        AlertDialog(
            onDismissRequest = { showPollDialog = false },
            title = { Text("Create Chat Poll") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text("Question") })
                    OutlinedTextField(value = optionA, onValueChange = { optionA = it }, label = { Text("Option 1") })
                    OutlinedTextField(value = optionB, onValueChange = { optionB = it }, label = { Text("Option 2") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (question.isNotBlank()) {
                        onSendMediaMessage(
                            "📊 Poll: $question",
                            "POLL",
                            "$optionA (0 votes) • $optionB (0 votes)"
                        )
                        showPollDialog = false
                        onDismiss()
                    }
                }) { Text("Send Poll") }
            },
            dismissButton = {
                TextButton(onClick = { showPollDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showEventDialog) {
        var eventTitle by remember { mutableStateOf("") }
        var eventTime by remember { mutableStateOf("Tonight 9:00 PM") }
        AlertDialog(
            onDismissRequest = { showEventDialog = false },
            title = { Text("Create Group Event") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = eventTitle, onValueChange = { eventTitle = it }, label = { Text("Event Title") })
                    OutlinedTextField(value = eventTime, onValueChange = { eventTime = it }, label = { Text("Date & Time") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (eventTitle.isNotBlank()) {
                        onSendMediaMessage(
                            "📅 Event: $eventTitle",
                            "EVENT",
                            "$eventTime • Tap to RSVP"
                        )
                        showEventDialog = false
                        onDismiss()
                    }
                }) { Text("Create Event") }
            },
            dismissButton = {
                TextButton(onClick = { showEventDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showContactPicker) {
        AlertDialog(
            onDismissRequest = { showContactPicker = false },
            title = { Text("Share Contact Card") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "Ali Raza (+92 302 4455661)",
                        "Usman Electrician (+92 308 1122009)",
                        "Bilal Bhai (+92 345 2233445)"
                    ).forEach { contact ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSendMediaMessage("👤 Contact: $contact", "CONTACT", "Verified Whatsup Contact")
                                    showContactPicker = false
                                    onDismiss()
                                }
                        ) {
                            Text(contact, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showContactPicker = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun AttachOption(
    icon: ImageVector,
    label: String,
    bgColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(74.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun EmojiStickersGifTray(
    onPickEmoji: (String) -> Unit,
    onPickStickerOrGif: (text: String, type: String, meta: String) -> Unit
) {
    var activeTab by remember { mutableStateOf("EMOJI") }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("EMOJI", "STICKERS", "GIFS").forEach { tab ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (activeTab == tab) WhatsupGreen else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.clickable { activeTab = tab }
                ) {
                    Text(
                        text = tab,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (activeTab == tab) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        when (activeTab) {
            "EMOJI" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    listOf("❤️", "😂", "🤲", "🇵🇰", "👍", "🔥", "🌙", "☕").forEach { emoji ->
                        Text(
                            text = emoji,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier
                                .clickable { onPickEmoji(emoji) }
                                .padding(6.dp)
                        )
                    }
                }
            }
            "STICKERS" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Assalam-o-Alaikum 🌙", "JazakAllah ✨", "Chai Peene Chalen ☕", "Mashallah 💚").forEach { sticker ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.clickable {
                                onPickStickerOrGif(sticker, "STICKER", "Whatsup Sticker Pack")
                            }
                        ) {
                            Text(
                                text = sticker,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
            "GIFS" -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("[GIF] Cricket Sixer! 🏏", "[GIF] Waah Kya Baat Hai 👏", "[GIF] Chai Time ☕").forEach { gif ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BluetoothBlue.copy(alpha = 0.14f),
                            modifier = Modifier.clickable {
                                onPickStickerOrGif(gif, "GIF", "Animated GIF • Low-Data Mode")
                            }
                        ) {
                            Text(
                                text = gif,
                                style = MaterialTheme.typography.labelSmall,
                                color = BluetoothBlue,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
