package com.example.ui.screens.chat

import android.Manifest
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.core.BiometricAuthHelper
import com.example.core.MeshStatus
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.MessageReactionHelper
import com.example.data.model.UiState
import com.example.ui.components.ContactAvatar
import com.example.ui.components.EncryptionNoticeBanner
import com.example.ui.components.MessageTickBadge
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkChatCanvas
import com.example.ui.theme.DarkReceivedBubble
import com.example.ui.theme.DarkSentBubble
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.GoldStar
import com.example.ui.theme.LightChatCanvas
import com.example.ui.theme.LightReceivedBubble
import com.example.ui.theme.LightSentBubble
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.InlineSummaryState
import com.example.ui.viewmodel.SuggestedRepliesState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chat: ChatThread,
    messagesState: UiState<List<ChatMessage>>,
    meshStatus: MeshStatus,
    darkMode: Boolean,
    hideBlueTicks: Boolean,
    hideOnline: Boolean,
    hideLastSeen: Boolean,
    allChats: List<ChatThread>,
    onBack: () -> Unit,
    onToggleBluetoothMode: (Boolean) -> Unit,
    onSyncBluetooth: (List<ChatMessage>) -> Unit,
    onSendMessage: (
        text: String,
        messageType: String,
        replyToText: String?,
        replyToSender: String?,
        mediaMeta: String?,
        scheduledMinutesDelay: Int?
    ) -> Unit,
    onForwardMessage: (targetChatId: String, msg: ChatMessage) -> Unit,
    onStarMessage: (ChatMessage) -> Unit,
    onToggleReaction: (ChatMessage, String) -> Unit,
    onDeleteForMe: (String) -> Unit,
    onDeleteForEveryone: (String) -> Unit,
    onOpenViewOnce: (String) -> Unit,
    onSetDisappearing: (String) -> Unit,
    onSetWallpaper: (String) -> Unit,
    onToggleChatLock: () -> Unit,
    onOpenAiAssistant: (ChatMessage?) -> Unit,
    inlineSummaryState: InlineSummaryState,
    suggestedRepliesState: SuggestedRepliesState,
    onSummarizeThread: () -> Unit,
    onDismissSummary: () -> Unit,
    onGenerateSuggestions: () -> Unit,
    onDismissSuggestions: () -> Unit,
    onOpenExportChat: () -> Unit,
    onStartVoiceCall: () -> Unit,
    onStartVideoCall: () -> Unit
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var replyTarget by remember { mutableStateOf<ChatMessage?>(null) }
    var showMenu by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    var showEmojiTray by remember { mutableStateOf(false) }
    var viewOnceEnabled by remember { mutableStateOf(false) }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showDisappearingDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }
    var viewOncePreviewMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var forwardTargetMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var inChatSearchActive by remember(chat.id) { mutableStateOf(false) }
    var inChatSearchQuery by remember(chat.id) { mutableStateOf("") }
    var biometricNotice by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (inChatSearchActive) {
            inChatSearchActive = false
            inChatSearchQuery = ""
        } else {
            onBack()
        }
    }

    val listState = rememberLazyListState()
    val messages = (messagesState as? UiState.Success)?.data ?: emptyList()

    val visibleMessages = remember(messages, inChatSearchActive, inChatSearchQuery) {
        val nonDeleted = messages.filter { !it.deletedForMe }
        val q = inChatSearchQuery.trim()
        if (inChatSearchActive && q.isNotEmpty()) {
            nonDeleted.filter { msg ->
                msg.text.contains(q, ignoreCase = true) ||
                    msg.senderName.contains(q, ignoreCase = true) ||
                    (msg.mediaMeta?.contains(q, ignoreCase = true) == true)
            }
        } else {
            nonDeleted
        }
    }

    val lastReceivedMsgId = remember(messages) {
        messages.lastOrNull { !it.deletedForMe && !it.deletedForEveryone && !it.fromMe }?.id
    }
    var lastAutoSuggestedKey by remember(chat.id) { mutableStateOf<String?>(null) }

    LaunchedEffect(chat.id, lastReceivedMsgId, meshStatus.networkOnline, chat.onlyAdminCanSend) {
        val targetId = lastReceivedMsgId
        if (targetId != null && !chat.onlyAdminCanSend && meshStatus.networkOnline) {
            val triggerKey = "${chat.id}:$targetId"
            if (lastAutoSuggestedKey != triggerKey) {
                lastAutoSuggestedKey = triggerKey
                onGenerateSuggestions()
            }
        }
    }

    LaunchedEffect(visibleMessages.size, inChatSearchQuery) {
        if (visibleMessages.isNotEmpty() && !inChatSearchActive) {
            listState.animateScrollToItem(visibleMessages.lastIndex)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            isRecordingAudio = true
        } else {
            onSendMessage("🎤 Voice note (0:08)", "VOICE", null, null, "Voice message • 0:08", null)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onSendMessage("📸 Camera HD Shot", if (viewOnceEnabled) "VIEW_ONCE" else "IMAGE_HD", null, null, "Original Camera Photo", null)
            viewOnceEnabled = false
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        cameraLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val topBarColor = if (darkMode) DarkTopBar else WhatsupDarkGreen
    val canvasBgColor = when {
        chat.wallpaperStyle == "MIDNIGHT" -> Color(0xFF0A1218)
        chat.wallpaperStyle == "EMERALD_TINT" -> Color(0xFFDCEEE2)
        darkMode -> DarkChatCanvas
        else -> LightChatCanvas
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(canvasBgColor)
            .navigationBarsPadding()
            .imePadding()
    ) {
        // Authentic WhatsApp Top Bar
        Surface(color = topBarColor, shadowElevation = 3.dp) {
            Column(modifier = Modifier.statusBarsPadding()) {
                if (inChatSearchActive) {
                    // WhatsApp-style inline Search Bar in the top chat header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                inChatSearchActive = false
                                inChatSearchQuery = ""
                            },
                            modifier = Modifier.testTag("chat_search_close_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close search", tint = Color.White)
                        }
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = Color.White.copy(alpha = 0.14f),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                    if (inChatSearchQuery.isEmpty()) {
                                        Text(
                                            text = "Search messages...",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White.copy(alpha = 0.7f)
                                        )
                                    }
                                    BasicTextField(
                                        value = inChatSearchQuery,
                                        onValueChange = { inChatSearchQuery = it },
                                        singleLine = true,
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                                        cursorBrush = SolidColor(WhatsupGreen),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("chat_search_input")
                                    )
                                }
                                if (inChatSearchQuery.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = WhatsupGreen.copy(alpha = 0.28f),
                                        modifier = Modifier.padding(end = 4.dp)
                                    ) {
                                        Text(
                                            text = "${visibleMessages.size}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                .testTag("chat_search_match_count")
                                        )
                                    }
                                }
                            }
                        }
                        if (inChatSearchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { inChatSearchQuery = "" },
                                modifier = Modifier.testTag("chat_search_clear_button")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Clear search query", tint = Color.White)
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("chat_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        ContactAvatar(
                            name = chat.title,
                            colorHex = chat.avatarColorHex,
                            chatType = chat.chatType,
                            online = chat.online && !hideOnline,
                            size = 38.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = chat.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                if (chat.locked) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Filled.Lock,
                                        contentDescription = "Biometric Lock Active",
                                        tint = WhatsupGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            val subtitle = when {
                                isRecordingAudio -> "recording audio..."
                                meshStatus.offlineModeActive -> "Offline Bluetooth Mesh (100m)"
                                chat.typing -> "typing..."
                                chat.online && !hideOnline -> "online"
                                hideLastSeen -> "End-to-End Encrypted"
                                else -> chat.lastSeenText
                            }
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (meshStatus.offlineModeActive) Color(0xFF8CD3FF) else Color.White.copy(alpha = 0.85f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Glowing Offline Bluetooth Mode indicator with 'Peer-to-peer' status tooltip
                        val coroutineScope = rememberCoroutineScope()
                        val tooltipState = rememberTooltipState(isPersistent = false)
                        val glowTransition = rememberInfiniteTransition(label = "offline_bt_glow")
                        val glowAlpha by glowTransition.animateFloat(
                            initialValue = 0.35f,
                            targetValue = 0.92f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "offline_bt_glow_alpha"
                        )
                        val glowRadiusFactor by glowTransition.animateFloat(
                            initialValue = 0.72f,
                            targetValue = 1.08f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "offline_bt_glow_radius"
                        )

                        AnimatedVisibility(
                            visible = meshStatus.offlineModeActive,
                            enter = fadeIn(tween(220)),
                            exit = fadeOut(tween(200))
                        ) {
                            TooltipBox(
                                positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
                                tooltip = {
                                    PlainTooltip(
                                        containerColor = Color(0xFF0E2942),
                                        contentColor = Color.White,
                                        modifier = Modifier.testTag("chat_p2p_tooltip")
                                    ) {
                                        Text(
                                            text = "Peer-to-peer • Offline Bluetooth Mode (100m)",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                },
                                state = tooltipState
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0xFF133A5E),
                                    border = BorderStroke(1.2.dp, Color(0xFF63D2FF).copy(alpha = glowAlpha)),
                                    modifier = Modifier
                                        .padding(end = 2.dp)
                                        .drawBehind {
                                            drawCircle(
                                                brush = Brush.radialGradient(
                                                    colors = listOf(
                                                        Color(0xFF53BDEB).copy(alpha = glowAlpha * 0.65f),
                                                        Color.Transparent
                                                    )
                                                ),
                                                radius = size.maxDimension * 0.78f * glowRadiusFactor
                                            )
                                        }
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable {
                                            coroutineScope.launch { tooltipState.show() }
                                        }
                                        .testTag("chat_offline_p2p_indicator")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFF63D2FF).copy(alpha = glowAlpha))
                                        )
                                        Text(
                                            text = "P2P",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF9CE2FF),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Bluetooth Offline Mode Toggle
                        IconButton(
                            onClick = { onToggleBluetoothMode(!meshStatus.offlineModeActive) },
                            modifier = Modifier
                                .then(
                                    if (meshStatus.offlineModeActive) {
                                        Modifier.drawBehind {
                                            drawCircle(
                                                brush = Brush.radialGradient(
                                                    colors = listOf(
                                                        Color(0xFF53BDEB).copy(alpha = glowAlpha * 0.45f),
                                                        Color.Transparent
                                                    )
                                                ),
                                                radius = size.minDimension * 0.65f * glowRadiusFactor
                                            )
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                                .testTag("chat_bluetooth_toggle")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.BluetoothConnected,
                                contentDescription = "Toggle Bluetooth Offline Mode",
                                tint = if (meshStatus.offlineModeActive) Color(0xFF63D2FF) else Color.White.copy(alpha = 0.75f)
                            )
                        }
                        IconButton(
                            onClick = { inChatSearchActive = true },
                            modifier = Modifier.testTag("chat_search_button")
                        ) {
                            Icon(Icons.Filled.Search, contentDescription = "Search messages in chat", tint = Color.White)
                        }
                        IconButton(onClick = onStartVideoCall, modifier = Modifier.testTag("chat_video_call_button")) {
                            Icon(Icons.Filled.Videocam, contentDescription = "Video Call", tint = Color.White)
                        }
                        IconButton(onClick = onStartVoiceCall, modifier = Modifier.testTag("chat_voice_call_button")) {
                            Icon(Icons.Filled.Call, contentDescription = "Voice Call", tint = Color.White)
                        }

                        Box {
                            IconButton(onClick = { showMenu = true }, modifier = Modifier.testTag("chat_more_menu")) {
                                Icon(Icons.Filled.MoreVert, contentDescription = "More options", tint = Color.White)
                            }
                            DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Search messages") },
                                    onClick = { showMenu = false; inChatSearchActive = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Whatsup AI Assistant") },
                                    onClick = { showMenu = false; onOpenAiAssistant(null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Whatsup AI Summary") },
                                    onClick = { showMenu = false; onSummarizeThread() }
                                )
                                DropdownMenuItem(
                                    text = { Text(if (chat.locked) "Unlock chat (Biometric)" else "Lock chat (Biometric)") },
                                    onClick = {
                                        showMenu = false
                                        BiometricAuthHelper.authenticate(
                                            context = context,
                                            title = if (chat.locked) "Unlock ${chat.title}" else "Lock ${chat.title}",
                                            subtitle = "Verify with Fingerprint or Face Lock",
                                            onSuccess = onToggleChatLock,
                                            onError = { msg -> biometricNotice = msg },
                                            onUnavailableFallback = onToggleChatLock
                                        )
                                    },
                                    modifier = Modifier.testTag("chat_menu_lock_toggle")
                                )
                                DropdownMenuItem(
                                    text = { Text("Sync Bluetooth Queue") },
                                    onClick = { showMenu = false; onSyncBluetooth(messages) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Disappearing Messages (${chat.disappearingMode})") },
                                    onClick = { showMenu = false; showDisappearingDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Chat Wallpaper") },
                                    onClick = { showMenu = false; showWallpaperDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Schedule Message") },
                                    onClick = { showMenu = false; showScheduleDialog = true }
                                )
                                DropdownMenuItem(
                                    text = { Text("Export Chat (JSON / TXT)") },
                                    onClick = {
                                        showMenu = false
                                        onOpenExportChat()
                                    }
                                )
                            }
                        }
                    }
                }

                // Optional Bluetooth / Disappearing strip
                if (meshStatus.offlineModeActive || chat.disappearingMode != "OFF") {
                    Surface(
                        color = if (meshStatus.offlineModeActive) BluetoothBlue else Color.Black.copy(alpha = 0.25f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (meshStatus.offlineModeActive) {
                                    "📡 Offline Bluetooth Mesh Active • Messages sync when net returns"
                                } else {
                                    "⏱ Disappearing messages: ${chat.disappearingMode}"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                            if (meshStatus.offlineModeActive) {
                                Text(
                                    text = "Sync Now",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.clickable { onSyncBluetooth(messages) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Chat Message Canvas with Wallpaper
        Box(modifier = Modifier.weight(1f)) {
            if (!darkMode && chat.wallpaperStyle == "DEFAULT") {
                Image(
                    painter = painterResource(id = R.drawable.img_chat_wallpaper),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.55f,
                    modifier = Modifier.fillMaxSize()
                )
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (!inChatSearchActive || inChatSearchQuery.isBlank()) {
                    item(key = "e2e_banner") {
                        Spacer(modifier = Modifier.height(6.dp))
                        EncryptionNoticeBanner(bluetoothMode = meshStatus.offlineModeActive)
                    }
                } else {
                    item(key = "search_results_header") {
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                        ) {
                            Text(
                                text = if (visibleMessages.isEmpty()) {
                                    "No messages matching \"$inChatSearchQuery\""
                                } else {
                                    "${visibleMessages.size} matching message(s) for \"$inChatSearchQuery\""
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                items(
                    items = visibleMessages,
                    key = { it.id }
                ) { msg ->
                    ChatMessageBubble(
                        message = msg,
                        isGroup = chat.chatType != "DIRECT",
                        darkMode = darkMode,
                        hideBlueTicks = hideBlueTicks,
                        highlightQuery = if (inChatSearchActive) inChatSearchQuery.trim() else "",
                        onReply = { replyTarget = msg },
                        onForward = { forwardTargetMsg = msg },
                        onTranslateWithAi = { onOpenAiAssistant(msg) },
                        onStar = { onStarMessage(msg) },
                        onReact = { emoji -> onToggleReaction(msg, emoji) },
                        onDeleteForMe = { onDeleteForMe(msg.id) },
                        onDeleteForEveryone = { onDeleteForEveryone(msg.id) },
                        onOpenViewOnce = {
                            if (!msg.viewOnceOpened) {
                                viewOncePreviewMsg = msg
                                onOpenViewOnce(msg.id)
                            }
                        }
                    )
                }
                item(key = "bottom_space") { Spacer(modifier = Modifier.height(8.dp)) }
            }
        }

        // Gemini AI Input Accessory: inline thread summary & suggested replies
        ChatAiAccessory(
            summaryState = inlineSummaryState,
            suggestionsState = suggestedRepliesState,
            onlyAdminCanSend = chat.onlyAdminCanSend,
            darkMode = darkMode,
            onSummarizeClick = onSummarizeThread,
            onDismissSummary = onDismissSummary,
            onSuggestRepliesClick = onGenerateSuggestions,
            onDismissSuggestions = onDismissSuggestions,
            onInsertSuggestedReply = { suggestion ->
                inputText = suggestion
            },
            onSendSuggestedReply = { suggestion ->
                val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "TEXT"
                onSendMessage(
                    suggestion,
                    msgType,
                    replyTarget?.text,
                    replyTarget?.senderName,
                    if (viewOnceEnabled) "View Once Text • Tap to reveal" else null,
                    null
                )
                replyTarget = null
                viewOnceEnabled = false
                onDismissSuggestions()
            },
            onOpenFullAiSheet = { onOpenAiAssistant(null) },
            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
        )

        // Reply Preview Bar
        if (replyTarget != null) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(34.dp)
                            .background(WhatsupGreen, RoundedCornerShape(2.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (replyTarget!!.fromMe) "Me" else replyTarget!!.senderName,
                            style = MaterialTheme.typography.labelMedium,
                            color = WhatsupGreen,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = replyTarget!!.text,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { replyTarget = null }) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel reply")
                    }
                }
            }
        }

        // Recording Audio Indicator Bar
        if (isRecordingAudio) {
            Surface(color = WhatsupDarkGreen, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = WhatsupGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Recording HD Voice Note...", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    Row {
                        TextButton(onClick = { isRecordingAudio = false }) {
                            Text("Cancel", color = Color.White.copy(alpha = 0.8f))
                        }
                        TextButton(onClick = {
                            isRecordingAudio = false
                            onSendMessage("🎤 Voice message", "VOICE", replyTarget?.text, replyTarget?.senderName, "Voice note • 0:12", null)
                            replyTarget = null
                        }) {
                            Text("Send", color = WhatsupGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (showEmojiTray) {
            EmojiStickersGifTray(
                onPickEmoji = { inputText += it },
                onPickStickerOrGif = { text, type, meta ->
                    onSendMessage(text, type, replyTarget?.text, replyTarget?.senderName, meta, null)
                    replyTarget = null
                    showEmojiTray = false
                }
            )
        }

        // Authentic WhatsApp Bottom Input Bar
        val adminLocked = chat.onlyAdminCanSend
        if (adminLocked) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Only Admins can send messages in this group",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 2.dp,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        IconButton(
                            onClick = { showEmojiTray = !showEmojiTray },
                            modifier = Modifier.testTag("chat_emoji_button")
                        ) {
                            Icon(
                                Icons.Filled.EmojiEmotions,
                                contentDescription = "Emoji, Stickers, GIFs",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (inputText.isEmpty()) {
                                Text(
                                    text = if (meshStatus.offlineModeActive) "Message via Bluetooth..." else "Message",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            BasicTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                textStyle = MaterialTheme.typography.bodyLarge.copy(
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                cursorBrush = SolidColor(WhatsupGreen),
                                maxLines = 5,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("chat_message_input")
                            )
                        }

                        IconButton(
                            onClick = { showAttachSheet = true },
                            modifier = Modifier.testTag("chat_attach_button")
                        ) {
                            Icon(
                                Icons.Filled.AttachFile,
                                contentDescription = "Attach media or file",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (inputText.isBlank()) {
                            IconButton(
                                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                modifier = Modifier.testTag("chat_camera_button")
                            ) {
                                Icon(
                                    Icons.Filled.CameraAlt,
                                    contentDescription = "Camera",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Green Send / Hold-to-Record Mic FAB
                Surface(
                    shape = CircleShape,
                    color = if (meshStatus.offlineModeActive) BluetoothBlue else WhatsupGreen,
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag(if (inputText.isNotBlank()) "chat_send_button" else "chat_mic_button")
                        .clickable {
                            if (inputText.isNotBlank()) {
                                val msgType = if (viewOnceEnabled) "VIEW_ONCE" else "TEXT"
                                onSendMessage(
                                    inputText,
                                    msgType,
                                    replyTarget?.text,
                                    replyTarget?.senderName,
                                    if (viewOnceEnabled) "View Once Text • Tap to reveal" else null,
                                    null
                                )
                                inputText = ""
                                replyTarget = null
                                viewOnceEnabled = false
                            } else {
                                if (isRecordingAudio) {
                                    isRecordingAudio = false
                                    onSendMessage("🎤 Voice message", "VOICE", null, null, "Voice note • 0:09", null)
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (inputText.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                            contentDescription = if (inputText.isNotBlank()) "Send" else "Record Voice Note",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAttachSheet) {
        AttachMediaSheet(
            viewOnceEnabled = viewOnceEnabled,
            onToggleViewOnce = { viewOnceEnabled = !viewOnceEnabled },
            onSendMediaMessage = { text, type, meta ->
                onSendMessage(text, type, replyTarget?.text, replyTarget?.senderName, meta, null)
                replyTarget = null
                viewOnceEnabled = false
            },
            onOpenScheduleDialog = { showScheduleDialog = true },
            onDismiss = { showAttachSheet = false }
        )
    }

    if (showScheduleDialog) {
        var schedText by remember { mutableStateOf(inputText.ifBlank { "Assalam-o-Alaikum, raat 9 baje yaad karwana!" }) }
        var delayMins by remember { mutableStateOf("60") }
        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            icon = { Icon(Icons.Filled.Timer, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Message Scheduler") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Schedule message (e.g. 'Is message ko raat 9 baje bhejna')", style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.OutlinedTextField(
                        value = schedText,
                        onValueChange = { schedText = it },
                        label = { Text("Message") }
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = delayMins,
                        onValueChange = { delayMins = it.filter { c -> c.isDigit() } },
                        label = { Text("Send after (minutes)") }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val mins = delayMins.toIntOrNull() ?: 60
                    onSendMessage(
                        "⏰ [Scheduled +${mins}m] $schedText",
                        "TEXT",
                        null,
                        null,
                        "Scheduled via Whatsup",
                        mins
                    )
                    inputText = ""
                    showScheduleDialog = false
                }) { Text("Schedule") }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showDisappearingDialog) {
        AlertDialog(
            onDismissRequest = { showDisappearingDialog = false },
            title = { Text("Disappearing Messages") },
            text = {
                Column {
                    listOf("OFF", "24H", "7D", "90D").forEach { mode ->
                        TextButton(
                            onClick = {
                                onSetDisappearing(mode)
                                showDisappearingDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when (mode) {
                                    "24H" -> "24 Hours"
                                    "7D" -> "7 Days"
                                    "90D" -> "90 Days"
                                    else -> "Off"
                                } + if (chat.disappearingMode == mode) "  ✓" else ""
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDisappearingDialog = false }) { Text("Close") }
            }
        )
    }

    if (showWallpaperDialog) {
        AlertDialog(
            onDismissRequest = { showWallpaperDialog = false },
            title = { Text("Chat Wallpaper") },
            text = {
                Column {
                    listOf("DEFAULT" to "WhatsApp Classic Doodle", "EMERALD_TINT" to "Emerald Green Calm", "MIDNIGHT" to "Midnight Dark").forEach { (key, label) ->
                        TextButton(
                            onClick = {
                                onSetWallpaper(key)
                                showWallpaperDialog = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(label + if (chat.wallpaperStyle == key) "  ✓" else "")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showWallpaperDialog = false }) { Text("Close") }
            }
        )
    }

    if (viewOncePreviewMsg != null) {
        AlertDialog(
            onDismissRequest = { viewOncePreviewMsg = null },
            icon = { Icon(Icons.Filled.VisibilityOff, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("View Once • Screenshot Protected") },
            text = {
                Column {
                    Text(viewOncePreviewMsg!!.text, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This message has now been marked as opened and cannot be viewed again.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { viewOncePreviewMsg = null }) { Text("Close") }
            }
        )
    }

    if (forwardTargetMsg != null) {
        AlertDialog(
            onDismissRequest = { forwardTargetMsg = null },
            title = { Text("Forward message to...") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    allChats.filter { it.id != chat.id }.take(6).forEach { target ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onForwardMessage(target.id, forwardTargetMsg!!)
                                    forwardTargetMsg = null
                                }
                        ) {
                            Text(target.title, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { forwardTargetMsg = null }) { Text("Cancel") }
            }
        )
    }

    if (biometricNotice != null) {
        AlertDialog(
            onDismissRequest = { biometricNotice = null },
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Chat Lock Authentication") },
            text = { Text(biometricNotice ?: "") },
            confirmButton = {
                TextButton(onClick = { biometricNotice = null }) { Text("OK") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatMessageBubble(
    message: ChatMessage,
    isGroup: Boolean,
    darkMode: Boolean,
    hideBlueTicks: Boolean,
    highlightQuery: String = "",
    onReply: () -> Unit,
    onForward: () -> Unit,
    onTranslateWithAi: () -> Unit,
    onStar: () -> Unit,
    onReact: (String) -> Unit,
    onDeleteForMe: () -> Unit,
    onDeleteForEveryone: () -> Unit,
    onOpenViewOnce: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val bubbleColor = when {
        message.fromMe && darkMode -> DarkSentBubble
        message.fromMe -> LightSentBubble
        darkMode -> DarkReceivedBubble
        else -> LightReceivedBubble
    }

    val sortedReactions = remember(message.reactions) {
        message.reactions.entries
            .filter { it.value > 0L }
            .sortedByDescending { it.value }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromMe) Arrangement.End else Arrangement.Start
    ) {
        Column(horizontalAlignment = if (message.fromMe) Alignment.End else Alignment.Start) {
            Box {
                Surface(
                    color = bubbleColor,
                    shape = RoundedCornerShape(
                        topStart = if (message.fromMe) 12.dp else 4.dp,
                        topEnd = if (message.fromMe) 4.dp else 12.dp,
                        bottomStart = 12.dp,
                        bottomEnd = 12.dp
                    ),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .widthIn(min = 90.dp, max = 300.dp)
                        .testTag("chat_bubble_${message.id}")
                        .combinedClickable(
                            onClick = {
                                if (message.messageType == "VIEW_ONCE") onOpenViewOnce()
                            },
                            onLongClick = { showMenu = true }
                        )
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
                        if (isGroup && !message.fromMe) {
                            Text(
                                text = message.senderName,
                                style = MaterialTheme.typography.labelMedium,
                                color = WhatsupGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!message.replyToText.isNullOrBlank()) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.07f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(6.dp)) {
                                    Text(
                                        text = message.replyToSender ?: "Reply",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = WhatsupGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = message.replyToText,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        if (message.viaBluetooth) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(bottom = 2.dp)
                            ) {
                                Icon(
                                    Icons.Filled.BluetoothConnected,
                                    contentDescription = "Sent via Bluetooth",
                                    tint = BluetoothBlue,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Sent via Bluetooth",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BluetoothBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        if (message.messageType == "VIEW_ONCE") {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Lock,
                                    contentDescription = "View Once",
                                    tint = if (message.viewOnceOpened) MaterialTheme.colorScheme.onSurfaceVariant else WhatsupGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (message.viewOnceOpened) "Opened (View Once)" else "① Tap to open View Once",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (message.viewOnceOpened) MaterialTheme.colorScheme.onSurfaceVariant else WhatsupDarkGreen
                                )
                            }
                        } else if (highlightQuery.isNotBlank()) {
                            val highlighted = buildAnnotatedString {
                                val text = message.text
                                var startIndex = 0
                                while (startIndex < text.length) {
                                    val matchIndex = text.indexOf(highlightQuery, startIndex, ignoreCase = true)
                                    if (matchIndex < 0) {
                                        append(text.substring(startIndex))
                                        break
                                    }
                                    if (matchIndex > startIndex) {
                                        append(text.substring(startIndex, matchIndex))
                                    }
                                    withStyle(
                                        SpanStyle(
                                            background = WhatsupGreen.copy(alpha = 0.36f),
                                            fontWeight = FontWeight.Bold
                                        )
                                    ) {
                                        append(text.substring(matchIndex, matchIndex + highlightQuery.length))
                                    }
                                    startIndex = matchIndex + highlightQuery.length
                                }
                            }
                            Text(
                                text = highlighted,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        } else {
                            Text(
                                text = message.text,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }

                        if (!message.mediaMeta.isNullOrBlank() && message.messageType != "VIEW_ONCE") {
                            Spacer(modifier = Modifier.height(3.dp))
                            Surface(
                                color = Color.Black.copy(alpha = 0.06f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = message.mediaMeta,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier.align(Alignment.End),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (message.starred) {
                                Icon(
                                    Icons.Filled.Star,
                                    contentDescription = "Starred",
                                    tint = GoldStar,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = message.timeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (message.fromMe) {
                                Spacer(modifier = Modifier.width(4.dp))
                                MessageTickBadge(
                                    tickStatus = message.tickStatus,
                                    viaBluetooth = message.viaBluetooth,
                                    hideBlueTicks = hideBlueTicks
                                )
                            }
                        }
                    }
                }

                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    // Quick Emoji Reaction Picker Bar
                    Row(
                        modifier = Modifier
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("reaction_picker_row_${message.id}"),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        MessageReactionHelper.quickEmojis.forEachIndexed { idx, emoji ->
                            val selected = message.myReaction == emoji
                            Surface(
                                shape = CircleShape,
                                color = if (selected) WhatsupGreen.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                border = if (selected) BorderStroke(1.dp, WhatsupGreen) else null,
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .clickable {
                                        showMenu = false
                                        onReact(emoji)
                                    }
                                    .testTag("reaction_pick_${message.id}_$idx")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = emoji, fontSize = 18.sp)
                                }
                            }
                        }
                    }
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Reply") }, onClick = { showMenu = false; onReply() })
                    DropdownMenuItem(text = { Text("Forward") }, onClick = { showMenu = false; onForward() })
                    DropdownMenuItem(text = { Text("Translate with Whatsup AI") }, onClick = { showMenu = false; onTranslateWithAi() })
                    DropdownMenuItem(text = { Text(if (message.starred) "Unstar" else "Star message") }, onClick = { showMenu = false; onStar() })
                    DropdownMenuItem(text = { Text("Delete for me") }, onClick = { showMenu = false; onDeleteForMe() })
                    if (message.fromMe && !message.deletedForEveryone) {
                        DropdownMenuItem(text = { Text("Delete for everyone") }, onClick = { showMenu = false; onDeleteForEveryone() })
                    }
                }
            }

            // Reaction Count Summary Underneath the Bubble
            if (sortedReactions.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .padding(top = 2.dp, start = 6.dp, end = 6.dp)
                        .testTag("message_reactions_${message.id}"),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    sortedReactions.forEach { (emoji, count) ->
                        val isMine = message.myReaction == emoji
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isMine) WhatsupGreen.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (isMine) WhatsupGreen else MaterialTheme.colorScheme.outlineVariant
                            ),
                            shadowElevation = 1.dp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onReact(emoji) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(text = emoji, fontSize = 13.sp)
                                Text(
                                    text = count.toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isMine) WhatsupDarkGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
