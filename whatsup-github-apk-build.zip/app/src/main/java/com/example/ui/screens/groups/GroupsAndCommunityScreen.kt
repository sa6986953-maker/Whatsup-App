package com.example.ui.screens.groups

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.ui.components.ContactAvatar
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen

@Composable
fun GroupsAndCommunityScreen(
    chatsState: UiState<List<ChatThread>>,
    onOpenChat: (ChatThread) -> Unit,
    onToggleAdminOnlySend: (ChatThread) -> Unit,
    onCreateGroup: (title: String, bluetoothChat: Boolean, communityName: String?) -> Unit,
    onStartGroupVideoCall: (ChatThread) -> Unit
) {
    var showCreateGroupDialog by remember { mutableStateOf(false) }
    var manageAdminGroup by remember { mutableStateOf<ChatThread?>(null) }

    when (chatsState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = WhatsupGreen)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(chatsState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val groupChats = chatsState.data.filter { it.chatType != "DIRECT" }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(key = "community_banner") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WhatsupDarkGreen),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Groups, contentDescription = null, tint = WhatsupGreen, modifier = Modifier.size(28.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Communities & 1024-Member Groups",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Admin controls, member approvals, polls, events & offline Bluetooth groups",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { showCreateGroupDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(46.dp)
                                    .testTag("create_community_group_button")
                            ) {
                                Icon(Icons.Filled.GroupAdd, contentDescription = null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("New Group / Bluetooth Community", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                items(groupChats, key = { it.id }) { group ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenChat(group) }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ContactAvatar(
                                    name = group.title,
                                    colorHex = group.avatarColorHex,
                                    chatType = group.chatType,
                                    online = group.online,
                                    size = 48.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(group.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${group.memberCount} / 1024 members" +
                                            (group.communityName?.let { " • $it" } ?: ""),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (group.bluetoothChat) BluetoothBlue else WhatsupGreen
                                    )
                                }
                                IconButton(onClick = { onStartGroupVideoCall(group) }) {
                                    Icon(Icons.Filled.Videocam, contentDescription = "Group Video Call", tint = WhatsupGreen)
                                }
                                IconButton(onClick = { manageAdminGroup = group }) {
                                    Icon(Icons.Filled.AdminPanelSettings, contentDescription = "Admin Controls", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = group.lastMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (group.bluetoothChat) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    color = BluetoothBlue.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.BluetoothConnected, contentDescription = null, tint = BluetoothBlue, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Offline Bluetooth Group Active", style = MaterialTheme.typography.labelSmall, color = BluetoothBlue)
                                    }
                                }
                            }
                        }
                    }
                }

                item(key = "groups_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (showCreateGroupDialog) {
        var title by remember { mutableStateOf("") }
        var community by remember { mutableStateOf("Kahror Pakka Youth Community") }
        var isBtGroup by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showCreateGroupDialog = false },
            title = { Text("Create Group (Up to 1024 Members)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Group Name") })
                    OutlinedTextField(value = community, onValueChange = { community = it }, label = { Text("Community Name") })
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Offline Bluetooth Group", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = isBtGroup,
                            onCheckedChange = { isBtGroup = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = BluetoothBlue)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            onCreateGroup(title.trim(), isBtGroup, community.trim().ifBlank { null })
                            showCreateGroupDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen)
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateGroupDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (manageAdminGroup != null) {
        val group = manageAdminGroup!!
        val pendingApprovals = remember { mutableStateListOf("Zohaib Ahmed (+92 304 1199223)", "Sanaullah (+92 315 8822114)") }
        val currentMembers = remember { mutableStateListOf("Ali Raza", "Hamza Tariq", "Usman") }

        AlertDialog(
            onDismissRequest = { manageAdminGroup = null },
            title = { Text("Admin Controls • ${group.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Only Admins Can Send", fontWeight = FontWeight.SemiBold)
                        Switch(
                            checked = group.onlyAdminCanSend,
                            onCheckedChange = {
                                onToggleAdminOnlySend(group)
                                manageAdminGroup = group.copy(onlyAdminCanSend = !group.onlyAdminCanSend)
                            }
                        )
                    }

                    Text("Approve New Members (${pendingApprovals.size})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    pendingApprovals.forEach { candidate ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(candidate, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = {
                                pendingApprovals.remove(candidate)
                                currentMembers.add(candidate.substringBefore(" ("))
                            }) {
                                Text("Approve")
                            }
                        }
                    }

                    Text("Remove Members", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    currentMembers.forEach { member ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(member, style = MaterialTheme.typography.bodySmall)
                            IconButton(onClick = { currentMembers.remove(member) }) {
                                Icon(Icons.Filled.PersonRemove, contentDescription = "Remove $member", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { manageAdminGroup = null }) { Text("Done") }
            }
        )
    }
}
