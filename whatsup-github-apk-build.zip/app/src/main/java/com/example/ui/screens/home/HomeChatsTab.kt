package com.example.ui.screens.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.BiometricAuthHelper
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.ui.components.ContactAvatar
import com.example.ui.components.MessageTickBadge
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupGreen

@Composable
fun HomeChatsTab(
    chatsState: UiState<List<ChatThread>>,
    searchQuery: String,
    hideBlueTicks: Boolean,
    hideOnline: Boolean,
    appLockPin: String,
    onOpenChat: (ChatThread) -> Unit,
    onTogglePin: (ChatThread) -> Unit,
    onToggleArchive: (ChatThread) -> Unit,
    onToggleMute: (ChatThread) -> Unit,
    onToggleLock: (ChatThread) -> Unit
) {
    val context = LocalContext.current
    var showArchivedOnly by remember { mutableStateOf(false) }
    var lockedChatPrompt by remember { mutableStateOf<ChatThread?>(null) }
    var pendingToggleLockChat by remember { mutableStateOf<ChatThread?>(null) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var biometricStatusMessage by remember { mutableStateOf<String?>(null) }

    when (chatsState) {
        is UiState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = WhatsupGreen)
            }
        }
        is UiState.Error -> {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(chatsState.message, color = MaterialTheme.colorScheme.error)
            }
        }
        is UiState.Success -> {
            val allChats = chatsState.data
            val archivedCount = allChats.count { it.archived }
            val filtered = allChats.filter { chat ->
                val matchesArchive = if (showArchivedOnly) chat.archived else !chat.archived
                val matchesSearch = searchQuery.isBlank() ||
                    chat.title.contains(searchQuery, ignoreCase = true) ||
                    chat.lastMessage.contains(searchQuery, ignoreCase = true)
                matchesArchive && matchesSearch
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                if (archivedCount > 0 || showArchivedOnly) {
                    item(key = "archived_banner") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .padding(horizontal = 16.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showArchivedOnly = !showArchivedOnly }
                                .padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Archive,
                                contentDescription = "Archived",
                                tint = WhatsupGreen,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(18.dp))
                            Text(
                                text = if (showArchivedOnly) "← Back to All Chats" else "Archived",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            if (!showArchivedOnly) {
                                Text(
                                    text = archivedCount.toString(),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = WhatsupGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    }
                }

                items(filtered, key = { it.id }) { chat ->
                    ChatRowItem(
                        chat = chat,
                        hideBlueTicks = hideBlueTicks,
                        hideOnline = hideOnline,
                        onClick = {
                            if (chat.locked) {
                                biometricStatusMessage = null
                                BiometricAuthHelper.authenticate(
                                    context = context,
                                    title = "Unlock ${chat.title}",
                                    subtitle = "Authenticate with Fingerprint or Face Lock",
                                    onSuccess = { onOpenChat(chat) },
                                    onError = { msg -> biometricStatusMessage = msg },
                                    onUnavailableFallback = {
                                        pinInput = ""
                                        pinError = null
                                        pendingToggleLockChat = null
                                        lockedChatPrompt = chat
                                    }
                                )
                            } else {
                                onOpenChat(chat)
                            }
                        },
                        onTogglePin = { onTogglePin(chat) },
                        onToggleArchive = { onToggleArchive(chat) },
                        onToggleMute = { onToggleMute(chat) },
                        onToggleLock = {
                            BiometricAuthHelper.authenticate(
                                context = context,
                                title = if (chat.locked) "Unlock Chat Lock" else "Lock Chat",
                                subtitle = if (chat.locked) {
                                    "Verify Fingerprint or Face Lock to remove chat lock"
                                } else {
                                    "Verify Fingerprint or Face Lock to secure ${chat.title}"
                                },
                                onSuccess = { onToggleLock(chat) },
                                onError = { msg -> biometricStatusMessage = msg },
                                onUnavailableFallback = {
                                    pinInput = ""
                                    pinError = null
                                    pendingToggleLockChat = chat
                                    lockedChatPrompt = chat
                                }
                            )
                        }
                    )
                }

                item(key = "bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (biometricStatusMessage != null) {
        AlertDialog(
            onDismissRequest = { biometricStatusMessage = null },
            icon = { Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Biometric Authentication") },
            text = { Text(biometricStatusMessage ?: "") },
            confirmButton = {
                TextButton(onClick = { biometricStatusMessage = null }) { Text("OK") }
            }
        )
    }

    if (lockedChatPrompt != null) {
        val targetChat = lockedChatPrompt!!
        val isTogglingLockState = pendingToggleLockChat?.id == targetChat.id
        AlertDialog(
            onDismissRequest = {
                lockedChatPrompt = null
                pendingToggleLockChat = null
            },
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen) },
            title = {
                Text(if (isTogglingLockState) "Confirm Chat Lock Change" else "Locked Chat")
            },
            text = {
                Column {
                    Text(
                        text = if (isTogglingLockState) {
                            "Biometrics unavailable on this device. Enter PIN to ${if (targetChat.locked) "unlock" else "lock"} ${targetChat.title} (default PIN: $appLockPin)"
                        } else {
                            "Enter Chat Lock PIN to open ${targetChat.title} (default PIN: $appLockPin)"
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            pinInput = it
                            pinError = null
                        },
                        label = { Text("PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.testTag("chat_lock_pin_input")
                    )
                    if (pinError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(pinError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pinInput == appLockPin) {
                        lockedChatPrompt = null
                        if (isTogglingLockState) {
                            pendingToggleLockChat = null
                            onToggleLock(targetChat)
                        } else {
                            onOpenChat(targetChat)
                        }
                    } else {
                        pinError = "Incorrect PIN"
                    }
                }) {
                    Text(if (isTogglingLockState) "Confirm" else "Unlock")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    lockedChatPrompt = null
                    pendingToggleLockChat = null
                }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun ChatRowItem(
    chat: ChatThread,
    hideBlueTicks: Boolean,
    hideOnline: Boolean,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleArchive: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleLock: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { targetValue ->
            if (targetValue == SwipeToDismissBoxValue.StartToEnd) {
                onTogglePin()
            }
            // Snap back smoothly after toggling pin so the chat row stays visible
            false
        }
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = true,
        enableDismissFromEndToStart = false,
        backgroundContent = {
            val isTriggered = dismissState.targetValue == SwipeToDismissBoxValue.StartToEnd
            val bgColor by animateColorAsState(
                targetValue = if (isTriggered) WhatsupGreen else WhatsupGreen.copy(alpha = 0.72f),
                label = "swipe_pin_bg"
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgColor)
                    .padding(horizontal = 22.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.PushPin,
                        contentDescription = if (chat.pinned) "Unpin chat" else "Pin chat",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (chat.pinned) "Unpin" else "Pin to Top",
                        color = Color.White,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.background)
                .testTag("chat_item_${chat.id}")
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = { showMenu = true }
                )
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ContactAvatar(
                name = chat.title,
                colorHex = chat.avatarColorHex,
                chatType = chat.chatType,
                online = chat.online && !hideOnline,
                size = 52.dp
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = chat.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (chat.bluetoothChat) {
                        Surface(
                            color = BluetoothBlue.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Filled.Bluetooth,
                                    contentDescription = "Bluetooth",
                                    tint = BluetoothBlue,
                                    modifier = Modifier.size(11.dp)
                                )
                                Text(
                                    "BT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BluetoothBlue,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                    Text(
                        text = chat.lastMessageTimeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (chat.unreadCount > 0) WhatsupGreen else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(3.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MessageTickBadge(
                        tickStatus = chat.lastMessageTick,
                        viaBluetooth = chat.lastMessageTick == "BLUETOOTH" || chat.bluetoothChat,
                        hideBlueTicks = hideBlueTicks
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (chat.locked) "🔒 Locked Chat" else chat.lastMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (chat.locked) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = "Chat Locked",
                            tint = WhatsupGreen,
                            modifier = Modifier
                                .size(15.dp)
                                .testTag("chat_locked_icon_${chat.id}")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    if (chat.muted) {
                        Icon(
                            imageVector = Icons.Filled.VolumeOff,
                            contentDescription = "Muted",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    if (chat.pinned) {
                        Icon(
                            imageVector = Icons.Filled.PushPin,
                            contentDescription = "Pinned",
                            tint = WhatsupGreen,
                            modifier = Modifier
                                .size(16.dp)
                                .testTag("chat_pinned_icon_${chat.id}")
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    if (chat.unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(WhatsupGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = chat.unreadCount.toString(),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
            DropdownMenuItem(
                text = { Text(if (chat.pinned) "Unpin chat" else "Pin chat") },
                onClick = { showMenu = false; onTogglePin() }
            )
            DropdownMenuItem(
                text = { Text(if (chat.archived) "Unarchive chat" else "Archive chat") },
                onClick = { showMenu = false; onToggleArchive() }
            )
            DropdownMenuItem(
                text = { Text(if (chat.muted) "Unmute notifications" else "Mute notifications") },
                onClick = { showMenu = false; onToggleMute() }
            )
            DropdownMenuItem(
                text = { Text(if (chat.locked) "Unlock chat (Biometric)" else "Lock chat (Biometric)") },
                onClick = { showMenu = false; onToggleLock() },
                modifier = Modifier.testTag("chat_row_lock_menu_${chat.id}")
            )
        }
        }
    }
}
