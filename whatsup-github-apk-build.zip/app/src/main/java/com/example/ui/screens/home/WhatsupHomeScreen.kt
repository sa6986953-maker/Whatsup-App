package com.example.ui.screens.home

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.ChatHistoryExporter
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.ui.screens.ai.WhatsupAiSheet
import com.example.ui.screens.bluetooth.BluetoothMeshSheet
import com.example.ui.screens.calls.ActiveCallOverlay
import com.example.ui.screens.calls.ActiveCallSession
import com.example.ui.screens.calls.CallsScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.groups.GroupsAndCommunityScreen
import com.example.ui.screens.settings.ExportChatHistoryDialog
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.updates.UpdatesScreen
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.WhatsupViewModel

private enum class HomeTab(val label: String) {
    CHATS("Chats"),
    UPDATES("Updates"),
    CALLS("Calls"),
    GROUPS("Groups")
}

@Composable
fun WhatsupMainApp(
    viewModel: WhatsupViewModel,
    aiViewModel: AiAssistantViewModel,
    isGoogleSignedIn: Boolean = false,
    signedInEmail: String? = null,
    isAuthLoading: Boolean = false,
    authErrorMessage: String? = null,
    onConnectGoogleAccount: () -> Unit = {},
    onOpenOptionalCloudSetup: () -> Unit = {},
    onSignOut: () -> Unit
) {
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val messagesState by viewModel.activeMessagesState.collectAsStateWithLifecycle()
    val statusesState by viewModel.statusesState.collectAsStateWithLifecycle()
    val callsState by viewModel.callsState.collectAsStateWithLifecycle()
    val profileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val meshStatus by viewModel.meshStatus.collectAsStateWithLifecycle()
    val selectedChatId by viewModel.selectedChatId.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val exportedFiles by viewModel.exportedFiles.collectAsStateWithLifecycle()
    val inlineSummaryState by aiViewModel.inlineSummaryState.collectAsStateWithLifecycle()
    val suggestedRepliesState by aiViewModel.suggestedRepliesState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(selectedChatId) {
        aiViewModel.onChatThreadChanged(selectedChatId)
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchActive by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showBluetoothSheet by remember { mutableStateOf(false) }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var showAiSheet by remember { mutableStateOf(false) }
    var showChatExportDialog by remember { mutableStateOf(false) }
    var aiTargetMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var activeCall by remember { mutableStateOf<ActiveCallSession?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(actionMessage) {
        actionMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearActionMessage()
        }
    }

    val quickPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val name = (profileState as? UiState.Success)?.data?.displayName ?: "Me"
            viewModel.postStatus(name, "📸 Camera Update", "PHOTO", 0xFF075E54L)
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        quickPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val allChats = (chatsState as? UiState.Success)?.data ?: emptyList()
    val selectedChat = allChats.firstOrNull { it.id == selectedChatId }
    val profile = (profileState as? UiState.Success)?.data

    // Active Call Overlay takes top priority
    if (activeCall != null) {
        ActiveCallOverlay(
            session = activeCall!!,
            onEndCall = { recorded ->
                viewModel.startOrLogCall(
                    peerName = activeCall!!.title,
                    callType = when {
                        activeCall!!.isGroupConference && activeCall!!.isVideo -> "GROUP_VIDEO"
                        activeCall!!.isGroupConference -> "GROUP_VOICE"
                        activeCall!!.isVideo -> "VIDEO"
                        else -> "VOICE"
                    },
                    participantCount = activeCall!!.participantCount.toLong(),
                    recorded = recorded
                )
                activeCall = null
            }
        )
        return
    }

    if (showSettings) {
        SettingsScreen(
            profile = profile,
            localPrefs = localPrefs,
            allChats = allChats,
            exportState = exportState,
            exportedFiles = exportedFiles,
            isGoogleSignedIn = isGoogleSignedIn,
            signedInEmail = signedInEmail,
            isAuthLoading = isAuthLoading,
            authErrorMessage = authErrorMessage,
            onBack = { showSettings = false },
            onToggleDarkMode = viewModel::toggleDarkMode,
            onUpdatePrivacySettings = viewModel::updatePrivacyAndSettings,
            onSetAppLock = viewModel::setAppLock,
            onSwitchDualAccount = viewModel::switchDualAccount,
            onOpenBluetoothMesh = { showBluetoothSheet = true },
            onSelectNotificationSound = viewModel::setNotificationSound,
            onRefreshExports = { viewModel.refreshExportedFiles(context) },
            onExportChatHistory = { chatId, format -> viewModel.exportChatHistory(context, chatId, format) },
            onDeleteExportFile = { file -> viewModel.deleteExportedFile(context, file) },
            onResetExportState = viewModel::resetExportState,
            onConnectGoogleAccount = onConnectGoogleAccount,
            onOpenOptionalCloudSetup = onOpenOptionalCloudSetup,
            onSignOut = onSignOut
        )
    } else {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedScreen = maxWidth >= 840.dp

            if (selectedChat != null && !isExpandedScreen) {
                // Full-screen ChatScreen on handheld portrait/medium screens
                ChatScreen(
                    chat = selectedChat,
                    messagesState = messagesState,
                    meshStatus = meshStatus,
                    darkMode = localPrefs.darkMode,
                    hideBlueTicks = profile?.hideBlueTicks ?: false,
                    hideOnline = profile?.hideOnline ?: false,
                    hideLastSeen = profile?.hideLastSeen ?: false,
                    allChats = allChats,
                    onBack = { viewModel.selectChat(null) },
                    onToggleBluetoothMode = viewModel::toggleOfflineBluetoothMode,
                    onSyncBluetooth = { msgs -> viewModel.syncPendingBluetooth(selectedChat.id, msgs) },
                    onSendMessage = { text, type, rText, rSender, meta, delayMins ->
                        viewModel.sendMessage(selectedChat.id, text, type, rText, rSender, meta, delayMins)
                    },
                    onForwardMessage = { targetId, msg ->
                        viewModel.sendMessage(targetId, "↪ Forwarded: ${msg.text}", msg.messageType, null, null, msg.mediaMeta, null)
                    },
                    onStarMessage = { msg -> viewModel.toggleStarMessage(selectedChat.id, msg) },
                    onToggleReaction = { msg, emoji -> viewModel.toggleMessageReaction(selectedChat.id, msg, emoji) },
                    onDeleteForMe = { msgId -> viewModel.deleteMessageForMe(selectedChat.id, msgId) },
                    onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(selectedChat.id, msgId) },
                    onOpenViewOnce = { msgId -> viewModel.openViewOnceMessage(selectedChat.id, msgId) },
                    onSetDisappearing = { mode -> viewModel.setDisappearingMode(selectedChat.id, mode) },
                    onSetWallpaper = { style -> viewModel.setWallpaperStyle(selectedChat.id, style) },
                    onToggleChatLock = { viewModel.toggleLockChat(selectedChat) },
                    onOpenAiAssistant = { msg ->
                        aiTargetMessage = msg
                        showAiSheet = true
                    },
                    inlineSummaryState = inlineSummaryState,
                    suggestedRepliesState = suggestedRepliesState,
                    onSummarizeThread = {
                        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                        aiViewModel.summarizeThreadInline(selectedChat.title, msgs)
                    },
                    onDismissSummary = aiViewModel::dismissInlineSummary,
                    onGenerateSuggestions = {
                        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                        aiViewModel.generateThreadSuggestions(selectedChat.title, msgs)
                    },
                    onDismissSuggestions = aiViewModel::dismissSuggestedReplies,
                    onOpenExportChat = {
                        viewModel.resetExportState()
                        showChatExportDialog = true
                    },
                    onStartVoiceCall = {
                        activeCall = ActiveCallSession(selectedChat.title, isVideo = false, isGroupConference = false, participantCount = 2, lowDataMode = profile?.dataSaver ?: false)
                    },
                    onStartVideoCall = {
                        activeCall = ActiveCallSession(selectedChat.title, isVideo = true, isGroupConference = selectedChat.chatType != "DIRECT", participantCount = if (selectedChat.chatType != "DIRECT") 8 else 2, lowDataMode = profile?.dataSaver ?: false)
                    }
                )
            } else {
                // Main WhatsApp Home Shell (with adaptive NavigationRail + List-Detail on Tablets)
                val topBarColor = if (localPrefs.darkMode) DarkTopBar else WhatsupDarkGreen
                val tabs = HomeTab.entries

                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    topBar = {
                        Surface(color = topBarColor, shadowElevation = 4.dp) {
                            Column(modifier = Modifier.statusBarsPadding()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(58.dp)
                                        .padding(horizontal = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (searchActive) {
                                        OutlinedTextField(
                                            value = searchQuery,
                                            onValueChange = viewModel::updateSearchQuery,
                                            placeholder = { Text("Search Whatsup...", color = Color.White.copy(alpha = 0.7f)) },
                                            singleLine = true,
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("home_search_input")
                                        )
                                        IconButton(onClick = {
                                            searchActive = false
                                            viewModel.updateSearchQuery("")
                                        }) {
                                            Icon(Icons.Filled.Close, contentDescription = "Close Search", tint = Color.White)
                                        }
                                    } else {
                                        Text(
                                            text = "Whatsup",
                                            style = MaterialTheme.typography.titleLarge,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )

                                        // Offline Bluetooth Mesh Status Chip
                                        Surface(
                                            color = if (meshStatus.offlineModeActive) BluetoothBlue else Color.White.copy(alpha = 0.16f),
                                            shape = RoundedCornerShape(16.dp),
                                            modifier = Modifier
                                                .clickable { showBluetoothSheet = true }
                                                .testTag("home_bluetooth_chip")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.BluetoothConnected,
                                                    contentDescription = "Bluetooth Mesh",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (meshStatus.offlineModeActive) "BT Offline" else "Mesh",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = { cameraPermission.launch(Manifest.permission.CAMERA) },
                                            modifier = Modifier.testTag("home_camera_button")
                                        ) {
                                            Icon(Icons.Filled.CameraAlt, contentDescription = "Camera", tint = Color.White)
                                        }
                                        IconButton(
                                            onClick = { searchActive = true },
                                            modifier = Modifier.testTag("home_search_button")
                                        ) {
                                            Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
                                        }
                                        Box {
                                            IconButton(
                                                onClick = { showOverflowMenu = true },
                                                modifier = Modifier.testTag("home_overflow_menu")
                                            ) {
                                                Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = Color.White)
                                            }
                                            DropdownMenu(
                                                expanded = showOverflowMenu,
                                                onDismissRequest = { showOverflowMenu = false }
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text("New group") },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        selectedTabIndex = HomeTab.GROUPS.ordinal
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("Offline Bluetooth Mesh") },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        showBluetoothSheet = true
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("New chat") },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        showNewChatDialog = true
                                                    }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("Settings") },
                                                    onClick = {
                                                        showOverflowMenu = false
                                                        showSettings = true
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }

                                // 100% WhatsApp Style 4-Tab Bar on handhelds: Chats | Updates | Calls | Groups
                                if (!isExpandedScreen) {
                                    TabRow(
                                        selectedTabIndex = selectedTabIndex,
                                        containerColor = topBarColor,
                                        contentColor = Color.White,
                                        indicator = { tabPositions ->
                                            TabRowDefaults.SecondaryIndicator(
                                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                                height = 3.dp,
                                                color = Color.White
                                            )
                                        }
                                    ) {
                                        tabs.forEachIndexed { index, tab ->
                                            Tab(
                                                selected = selectedTabIndex == index,
                                                onClick = { selectedTabIndex = index },
                                                modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
                                                text = {
                                                    Text(
                                                        text = tab.label,
                                                        fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                                        maxLines = 1
                                                    )
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = { showNewChatDialog = true },
                            containerColor = WhatsupGreen,
                            contentColor = Color.White,
                            modifier = Modifier
                                .navigationBarsPadding()
                                .testTag("home_new_chat_fab")
                        ) {
                            Icon(Icons.Filled.AddComment, contentDescription = "New Chat")
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .navigationBarsPadding()
                    ) {
                        if (isExpandedScreen) {
                            NavigationRail {
                                tabs.forEachIndexed { index, tab ->
                                    val icon = when (tab) {
                                        HomeTab.CHATS -> Icons.Filled.Chat
                                        HomeTab.UPDATES -> Icons.Filled.Update
                                        HomeTab.CALLS -> Icons.Filled.Call
                                        HomeTab.GROUPS -> Icons.Filled.Groups
                                    }
                                    NavigationRailItem(
                                        selected = selectedTabIndex == index,
                                        onClick = { selectedTabIndex = index },
                                        icon = { Icon(icon, contentDescription = tab.label) },
                                        label = { Text(tab.label) }
                                    )
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(if (isExpandedScreen && selectedChat != null) 0.42f else 1f)
                                .fillMaxHeight()
                        ) {
                            when (tabs[selectedTabIndex]) {
                                HomeTab.CHATS -> HomeChatsTab(
                                    chatsState = chatsState,
                                    searchQuery = searchQuery,
                                    hideBlueTicks = profile?.hideBlueTicks ?: false,
                                    hideOnline = profile?.hideOnline ?: false,
                                    appLockPin = localPrefs.appLockPin,
                                    onOpenChat = { viewModel.selectChat(it.id) },
                                    onTogglePin = viewModel::togglePinChat,
                                    onToggleArchive = viewModel::toggleArchiveChat,
                                    onToggleMute = viewModel::toggleMuteChat,
                                    onToggleLock = viewModel::toggleLockChat
                                )
                                HomeTab.UPDATES -> UpdatesScreen(
                                    statusesState = statusesState,
                                    myDisplayName = profile?.displayName ?: "Me",
                                    onPostStatus = viewModel::postStatus,
                                    onMarkViewed = viewModel::markStatusViewed
                                )
                                HomeTab.CALLS -> CallsScreen(
                                    callsState = callsState,
                                    dataSaverDefault = profile?.dataSaver ?: false,
                                    onCreateCallLink = { code ->
                                        viewModel.startOrLogCall(
                                            peerName = "Call Link ($code)",
                                            callType = "GROUP_VIDEO",
                                            participantCount = 1L,
                                            callLinkCode = code
                                        )
                                    },
                                    onLaunchCall = { peer, type, count ->
                                        activeCall = ActiveCallSession(
                                            title = peer,
                                            isVideo = type.contains("VIDEO"),
                                            isGroupConference = type.startsWith("GROUP"),
                                            participantCount = count,
                                            lowDataMode = profile?.dataSaver ?: false
                                        )
                                    }
                                )
                                HomeTab.GROUPS -> GroupsAndCommunityScreen(
                                    chatsState = chatsState,
                                    onOpenChat = { viewModel.selectChat(it.id) },
                                    onToggleAdminOnlySend = viewModel::toggleAdminOnlySend,
                                    onCreateGroup = { title, bt, community ->
                                        viewModel.createNewChatOrBluetoothGroup(
                                            title = title,
                                            phone = "",
                                            chatType = if (bt) "BLUETOOTH_GROUP" else "GROUP",
                                            bluetoothChat = bt,
                                            communityName = community
                                        )
                                    },
                                    onStartGroupVideoCall = { group ->
                                        activeCall = ActiveCallSession(
                                            title = group.title,
                                            isVideo = true,
                                            isGroupConference = true,
                                            participantCount = group.memberCount.toInt().coerceIn(2, 16),
                                            lowDataMode = profile?.dataSaver ?: false
                                        )
                                    }
                                )
                            }
                        }

                        // Tablet Split-Pane Detail View
                        if (isExpandedScreen && selectedChat != null) {
                            Box(
                                modifier = Modifier
                                    .weight(0.58f)
                                    .fillMaxHeight()
                            ) {
                                ChatScreen(
                                    chat = selectedChat,
                                    messagesState = messagesState,
                                    meshStatus = meshStatus,
                                    darkMode = localPrefs.darkMode,
                                    hideBlueTicks = profile?.hideBlueTicks ?: false,
                                    hideOnline = profile?.hideOnline ?: false,
                                    hideLastSeen = profile?.hideLastSeen ?: false,
                                    allChats = allChats,
                                    onBack = { viewModel.selectChat(null) },
                                    onToggleBluetoothMode = viewModel::toggleOfflineBluetoothMode,
                                    onSyncBluetooth = { msgs -> viewModel.syncPendingBluetooth(selectedChat.id, msgs) },
                                    onSendMessage = { text, type, rText, rSender, meta, delayMins ->
                                        viewModel.sendMessage(selectedChat.id, text, type, rText, rSender, meta, delayMins)
                                    },
                                    onForwardMessage = { targetId, msg ->
                                        viewModel.sendMessage(targetId, "↪ Forwarded: ${msg.text}", msg.messageType, null, null, msg.mediaMeta, null)
                                    },
                                    onStarMessage = { msg -> viewModel.toggleStarMessage(selectedChat.id, msg) },
                                    onToggleReaction = { msg, emoji -> viewModel.toggleMessageReaction(selectedChat.id, msg, emoji) },
                                    onDeleteForMe = { msgId -> viewModel.deleteMessageForMe(selectedChat.id, msgId) },
                                    onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(selectedChat.id, msgId) },
                                    onOpenViewOnce = { msgId -> viewModel.openViewOnceMessage(selectedChat.id, msgId) },
                                    onSetDisappearing = { mode -> viewModel.setDisappearingMode(selectedChat.id, mode) },
                                    onSetWallpaper = { style -> viewModel.setWallpaperStyle(selectedChat.id, style) },
                                    onToggleChatLock = { viewModel.toggleLockChat(selectedChat) },
                                    onOpenAiAssistant = { msg ->
                                        aiTargetMessage = msg
                                        showAiSheet = true
                                    },
                                    inlineSummaryState = inlineSummaryState,
                                    suggestedRepliesState = suggestedRepliesState,
                                    onSummarizeThread = {
                                        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                        aiViewModel.summarizeThreadInline(selectedChat.title, msgs)
                                    },
                                    onDismissSummary = aiViewModel::dismissInlineSummary,
                                    onGenerateSuggestions = {
                                        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                        aiViewModel.generateThreadSuggestions(selectedChat.title, msgs)
                                    },
                                    onDismissSuggestions = aiViewModel::dismissSuggestedReplies,
                                    onOpenExportChat = {
                                        viewModel.resetExportState()
                                        showChatExportDialog = true
                                    },
                                    onStartVoiceCall = {
                                        activeCall = ActiveCallSession(selectedChat.title, false, false, 2, profile?.dataSaver ?: false)
                                    },
                                    onStartVideoCall = {
                                        activeCall = ActiveCallSession(selectedChat.title, true, selectedChat.chatType != "DIRECT", 8, profile?.dataSaver ?: false)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBluetoothSheet) {
        BluetoothMeshSheet(
            meshStatus = meshStatus,
            onDismiss = { showBluetoothSheet = false },
            onToggleOfflineMode = viewModel::toggleOfflineBluetoothMode,
            onStartScan = viewModel::startNearbyBluetoothScan,
            onStopScan = viewModel::stopNearbyBluetoothScan,
            onTogglePeerConnect = viewModel::togglePeerConnect,
            onCreateBluetoothGroup = { groupName ->
                viewModel.createNewChatOrBluetoothGroup(
                    title = groupName,
                    phone = "",
                    chatType = "BLUETOOTH_GROUP",
                    bluetoothChat = true,
                    communityName = "Nearby Mesh"
                )
            }
        )
    }

    if (showAiSheet && selectedChat != null) {
        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
        WhatsupAiSheet(
            chatTitle = selectedChat.title,
            messages = msgs,
            selectedMessageForTranslate = aiTargetMessage,
            aiViewModel = aiViewModel,
            onInsertReply = { draft ->
                viewModel.sendMessage(selectedChat.id, draft)
            },
            onDismiss = {
                aiViewModel.reset()
                showAiSheet = false
            }
        )
    }

    if (showNewChatDialog) {
        var contactName by remember { mutableStateOf("") }
        var contactPhone by remember { mutableStateOf("+92 300 ") }
        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            title = { Text("Start New Whatsup Chat") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = contactName,
                        onValueChange = { contactName = it },
                        label = { Text("Contact Name") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = contactPhone,
                        onValueChange = { contactPhone = it },
                        label = { Text("Phone (+92 ...)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (contactName.isNotBlank()) {
                            viewModel.createNewChatOrBluetoothGroup(
                                title = contactName.trim(),
                                phone = contactPhone.trim(),
                                chatType = "DIRECT",
                                bluetoothChat = meshStatus.offlineModeActive
                            )
                            showNewChatDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen)
                ) { Text("Start Chat") }
            },
            dismissButton = {
                TextButton(onClick = { showNewChatDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showChatExportDialog && selectedChat != null) {
        val docsPath = remember(context) {
            ChatHistoryExporter.getLocalDocumentsDir(context).absolutePath
        }
        ExportChatHistoryDialog(
            chats = allChats,
            initialChatId = selectedChat.id,
            exportState = exportState,
            exportedFiles = exportedFiles,
            localDocumentsPath = docsPath,
            onRefreshExports = { viewModel.refreshExportedFiles(context) },
            onExport = { chatId, format -> viewModel.exportChatHistory(context, chatId, format) },
            onDeleteExport = { file -> viewModel.deleteExportedFile(context, file) },
            onDismiss = {
                viewModel.resetExportState()
                showChatExportDialog = false
            }
        )
    }
}
