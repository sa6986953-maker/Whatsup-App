package com.example.ui.screens.settings

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DataSaverOn
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ReplyAll
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.ChatHistoryExporter
import com.example.core.ExportFormat
import com.example.core.ExportedChatFile
import com.example.core.LocalAppPreferences
import com.example.core.NotificationSoundCategory
import com.example.data.model.ChatThread
import com.example.data.model.UserProfile
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.MissedCallRed
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.ExportUiState

@Composable
fun SettingsScreen(
    profile: UserProfile?,
    localPrefs: LocalAppPreferences,
    allChats: List<ChatThread>,
    exportState: ExportUiState,
    exportedFiles: List<ExportedChatFile>,
    isGoogleSignedIn: Boolean = false,
    signedInEmail: String? = null,
    isAuthLoading: Boolean = false,
    authErrorMessage: String? = null,
    onBack: () -> Unit,
    onToggleDarkMode: (Boolean) -> Unit,
    onUpdatePrivacySettings: (Map<String, Any>) -> Unit,
    onSetAppLock: (enabled: Boolean, pin: String) -> Unit,
    onSwitchDualAccount: (slot: Int) -> Unit,
    onOpenBluetoothMesh: () -> Unit,
    onSelectNotificationSound: (category: NotificationSoundCategory, uri: String, displayName: String) -> Unit,
    onRefreshExports: () -> Unit,
    onExportChatHistory: (chatId: String?, format: ExportFormat) -> Unit,
    onDeleteExportFile: (ExportedChatFile) -> Unit,
    onResetExportState: () -> Unit,
    onConnectGoogleAccount: () -> Unit = {},
    onOpenOptionalCloudSetup: () -> Unit = {},
    onSignOut: () -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    var showAutoReplyDialog by remember { mutableStateOf(false) }
    var showSecurityCodeDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var pendingSoundCategory by remember { mutableStateOf<NotificationSoundCategory?>(null) }

    val audioDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        val category = pendingSoundCategory
        pendingSoundCategory = null
        if (uri != null && category != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            val title = resolveAudioTitle(context, uri)
            onSelectNotificationSound(category, uri.toString(), title)
        }
    }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val category = pendingSoundCategory
        pendingSoundCategory = null
        if (result.resultCode == Activity.RESULT_OK && category != null) {
            val data = result.data
            val pickedUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (pickedUri != null) {
                val title = resolveAudioTitle(context, pickedUri)
                onSelectNotificationSound(category, pickedUri.toString(), title)
            } else {
                onSelectNotificationSound(category, "", "Silent")
            }
        }
    }

    fun launchNotificationSoundPicker(category: NotificationSoundCategory, existingUri: String) {
        pendingSoundCategory = category
        val ringtoneIntent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select ${category.title} Sound")
            if (existingUri.isNotBlank()) {
                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(existingUri))
            } else {
                putExtra(
                    RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                )
            }
        }
        if (ringtoneIntent.resolveActivity(context.packageManager) != null) {
            ringtonePickerLauncher.launch(ringtoneIntent)
        } else {
            audioDocumentLauncher.launch(arrayOf("audio/*"))
        }
    }

    val activePhone = if (localPrefs.activeAccountSlot == 1) {
        profile?.phoneNumber ?: localPrefs.verifiedPhoneNumber
    } else {
        profile?.secondaryPhone ?: localPrefs.secondaryPhoneNumber
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .navigationBarsPadding()
    ) {
        Surface(
            color = if (localPrefs.darkMode) DarkTopBar else WhatsupDarkGreen,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(60.dp)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Settings", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.Bold)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Profile & Dual Account Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(WhatsupGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (profile?.displayName ?: "W").take(1).uppercase(),
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile?.displayName ?: "Whatsup User",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = activePhone,
                                style = MaterialTheme.typography.bodySmall,
                                color = WhatsupGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = profile?.about ?: "Assalam-o-Alaikum! Using Whatsup Mesh",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onSwitchDualAccount(1) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.SimCard, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (localPrefs.activeAccountSlot == 1) "SIM 1 ✓" else "SIM 1")
                        }
                        OutlinedButton(
                            onClick = { onSwitchDualAccount(2) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.SimCard, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (localPrefs.activeAccountSlot == 2) "SIM 2 ✓" else "SIM 2")
                        }
                    }
                }
            }

            SectionHeader("Privacy & Security")
            SettingSwitchRow(
                icon = Icons.Filled.VisibilityOff,
                title = "Hide Online Status",
                subtitle = "Appear offline while using Whatsup",
                checked = profile?.hideOnline ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("hideOnline" to it)) }
            )
            SettingSwitchRow(
                icon = Icons.Filled.VisibilityOff,
                title = "Read Receipts",
                subtitle = "If turned off, you won't send or see blue double ticks",
                checked = !(profile?.hideBlueTicks ?: false),
                testTag = "privacy_read_receipts_switch",
                onCheckedChange = { enabled ->
                    onUpdatePrivacySettings(mapOf("hideBlueTicks" to !enabled))
                }
            )
            SettingSwitchRow(
                icon = Icons.Filled.VisibilityOff,
                title = "Hide Last Seen",
                subtitle = "Hide your last seen timestamp",
                checked = profile?.hideLastSeen ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("hideLastSeen" to it)) }
            )
            SettingSwitchRow(
                icon = Icons.Filled.Fingerprint,
                title = "App Lock (Fingerprint / PIN)",
                subtitle = "Protect Whatsup with PIN (${localPrefs.appLockPin})",
                checked = localPrefs.appLockEnabled,
                onCheckedChange = { enabled ->
                    if (enabled) showPinDialog = true else onSetAppLock(false, localPrefs.appLockPin)
                }
            )
            SettingSwitchRow(
                icon = Icons.Filled.Key,
                title = "Two-Step Verification",
                subtitle = "Extra 6-digit PIN security",
                checked = profile?.twoStepEnabled ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("twoStepEnabled" to it)) }
            )
            SettingActionRow(
                icon = Icons.Filled.Security,
                title = "End-to-End Encryption Verification",
                subtitle = "Signal-style 60-digit safety number",
                onClick = { showSecurityCodeDialog = true }
            )

            HorizontalDivider()
            SectionHeader("Whatsup Pro Features")
            SettingActionRow(
                icon = Icons.Filled.BluetoothConnected,
                title = "Offline Bluetooth & Wi-Fi Direct Mesh",
                subtitle = "Manage 100m offline peer discovery & groups",
                tint = BluetoothBlue,
                onClick = onOpenBluetoothMesh
            )
            SettingSwitchRow(
                icon = Icons.Filled.DataSaverOn,
                title = "Data Saver Mode",
                subtitle = "Compress calls & defer media on slow 2G/3G networks",
                checked = profile?.dataSaver ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("dataSaver" to it)) }
            )
            SettingSwitchRow(
                icon = Icons.Filled.ReplyAll,
                title = "Auto-Reply for Business",
                subtitle = profile?.autoReplyText ?: "Automatically reply when busy",
                checked = profile?.autoReplyEnabled ?: false,
                onCheckedChange = { onUpdatePrivacySettings(mapOf("autoReplyEnabled" to it)) },
                onRowClick = { showAutoReplyDialog = true }
            )

            HorizontalDivider()
            SectionHeader("Chat Settings")
            SettingSwitchRow(
                icon = Icons.Filled.DarkMode,
                title = "Dark Mode",
                subtitle = "WhatsApp dark charcoal theme",
                checked = localPrefs.darkMode,
                onCheckedChange = onToggleDarkMode
            )
            SettingActionRow(
                icon = Icons.Filled.Download,
                title = "Export Chat History (JSON / TXT)",
                subtitle = "Save conversations to local Documents folder",
                tint = WhatsupGreen,
                testTag = "settings_export_chat_history",
                onClick = {
                    onResetExportState()
                    showExportDialog = true
                }
            )
            SettingActionRow(
                icon = Icons.Filled.Backup,
                title = if (isGoogleSignedIn) "Cloud Chat Backup (Active)" else "Cloud Chat Backup (Optional)",
                subtitle = if (isGoogleSignedIn) {
                    "Synced to Google account: ${signedInEmail ?: "Connected"}"
                } else {
                    "Local device storage active • Tap to optionally connect Google"
                },
                onClick = {
                    if (isGoogleSignedIn) {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Whatsup Encrypted Backup verified for $activePhone")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Whatsup Backup Info"))
                    } else {
                        onOpenOptionalCloudSetup()
                    }
                }
            )

            HorizontalDivider()
            SectionHeader("Notification Sounds")
            SettingActionRow(
                icon = Icons.Filled.Notifications,
                title = "Standard Messages Sound",
                subtitle = localPrefs.standardSoundName,
                tint = WhatsupGreen,
                testTag = "setting_sound_standard",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.STANDARD,
                        existingUri = localPrefs.standardSoundUri
                    )
                }
            )
            SettingActionRow(
                icon = Icons.Filled.NotificationsActive,
                title = "Urgent Messages Sound",
                subtitle = localPrefs.urgentSoundName,
                tint = MissedCallRed,
                testTag = "setting_sound_urgent",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.URGENT,
                        existingUri = localPrefs.urgentSoundUri
                    )
                }
            )
            SettingActionRow(
                icon = Icons.Filled.AlternateEmail,
                title = "Group Mentions Sound",
                subtitle = localPrefs.mentionSoundName,
                tint = BluetoothBlue,
                testTag = "setting_sound_mention",
                onClick = {
                    launchNotificationSoundPicker(
                        category = NotificationSoundCategory.GROUP_MENTION,
                        existingUri = localPrefs.mentionSoundUri
                    )
                }
            )

            HorizontalDivider()
            SectionHeader("Account & Cloud Sync (Optional)")
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isGoogleSignedIn) {
                            "Google Cloud Sync Connected"
                        } else {
                            "Local Mode Active (No Google Login Required)"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isGoogleSignedIn) {
                            "Signed in as ${signedInEmail ?: "Google User"}. You can disconnect anytime and stay in Local Mode."
                        } else {
                            "Whatsup works 100% locally and offline without Google login. Connect Google only if you want optional cloud sync."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!authErrorMessage.isNullOrBlank()) {
                        Text(
                            text = authErrorMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (isGoogleSignedIn) {
                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(containerColor = MissedCallRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("settings_sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Disconnect Google (Use Local Mode)", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onConnectGoogleAccount,
                            enabled = !isAuthLoading,
                            colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("settings_google_sign_in_button")
                        ) {
                            Text(
                                text = if (isAuthLoading) "Connecting Google..." else "Sign in with Google (Optional)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenOptionalCloudSetup,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("settings_phone_cloud_setup_button")
                        ) {
                            Text("Verify Phone (+92) / Sync Options")
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showAutoReplyDialog) {
        var text by remember { mutableStateOf(profile?.autoReplyText ?: "") }
        AlertDialog(
            onDismissRequest = { showAutoReplyDialog = false },
            title = { Text("Business Auto-Reply Message") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Auto-reply text") },
                    maxLines = 4
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotBlank()) {
                        onUpdatePrivacySettings(mapOf("autoReplyText" to text.trim(), "autoReplyEnabled" to true))
                        showAutoReplyDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAutoReplyDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showSecurityCodeDialog) {
        AlertDialog(
            onDismissRequest = { showSecurityCodeDialog = false },
            icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("End-to-End Encryption") },
            text = {
                Text(
                    "Signal-Style Safety Number:\n\n88412  90124  55612  77219\n31048  66291  09128  44510\n\nAll 1-to-1 chats, voice/video calls, and Offline Bluetooth packets are encrypted end-to-end."
                )
            },
            confirmButton = {
                TextButton(onClick = { showSecurityCodeDialog = false }) { Text("Verified") }
            }
        )
    }

    if (showPinDialog) {
        var pin by remember { mutableStateOf(localPrefs.appLockPin) }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Set App Lock PIN") },
            text = {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6) },
                    label = { Text("4-6 digit PIN") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (pin.length >= 4) {
                        onSetAppLock(true, pin)
                        showPinDialog = false
                    }
                }) { Text("Enable Lock") }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showExportDialog) {
        val docsPath = remember(context) {
            ChatHistoryExporter.getLocalDocumentsDir(context).absolutePath
        }
        ExportChatHistoryDialog(
            chats = allChats,
            initialChatId = null,
            exportState = exportState,
            exportedFiles = exportedFiles,
            localDocumentsPath = docsPath,
            onRefreshExports = onRefreshExports,
            onExport = onExportChatHistory,
            onDeleteExport = onDeleteExportFile,
            onDismiss = {
                onResetExportState()
                showExportDialog = false
            }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = WhatsupGreen,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun SettingSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String? = null,
    onRowClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onRowClick?.invoke() ?: onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = WhatsupGreen),
            modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier
        )
    }
}

@Composable
private fun SettingActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    testTag: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .let { if (testTag != null) it.testTag(testTag) else it }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun resolveAudioTitle(context: Context, uri: Uri): String {
    val ringtoneTitle = try {
        RingtoneManager.getRingtone(context, uri)?.getTitle(context)
    } catch (_: Exception) {
        null
    }
    if (!ringtoneTitle.isNullOrBlank() && !ringtoneTitle.equals("Unknown ringtone", ignoreCase = true)) {
        return ringtoneTitle
    }
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment ?: "Custom Audio"
}
