package com.example.ui.screens.updates

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.StatusUpdate
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun StatusStoryViewer(
    stories: List<StatusUpdate>,
    initialIndex: Int,
    onMarkViewed: (StatusUpdate) -> Unit,
    onDismiss: () -> Unit
) {
    if (stories.isEmpty()) return

    var currentIndex by remember(stories) {
        mutableIntStateOf(initialIndex.coerceIn(0, stories.lastIndex))
    }
    var visible by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    fun closeWithFadeOut() {
        scope.launch {
            visible = false
            delay(220)
            onDismiss()
        }
    }

    fun goNext() {
        if (currentIndex < stories.lastIndex) {
            currentIndex += 1
        } else {
            closeWithFadeOut()
        }
    }

    fun goPrevious() {
        if (currentIndex > 0) {
            currentIndex -= 1
        } else {
            scope.launch { progress.snapTo(0f) }
        }
    }

    LaunchedEffect(Unit) {
        visible = true
    }

    LaunchedEffect(currentIndex) {
        onMarkViewed(stories[currentIndex])
        progress.snapTo(0f)
    }

    LaunchedEffect(currentIndex, isPaused, visible) {
        if (!visible || isPaused) return@LaunchedEffect
        val remainingFraction = (1f - progress.value).coerceIn(0f, 1f)
        val durationMs = (5000f * remainingFraction).toInt().coerceAtLeast(100)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = durationMs, easing = LinearEasing)
        )
        if (!isPaused && visible && progress.value >= 0.99f) {
            goNext()
        }
    }

    Dialog(
        onDismissRequest = { closeWithFadeOut() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BackHandler { closeWithFadeOut() }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(240)) + scaleIn(initialScale = 0.95f, animationSpec = tween(260, easing = FastOutSlowInEasing)),
            exit = fadeOut(tween(220))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(currentIndex, stories.size) {
                        var dragDelta = 0f
                        detectHorizontalDragGestures(
                            onDragStart = {
                                dragDelta = 0f
                                isPaused = true
                            },
                            onDragEnd = {
                                isPaused = false
                                if (dragDelta < -90f) {
                                    goNext()
                                } else if (dragDelta > 90f) {
                                    goPrevious()
                                }
                            },
                            onDragCancel = { isPaused = false },
                            onHorizontalDrag = { _, amount ->
                                dragDelta += amount
                            }
                        )
                    }
                    .pointerInput(currentIndex, stories.size) {
                        detectTapGestures(
                            onPress = {
                                isPaused = true
                                tryAwaitRelease()
                                isPaused = false
                            },
                            onTap = { offset ->
                                if (offset.x < size.width * 0.35f) {
                                    goPrevious()
                                } else {
                                    goNext()
                                }
                            }
                        )
                    }
            ) {
                // Smooth slide-in and fade-out animated story transitions across users
                AnimatedContent(
                    targetState = currentIndex,
                    transitionSpec = {
                        val movingForward = targetState >= initialState
                        val enterAnim = slideInHorizontally(
                            animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
                            initialOffsetX = { fullWidth -> if (movingForward) fullWidth else -fullWidth }
                        ) + fadeIn(animationSpec = tween(durationMillis = 280))

                        val exitAnim = slideOutHorizontally(
                            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                            targetOffsetX = { fullWidth -> if (movingForward) -fullWidth / 3 else fullWidth / 3 }
                        ) + fadeOut(animationSpec = tween(durationMillis = 250))

                        enterAnim togetherWith exitAnim
                    },
                    label = "status_story_transition",
                    modifier = Modifier.fillMaxSize()
                ) { index ->
                    val story = stories[index]
                    val baseColor = Color(story.bgColorHex)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        baseColor.copy(alpha = 0.95f),
                                        baseColor,
                                        Color(0xFF0A1419)
                                    )
                                )
                            )
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Top spacer for progress bar + header rendered consistently above
                            Spacer(modifier = Modifier.height(78.dp))

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Surface(
                                        color = Color.White.copy(alpha = 0.16f),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Text(
                                            text = story.statusType,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(18.dp))
                                    Text(
                                        text = story.caption,
                                        style = MaterialTheme.typography.headlineMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.testTag("story_caption_text")
                                    )
                                }
                            }

                            // Who Viewed Footer
                            Surface(
                                color = Color.Black.copy(alpha = 0.36f),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Visibility,
                                        contentDescription = "Views",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Viewed by ${story.viewedByCount}: ${story.viewersSummary}",
                                        color = Color.White,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }

                // Segmented Progress Indicators & Top Story Controls Overlay
                val activeStory = stories[currentIndex]
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        stories.forEachIndexed { idx, _ ->
                            val fill = when {
                                idx < currentIndex -> 1f
                                idx == currentIndex -> progress.value
                                else -> 0f
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Color.White.copy(alpha = 0.32f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fill)
                                        .background(Color.White)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color.White, CircleShape)
                                .background(Color.Black.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = activeStory.authorName.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeStory.authorName,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("story_author_name")
                            )
                            Text(
                                text = "${activeStory.timeLabel} • ${currentIndex + 1} of ${stories.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        IconButton(
                            onClick = { goPrevious() },
                            enabled = currentIndex > 0,
                            modifier = Modifier.testTag("story_prev_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                contentDescription = "Previous Status",
                                tint = if (currentIndex > 0) Color.White else Color.White.copy(alpha = 0.35f)
                            )
                        }
                        IconButton(
                            onClick = { goNext() },
                            modifier = Modifier.testTag("story_next_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Next Status",
                                tint = Color.White
                            )
                        }
                        IconButton(
                            onClick = { closeWithFadeOut() },
                            modifier = Modifier.testTag("story_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close Status",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
