package com.example.ui.screens.updates

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.StatusUpdate
import com.example.data.model.UiState
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen

@Composable
fun UpdatesScreen(
    statusesState: UiState<List<StatusUpdate>>,
    myDisplayName: String,
    onPostStatus: (authorName: String, caption: String, statusType: String, bgColorHex: Long) -> Unit,
    onMarkViewed: (StatusUpdate) -> Unit
) {
    var showCreateTextStatus by remember { mutableStateOf(false) }
    var activeViewerList by remember { mutableStateOf<List<StatusUpdate>>(emptyList()) }
    var activeViewerStartIndex by remember { mutableStateOf<Int?>(null) }
    var captionInput by remember { mutableStateOf("") }

    val statusPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPostStatus(myDisplayName, "📸 Photo Story (${uri.lastPathSegment ?: "HD"})", "PHOTO", 0xFF075E54L)
        }
    }

    when (statusesState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = WhatsupGreen)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(statusesState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val all = statusesState.data
            val stories = all.filter { it.statusType != "CHANNEL" }
            val channels = all.filter { it.statusType == "CHANNEL" }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "status_header") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Status (24h)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row {
                            IconButton(
                                onClick = { showCreateTextStatus = true },
                                modifier = Modifier.testTag("add_text_status_button")
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Text Status", tint = WhatsupDarkGreen)
                            }
                            IconButton(
                                onClick = {
                                    statusPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                },
                                modifier = Modifier.testTag("add_media_status_button")
                            ) {
                                Icon(Icons.Filled.PhotoCamera, contentDescription = "Photo/Video Status", tint = WhatsupDarkGreen)
                            }
                        }
                    }
                }

                // My Status Tile
                item(key = "my_status") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { showCreateTextStatus = true }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(54.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(WhatsupDarkGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = myDisplayName.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .align(Alignment.BottomEnd)
                                    .clip(CircleShape)
                                    .background(WhatsupGreen)
                                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("My status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Tap to add text, photo or 2GB video update",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item(key = "recent_updates_label") {
                    Text(
                        text = "Recent updates",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                items(stories, key = { it.id }) { status ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                val idx = stories.indexOfFirst { it.id == status.id }.coerceAtLeast(0)
                                activeViewerList = stories
                                activeViewerStartIndex = idx
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .border(
                                    width = 2.5.dp,
                                    color = if (status.viewed) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f) else WhatsupGreen,
                                    shape = CircleShape
                                )
                                .padding(4.dp)
                                .clip(CircleShape)
                                .background(Color(status.bgColorHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = status.authorName.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(status.authorName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "${status.timeLabel} • ${status.statusType}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Filled.Visibility,
                                contentDescription = "Views",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(status.viewedByCount.toString(), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                item(key = "channels_header") {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Channels",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Stay updated on Pakistan tech, cricket & Whatsup releases",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                items(channels, key = { it.id }) { channel ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val idx = channels.indexOfFirst { it.id == channel.id }.coerceAtLeast(0)
                                activeViewerList = channels
                                activeViewerStartIndex = idx
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(BluetoothBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Campaign, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(channel.authorName, fontWeight = FontWeight.Bold)
                                Text(channel.caption, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                Text(
                                    channel.viewersSummary,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = WhatsupGreen
                                )
                            }
                            OutlinedButton(onClick = {
                                val idx = channels.indexOfFirst { it.id == channel.id }.coerceAtLeast(0)
                                activeViewerList = channels
                                activeViewerStartIndex = idx
                            }) {
                                Text("View")
                            }
                        }
                    }
                }

                item(key = "updates_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (showCreateTextStatus) {
        AlertDialog(
            onDismissRequest = { showCreateTextStatus = false },
            title = { Text("New 24-Hour Status") },
            text = {
                OutlinedTextField(
                    value = captionInput,
                    onValueChange = { captionInput = it },
                    label = { Text("Share an update in Roman Urdu or English...") },
                    maxLines = 4,
                    modifier = Modifier.testTag("status_caption_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (captionInput.isNotBlank()) {
                            onPostStatus(myDisplayName, captionInput.trim(), "TEXT", 0xFF128C7EL)
                            captionInput = ""
                            showCreateTextStatus = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                    modifier = Modifier.testTag("post_status_button")
                ) { Text("Post Status") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateTextStatus = false }) { Text("Cancel") }
            }
        )
    }

    if (activeViewerStartIndex != null && activeViewerList.isNotEmpty()) {
        StatusStoryViewer(
            stories = activeViewerList,
            initialIndex = activeViewerStartIndex!!,
            onMarkViewed = onMarkViewed,
            onDismiss = {
                activeViewerStartIndex = null
                activeViewerList = emptyList()
            }
        )
    }
}
