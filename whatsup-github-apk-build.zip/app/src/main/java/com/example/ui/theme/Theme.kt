package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WhatsupLightColorScheme = lightColorScheme(
    primary = WhatsupEmeraldAccent,
    onPrimary = Color.White,
    primaryContainer = LightSentBubble,
    onPrimaryContainer = WhatsupDarkGreen,
    secondary = WhatsupTealGreen,
    onSecondary = Color.White,
    secondaryContainer = BluetoothBlueContainer,
    onSecondaryContainer = BluetoothBlue,
    tertiary = BluetoothBlue,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightBackground,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outlineVariant = LightDivider
)

private val WhatsupDarkColorScheme = darkColorScheme(
    primary = WhatsupGreen,
    onPrimary = Color(0xFF003919),
    primaryContainer = DarkSentBubble,
    onPrimaryContainer = DarkTextPrimary,
    secondary = WhatsupTealGreen,
    onSecondary = Color.White,
    secondaryContainer = BluetoothBlueDarkContainer,
    onSecondaryContainer = BluetoothBlue,
    tertiary = BluetoothBlue,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outlineVariant = DarkDivider
)

@Composable
fun WhatsupTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) WhatsupDarkColorScheme else WhatsupLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = WhatsupTypography,
        content = content
    )
}
