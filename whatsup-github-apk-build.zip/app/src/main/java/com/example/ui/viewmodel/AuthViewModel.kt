package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.PreferencesManager
import com.example.data.repository.AuthRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val phoneNumberInput: String = "300 4512980",
    val otpCodeInput: String = "",
    val otpSent: Boolean = false,
    val phoneVerified: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoBanner: String? = null
)

class AuthViewModel(
    private val authRepository: AuthRepository,
    private val preferencesManager: PreferencesManager
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = authRepository.observeAuthUser()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = authRepository.currentUser()
        )

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun attemptSilentSignIn(context: Context) {
        viewModelScope.launch {
            authRepository.attemptAutoSignIn(context)
        }
    }

    fun updatePhoneNumber(input: String) {
        _uiState.value = _uiState.value.copy(
            phoneNumberInput = input.filter { it.isDigit() || it == ' ' }.take(13),
            errorMessage = null
        )
    }

    fun updateOtpCode(input: String) {
        _uiState.value = _uiState.value.copy(
            otpCodeInput = input.filter { it.isDigit() }.take(6),
            errorMessage = null
        )
    }

    fun requestOtp() {
        val digits = _uiState.value.phoneNumberInput.filter { it.isDigit() }
        if (digits.length < 10) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Enter a valid 10-digit Pakistan mobile number (+92 3XX XXXXXXX)"
            )
            return
        }
        _uiState.value = _uiState.value.copy(
            otpSent = true,
            otpCodeInput = "482910",
            errorMessage = null,
            infoBanner = "6-digit verification code sent to +92 ${_uiState.value.phoneNumberInput}"
        )
    }

    fun verifyOtpAndProceed() {
        val otp = _uiState.value.otpCodeInput
        if (otp.length != 6) {
            _uiState.value = _uiState.value.copy(errorMessage = "Enter the 6-digit OTP code")
            return
        }
        val formattedPhone = "+92 ${_uiState.value.phoneNumberInput.trim()}"
        viewModelScope.launch {
            preferencesManager.setVerifiedPhoneNumber(formattedPhone)
            _uiState.value = _uiState.value.copy(
                phoneVerified = true,
                errorMessage = null,
                infoBanner = "Phone $formattedPhone saved! You can use Whatsup directly or optionally connect Google for Cloud Sync."
            )
        }
    }

    fun signInWithGoogle(activity: Activity) {
        if (_uiState.value.isLoading) return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val formattedPhone = "+92 ${_uiState.value.phoneNumberInput.trim().ifBlank { "300 4512980" }}"
            preferencesManager.setVerifiedPhoneNumber(formattedPhone)
            val result = authRepository.signInWithGoogleInteractive(activity)
            result.fold(
                onSuccess = {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = null,
                        infoBanner = "Google Cloud Sync connected!"
                    )
                },
                onFailure = { error ->
                    if (error is GetCredentialCancellationException) {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = "Google Sign-In was cancelled. Local mode remains active."
                        )
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = error.localizedMessage ?: "Sign-in failed. Local mode remains active."
                        )
                    }
                }
            )
        }
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, infoBanner = null)
    }

    fun signOut(context: Context) {
        viewModelScope.launch {
            authRepository.signOut(context)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                errorMessage = null,
                infoBanner = "Switched back to Local Mode (no Google account linked)."
            )
        }
    }
}
