package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ChatHistoryExporter
import com.example.core.ExportFormat
import com.example.core.ExportedChatFile
import com.example.core.LocalAppPreferences
import com.example.core.MeshStatus
import com.example.core.NotificationSoundCategory
import com.example.core.OfflineMeshEngine
import com.example.core.PreferencesManager
import com.example.data.model.CallRecord
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.StatusUpdate
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.repository.WhatsupRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "WhatsupViewModel"

sealed interface ExportUiState {
    data object Idle : ExportUiState
    data object Exporting : ExportUiState
    data class Success(val file: ExportedChatFile) : ExportUiState
    data class Error(val message: String) : ExportUiState
}

class WhatsupViewModel(
    private val repository: WhatsupRepository,
    private val preferencesManager: PreferencesManager,
    private val offlineMeshEngine: OfflineMeshEngine,
    private val currentUserId: String,
    initialDisplayName: String
) : ViewModel() {

    val localPrefs: StateFlow<LocalAppPreferences> = preferencesManager.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), LocalAppPreferences())

    val meshStatus: StateFlow<MeshStatus> = offlineMeshEngine.status

    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId: StateFlow<String?> = _selectedChatId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    private val _exportState = MutableStateFlow<ExportUiState>(ExportUiState.Idle)
    val exportState: StateFlow<ExportUiState> = _exportState.asStateFlow()

    private val _exportedFiles = MutableStateFlow<List<ExportedChatFile>>(emptyList())
    val exportedFiles: StateFlow<List<ExportedChatFile>> = _exportedFiles.asStateFlow()

    val userProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load profile")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val chatsState: StateFlow<UiState<List<ChatThread>>> = repository.observeChats(currentUserId)
        .map<List<ChatThread>, UiState<List<ChatThread>>> { chats ->
            val sorted = chats.sortedWith(
                compareByDescending<ChatThread> { it.pinned }
                    .thenByDescending { it.sortOrder }
            )
            UiState.Success(sorted)
        }
        .catch { error -> emit(mapFirestoreError(error, "Failed to observe chats")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeMessagesState: StateFlow<UiState<List<ChatMessage>>> = _selectedChatId
        .flatMapLatest { chatId ->
            if (chatId.isNullOrBlank()) {
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeMessages(currentUserId, chatId)
                    .map<List<ChatMessage>, UiState<List<ChatMessage>>> { msgs ->
                        val pendingBt = msgs.filter { it.viaBluetooth && it.tickStatus == "PENDING_SYNC" }.map { it.id }
                        offlineMeshEngine.updatePendingSyncCount(pendingBt.size)
                        UiState.Success(msgs)
                    }
                    .catch { error -> emit(mapFirestoreError(error, "Failed to load messages")) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val statusesState: StateFlow<UiState<List<StatusUpdate>>> = repository.observeStatuses(currentUserId)
        .map<List<StatusUpdate>, UiState<List<StatusUpdate>>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load statuses")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val callsState: StateFlow<UiState<List<CallRecord>>> = repository.observeCalls(currentUserId)
        .map<List<CallRecord>, UiState<List<CallRecord>>> { UiState.Success(it) }
        .catch { error -> emit(mapFirestoreError(error, "Failed to load calls")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    init {
        viewModelScope.launch {
            val phone = localPrefs.value.verifiedPhoneNumber
            repository.ensureUserAndSeedPakistaniData(
                displayName = initialDisplayName,
                phoneNumber = phone
            ).onFailure { error ->
                _actionMessage.value = error.localizedMessage ?: "Unable to sync initial data"
            }
        }
    }

    private fun <T> mapFirestoreError(error: Throwable, fallback: String): UiState<T> {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val root = firestoreError ?: error
        Log.w(TAG, fallback, root)
        return UiState.Error(root.message ?: fallback)
    }

    fun selectChat(chatId: String?) {
        _selectedChatId.value = chatId
        if (!chatId.isNullOrBlank()) {
            viewModelScope.launch {
                repository.updateChatFlags(chatId, mapOf("unreadCount" to 0L))
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearActionMessage() {
        _actionMessage.value = null
    }

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setDarkMode(enabled) }
    }

    fun toggleOfflineBluetoothMode(enabled: Boolean) {
        offlineMeshEngine.setManualOfflineMode(enabled)
        viewModelScope.launch {
            preferencesManager.setBluetoothPreferred(enabled)
        }
        _actionMessage.value = if (enabled) {
            "Offline Bluetooth Mesh Mode ON — Messages queue locally & broadcast to nearby peers"
        } else {
            "Cloud Mode ON — Auto-syncing pending Bluetooth messages"
        }
    }

    fun startNearbyBluetoothScan() {
        offlineMeshEngine.startNearbyScan()
    }

    fun stopNearbyBluetoothScan() {
        offlineMeshEngine.stopScan()
    }

    fun togglePeerConnect(peerId: String) {
        offlineMeshEngine.togglePeerConnection(peerId)
    }

    fun sendMessage(
        chatId: String,
        text: String,
        messageType: String = "TEXT",
        replyToText: String? = null,
        replyToSender: String? = null,
        mediaMeta: String? = null,
        scheduledMinutesDelay: Int? = null
    ) {
        val viaBt = meshStatus.value.offlineModeActive
        val scheduledFor = scheduledMinutesDelay?.let { System.currentTimeMillis() + it * 60_000L }
        viewModelScope.launch {
            if (scheduledMinutesDelay != null && scheduledMinutesDelay > 0) {
                _actionMessage.value = "Scheduled message for +$scheduledMinutesDelay min (Whatsup Scheduler)"
            }
            val result = repository.sendMessage(
                chatId = chatId,
                text = text,
                messageType = messageType,
                viaBluetooth = viaBt,
                replyToText = replyToText,
                replyToSender = replyToSender,
                mediaMeta = mediaMeta,
                scheduledForMillis = scheduledFor
            )
            result.onFailure {
                _actionMessage.value = it.localizedMessage ?: "Failed to send message"
            }.onSuccess {
                // Simulate natural realistic auto-reply if Business Auto-Reply or online peer responds
                if (viaBt) {
                    _actionMessage.value = "Sent via 100m Bluetooth Mesh"
                }
            }
        }
    }

    fun syncPendingBluetooth(chatId: String, messages: List<ChatMessage>) {
        val pendingIds = messages.filter { it.viaBluetooth && it.tickStatus == "PENDING_SYNC" }.map { it.id }
        if (pendingIds.isEmpty()) {
            _actionMessage.value = "All Bluetooth messages are already synced to Cloud"
            return
        }
        viewModelScope.launch {
            repository.syncPendingBluetoothMessages(currentUserId, chatId, pendingIds)
                .onSuccess {
                    offlineMeshEngine.updatePendingSyncCount(0)
                    _actionMessage.value = "Synced ${pendingIds.size} offline Bluetooth message(s) to Cloud!"
                }
                .onFailure {
                    _actionMessage.value = it.localizedMessage ?: "Sync failed"
                }
        }
    }

    fun togglePinChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateChatFlags(chat.id, mapOf("pinned" to !chat.pinned))
                .onSuccess {
                    _actionMessage.value = if (!chat.pinned) {
                        "Pinned ${chat.title} to top"
                    } else {
                        "Unpinned ${chat.title}"
                    }
                }
        }
    }

    fun toggleArchiveChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateChatFlags(chat.id, mapOf("archived" to !chat.archived))
            _actionMessage.value = if (!chat.archived) "Chat archived" else "Chat unarchived"
        }
    }

    fun toggleMuteChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateChatFlags(chat.id, mapOf("muted" to !chat.muted))
        }
    }

    fun toggleLockChat(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateChatFlags(chat.id, mapOf("locked" to !chat.locked))
            _actionMessage.value = if (!chat.locked) "Chat locked with Biometric/PIN" else "Chat unlocked"
        }
    }

    fun toggleAdminOnlySend(chat: ChatThread) {
        viewModelScope.launch {
            repository.updateChatFlags(chat.id, mapOf("onlyAdminCanSend" to !chat.onlyAdminCanSend))
        }
    }

    fun setDisappearingMode(chatId: String, mode: String) {
        viewModelScope.launch {
            repository.updateChatFlags(chatId, mapOf("disappearingMode" to mode))
            _actionMessage.value = "Disappearing messages set to $mode"
        }
    }

    fun setWallpaperStyle(chatId: String, style: String) {
        viewModelScope.launch {
            repository.updateChatFlags(chatId, mapOf("wallpaperStyle" to style))
            _actionMessage.value = "Chat wallpaper updated"
        }
    }

    fun toggleStarMessage(chatId: String, message: ChatMessage) {
        viewModelScope.launch {
            repository.updateMessageAction(chatId, message.id, mapOf("starred" to !message.starred))
        }
    }

    fun toggleMessageReaction(chatId: String, message: ChatMessage, emoji: String) {
        viewModelScope.launch {
            repository.toggleMessageReaction(chatId, message, emoji)
                .onFailure { error ->
                    _actionMessage.value = error.localizedMessage ?: "Failed to update reaction"
                }
        }
    }

    fun deleteMessageForMe(chatId: String, messageId: String) {
        viewModelScope.launch {
            repository.updateMessageAction(chatId, messageId, mapOf("deletedForMe" to true))
        }
    }

    fun deleteMessageForEveryone(chatId: String, messageId: String) {
        viewModelScope.launch {
            repository.updateMessageAction(
                chatId,
                messageId,
                mapOf(
                    "deletedForEveryone" to true,
                    "text" to "🚫 This message was deleted"
                )
            )
        }
    }

    fun openViewOnceMessage(chatId: String, messageId: String) {
        viewModelScope.launch {
            delay(250)
            repository.updateMessageAction(chatId, messageId, mapOf("viewOnceOpened" to true))
        }
    }

    fun createNewChatOrBluetoothGroup(
        title: String,
        phone: String,
        chatType: String,
        bluetoothChat: Boolean,
        communityName: String? = null
    ) {
        viewModelScope.launch {
            repository.createChatOrGroup(title, phone, chatType, bluetoothChat, communityName)
                .onSuccess { newId ->
                    _selectedChatId.value = newId
                    _actionMessage.value = "Created $title"
                }
                .onFailure {
                    _actionMessage.value = it.localizedMessage ?: "Failed to create chat"
                }
        }
    }

    fun postStatus(authorName: String, caption: String, statusType: String, bgColorHex: Long) {
        viewModelScope.launch {
            repository.postStatus(authorName, caption, statusType, bgColorHex)
                .onSuccess { _actionMessage.value = "Status posted for 24 hours!" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to post status" }
        }
    }

    fun markStatusViewed(status: StatusUpdate) {
        if (status.viewed) return
        viewModelScope.launch {
            repository.markStatusViewed(status.id, status.viewedByCount)
        }
    }

    fun startOrLogCall(
        peerName: String,
        callType: String,
        participantCount: Long = 2L,
        recorded: Boolean = false,
        callLinkCode: String? = null
    ) {
        viewModelScope.launch {
            repository.logCall(peerName, callType, participantCount, recorded, callLinkCode)
        }
    }

    fun updatePrivacyAndSettings(updates: Map<String, Any>) {
        viewModelScope.launch {
            repository.updateUserProfileSettings(updates)
                .onSuccess { _actionMessage.value = "Settings saved to Cloud" }
                .onFailure { _actionMessage.value = it.localizedMessage ?: "Failed to update settings" }
        }
    }

    fun setAppLock(enabled: Boolean, pin: String) {
        viewModelScope.launch {
            preferencesManager.setAppLock(enabled, pin)
            repository.updateUserProfileSettings(mapOf("appLockEnabled" to enabled))
            _actionMessage.value = if (enabled) "App Lock enabled (PIN/Biometric)" else "App Lock disabled"
        }
    }

    fun switchDualAccount(slot: Int) {
        viewModelScope.launch {
            preferencesManager.setActiveAccountSlot(slot)
            _actionMessage.value = "Switched to SIM $slot account"
        }
    }

    fun setNotificationSound(
        category: NotificationSoundCategory,
        uri: String,
        displayName: String
    ) {
        viewModelScope.launch {
            preferencesManager.setNotificationSound(category, uri, displayName)
            _actionMessage.value = "${category.title} sound set to $displayName"
        }
    }

    fun refreshExportedFiles(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            val files = withContext(Dispatchers.IO) {
                ChatHistoryExporter.listExportedFiles(appContext)
            }
            _exportedFiles.value = files
        }
    }

    fun exportChatHistory(context: Context, chatId: String?, format: ExportFormat) {
        val appContext = context.applicationContext
        val availableChats = (chatsState.value as? UiState.Success)?.data ?: emptyList()
        val targetChats = if (chatId == null) {
            availableChats
        } else {
            availableChats.filter { it.id == chatId }
        }
        if (targetChats.isEmpty()) {
            _exportState.value = ExportUiState.Error("No chats available to export yet.")
            return
        }

        val profile = (userProfile.value as? UiState.Success)?.data
        val activePhone = if (localPrefs.value.activeAccountSlot == 1) {
            profile?.phoneNumber ?: localPrefs.value.verifiedPhoneNumber
        } else {
            profile?.secondaryPhone ?: localPrefs.value.secondaryPhoneNumber
        }
        val scopeLabel = if (chatId == null) "All Chats" else targetChats.first().title

        viewModelScope.launch {
            _exportState.value = ExportUiState.Exporting
            try {
                val activeId = _selectedChatId.value
                val activeMsgs = (activeMessagesState.value as? UiState.Success)?.data

                val chatEntries = targetChats.map { thread ->
                    val fetched = repository.getMessagesSnapshot(thread.id).getOrNull()
                    val msgs = when {
                        !fetched.isNullOrEmpty() -> fetched
                        thread.id == activeId && !activeMsgs.isNullOrEmpty() -> activeMsgs
                        else -> fetched ?: emptyList()
                    }
                    thread to msgs
                }

                val exported = withContext(Dispatchers.IO) {
                    ChatHistoryExporter.exportToLocalDocuments(
                        context = appContext,
                        accountPhone = activePhone,
                        scopeLabel = scopeLabel,
                        chatEntries = chatEntries,
                        format = format
                    )
                }
                val updatedList = withContext(Dispatchers.IO) {
                    ChatHistoryExporter.listExportedFiles(appContext)
                }
                _exportedFiles.value = updatedList
                _exportState.value = ExportUiState.Success(exported)
                _actionMessage.value = "Exported ${exported.name} to local Documents"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Chat history export failed", e)
                _exportState.value = ExportUiState.Error(
                    e.localizedMessage ?: "Failed to export chat history."
                )
            }
        }
    }

    fun deleteExportedFile(context: Context, file: ExportedChatFile) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                ChatHistoryExporter.deleteExportedFile(file.absolutePath)
            }
            _exportedFiles.value = withContext(Dispatchers.IO) {
                ChatHistoryExporter.listExportedFiles(appContext)
            }
            _actionMessage.value = "Deleted ${file.name}"
        }
    }

    fun resetExportState() {
        _exportState.value = ExportUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        offlineMeshEngine.release()
    }
}
