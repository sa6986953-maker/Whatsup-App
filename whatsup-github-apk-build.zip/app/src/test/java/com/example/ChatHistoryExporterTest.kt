package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.ChatHistoryExporter
import com.example.core.ExportFormat
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChatHistoryExporterTest {

    private fun sampleThread(): Pair<ChatThread, List<ChatMessage>> {
        val thread = ChatThread(
            id = "chat_ammi",
            title = "Ammi",
            phone = "+92 300 1122334",
            chatType = "DIRECT",
            disappearingMode = "OFF",
            bluetoothChat = false
        )
        val messages = listOf(
            ChatMessage(
                id = "m1",
                chatId = "chat_ammi",
                senderName = "Ammi",
                fromMe = false,
                text = "Beta ghar kab aa rahe ho?",
                messageType = "TEXT",
                tickStatus = "READ",
                timeLabel = "9:10 AM"
            ),
            ChatMessage(
                id = "m2",
                chatId = "chat_ammi",
                senderName = "Me",
                fromMe = true,
                text = "Bus 20 minute mein pohnch raha hoon!",
                messageType = "TEXT",
                tickStatus = "DELIVERED",
                viaBluetooth = true,
                starred = true,
                timeLabel = "9:12 AM"
            ),
            ChatMessage(
                id = "m3",
                chatId = "chat_ammi",
                senderName = "Me",
                fromMe = true,
                text = "Hidden deleted message",
                deletedForMe = true,
                timeLabel = "9:15 AM"
            )
        )
        return thread to messages
    }

    @Test
    fun `export json and txt stores files in local documents directory`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val entry = sampleThread()

        val jsonExport = ChatHistoryExporter.exportToLocalDocuments(
            context = context,
            accountPhone = "+92 300 4512980",
            scopeLabel = "Ammi",
            chatEntries = listOf(entry),
            format = ExportFormat.JSON
        )

        val jsonFile = File(jsonExport.absolutePath)
        assertTrue(jsonFile.exists())
        assertTrue(jsonExport.name.endsWith(".json"))

        val parsed = JSONObject(jsonFile.readText(Charsets.UTF_8))
        assertEquals("Whatsup", parsed.getString("app"))
        assertEquals(1, parsed.getInt("chatCount"))
        assertEquals(2, parsed.getInt("totalMessages"))
        val exportedMsgs = parsed.getJSONArray("chats").getJSONObject(0).getJSONArray("messages")
        assertEquals(2, exportedMsgs.length())
        assertTrue(exportedMsgs.getJSONObject(1).getBoolean("viaBluetooth"))

        val txtExport = ChatHistoryExporter.exportToLocalDocuments(
            context = context,
            accountPhone = "+92 300 4512980",
            scopeLabel = "Ammi",
            chatEntries = listOf(entry),
            format = ExportFormat.TXT
        )
        val txtFile = File(txtExport.absolutePath)
        assertTrue(txtFile.exists())
        val txtContent = txtFile.readText(Charsets.UTF_8)
        assertTrue(txtContent.contains("Whatsup Chat History Export"))
        assertTrue(txtContent.contains("Beta ghar kab aa rahe ho?"))
        assertTrue(txtContent.contains("[Sent via Bluetooth]"))
        assertFalse(txtContent.contains("Hidden deleted message"))

        val listed = ChatHistoryExporter.listExportedFiles(context)
        assertTrue(listed.any { it.name == jsonExport.name })
        assertTrue(listed.any { it.name == txtExport.name })

        assertTrue(ChatHistoryExporter.deleteExportedFile(jsonExport.absolutePath))
        assertTrue(ChatHistoryExporter.deleteExportedFile(txtExport.absolutePath))
        assertFalse(jsonFile.exists())
    }
}
