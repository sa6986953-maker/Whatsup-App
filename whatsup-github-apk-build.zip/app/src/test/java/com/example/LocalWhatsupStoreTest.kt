package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.LocalWhatsupStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalWhatsupStoreTest {

    @Test
    fun localStoreWorksAndPersistsWithoutGoogleLogin() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = LocalWhatsupStore(context)

        store.ensureInitialized(displayName = "Hamza", phoneNumber = "+92 300 4512980")

        val chats = store.observeChats().first()
        assertTrue(chats.isNotEmpty())
        val firstChat = chats.first()

        store.sendMessage(
            chatId = firstChat.id,
            text = "Salam without Google Login!",
            messageType = "TEXT",
            viaBluetooth = false,
            replyToText = null,
            replyToSender = null,
            mediaMeta = null,
            scheduledForMillis = null
        )

        val messages = store.observeMessages(firstChat.id).first()
        val sentMsg = messages.last()
        assertEquals("Salam without Google Login!", sentMsg.text)

        store.toggleMessageReaction(firstChat.id, sentMsg, "❤️")

        // Verify disk persistence across a fresh LocalWhatsupStore instance
        val reloadedStore = LocalWhatsupStore(context)
        reloadedStore.ensureInitialized(displayName = "Hamza", phoneNumber = "+92 300 4512980")
        val reloadedMsgs = reloadedStore.observeMessages(firstChat.id).first()
        val reloadedSent = reloadedMsgs.last { it.id == sentMsg.id }
        assertEquals(mapOf("❤️" to 1L), reloadedSent.reactions)
        assertEquals("❤️", reloadedSent.myReaction)
    }
}
