const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write users, chats, messages, statuses, or calls", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("statuses").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("calls").get());
});

test("Authenticated owner: valid UserProfile, ChatThread, ChatMessage, StatusUpdate, CallRecord create and update succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  // UserProfile
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Hamza",
      phoneNumber: "+92 300 4512980",
      about: "Assalam-o-Alaikum! Using Whatsup",
      twoStepEnabled: false,
      hideOnline: false,
      hideBlueTicks: false,
      hideLastSeen: false,
      dataSaver: false,
      autoReplyEnabled: false,
      appLockEnabled: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Partial update on UserProfile
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      hideBlueTicks: true,
      dataSaver: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // ChatThread create (no 'id' field)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_ammi").set({
      userId: ALICE_UID,
      title: "Ammi ❤️",
      phone: "+92 301 7788990",
      avatarColorHex: 0xFF25D366,
      chatType: "DIRECT",
      lastMessage: "Khana kha liya beta?",
      lastMessageTimeLabel: "10:15 AM",
      lastMessageTick: "READ",
      unreadCount: 1,
      pinned: true,
      archived: false,
      muted: false,
      locked: false,
      online: true,
      typing: false,
      lastSeenText: "online",
      disappearingMode: "OFF",
      wallpaperStyle: "DEFAULT",
      memberCount: 2,
      onlyAdminCanSend: false,
      bluetoothChat: false,
      encryptionCode: "88412-90124-55612",
      sortOrder: 100,
      createdAt: now,
      updatedAt: now,
    })
  );

  // ChatThread list query
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").orderBy("sortOrder", "desc").get()
  );

  // ChatMessage create (via Bluetooth offline queue sync)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_ammi").collection("messages").doc("msg_1").set({
      userId: ALICE_UID,
      chatId: "chat_ammi",
      senderName: "Me",
      fromMe: true,
      text: "Ji Ammi, abhi khaya hai",
      messageType: "TEXT",
      tickStatus: "SENT",
      viaBluetooth: true,
      starred: false,
      deletedForEveryone: false,
      deletedForMe: false,
      viewOnceOpened: false,
      timeLabel: "10:16 AM",
      createdAt: now,
      updatedAt: now,
    })
  );

  // ChatMessage tick update & star update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_ammi").collection("messages").doc("msg_1").update({
      tickStatus: "READ",
      viaBluetooth: false,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_ammi").collection("messages").doc("msg_1").update({
      starred: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("chat_ammi").collection("messages").doc("msg_1").update({
      reactions: { "❤️": 1 },
      myReaction: "❤️",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // StatusUpdate create & mark viewed
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("statuses").doc("st_1").set({
      userId: ALICE_UID,
      authorName: "Ali Raza",
      caption: "Kahror Pakka sunset vibes!",
      statusType: "PHOTO",
      bgColorHex: 0xFF075E54,
      viewedByCount: 14,
      viewersSummary: "Ayesha, Hamza, Bilal +11",
      timeLabel: "25m ago",
      viewed: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  // CallRecord create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("calls").doc("call_1").set({
      userId: ALICE_UID,
      peerName: "Abbu",
      callType: "VIDEO",
      direction: "OUTGOING",
      durationLabel: "08:42",
      participantCount: 2,
      recorded: false,
      timeLabel: "Yesterday",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Cross-user isolation & negative bounds: Bob cannot read Alice; shadow fields & @DocumentId 'id' rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      phoneNumber: "+92 300 1112233",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read or write Alice's data
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("chats").get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("chats").doc("hack").set({
      userId: ALICE_UID,
      title: "Hijack",
      chatType: "DIRECT",
      lastMessage: "hi",
      lastMessageTimeLabel: "now",
      lastMessageTick: "SENT",
      unreadCount: 0,
      pinned: false,
      archived: false,
      muted: false,
      locked: false,
      online: false,
      typing: false,
      disappearingMode: "OFF",
      memberCount: 2,
      onlyAdminCanSend: false,
      bluetoothChat: false,
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Reject ghost 'id' field on ChatThread
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("chats").doc("bad_id_doc").set({
      id: "bad_id_doc",
      userId: ALICE_UID,
      title: "Bad",
      chatType: "DIRECT",
      lastMessage: "hi",
      lastMessageTimeLabel: "now",
      lastMessageTick: "SENT",
      unreadCount: 0,
      pinned: false,
      archived: false,
      muted: false,
      locked: false,
      online: false,
      typing: false,
      disappearingMode: "OFF",
      memberCount: 2,
      onlyAdminCanSend: false,
      bluetoothChat: false,
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Reject future timestamp spoofing
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("statuses").doc("future_st").set({
      userId: ALICE_UID,
      authorName: "Alice",
      caption: "Future",
      statusType: "TEXT",
      bgColorHex: 0xFF25D366,
      viewedByCount: 0,
      viewersSummary: "",
      timeLabel: "now",
      viewed: false,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: now,
    })
  );
});
